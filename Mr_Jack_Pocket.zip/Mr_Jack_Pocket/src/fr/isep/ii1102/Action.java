package fr.isep.ii1102;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Action {

	public static void carteAlibi(String[] args) {
		// TODO Auto-generated method stub
		List<String> liste = new ArrayList<String>();                   // Permet de cr�er une liste "liste" des cartes ALibi.

		liste.add("Madame");                                            // Permet d'ajouter le nom du personnage en derni�re position de cette liste.
		liste.add("Sgt Goodley");
		liste.add("Jeremy Bert");
		liste.add("William Gull");
		liste.add("Miss Stealthy");
		//liste.add("John Smith");
		liste.add("Inspecteur Lestrade");
		liste.add("John Pize");
		liste.add("Joseph Lane");

		int indiceAuHasard = (int) (Math.random() * (liste.size() - 1));      // Permet de s�lectionner un indice au hasard dans cette liste "liste".
        
		System.out.println("Vous avez pioch� la carte " + liste.get(indiceAuHasard)    // Permet d'afficher ce message en console uniquement pour 
					+ ".");                                                            // ne pas r�v�ler la carte pioch�e
		}
	}


