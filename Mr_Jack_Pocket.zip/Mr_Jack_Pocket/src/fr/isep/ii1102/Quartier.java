package fr.isep.ii1102;

import javax.swing.ImageIcon;/*
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Quartier {

	public static void main(String[] args) {
		 //URL des images repr�sentantns les tuiles de rues
		 JFrame frame = new JFrame("Mr Jack Pocket"); // TITRE
	     frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	     frame.setSize(1200,750);// TAILLE
	     frame.setLocationRelativeTo(null);
	     frame.setVisible(true);
	     
	     String InspLestrader="InspLestrade-recto.png";
	     String JeremyBertr="JeremyBert-recto.png";
	     String JohnPizerr="JohnPizer-recto.png";
	     String JohnSmithr="JohnSmith-recto.png";
	     String JosephLaner="JosephLane-recto.png";
	     String Madamer="Madame-rector.png";
	     String MissStealthyr="MissStealthy-recto.png";
	     String SgtGoodleyr="SgtGoodley-recto.png";
	     String WilliamGullr="WilliamGull-recto.png";
	     String plateau="plateau.jpg";
	     
	     ImageIcon iconeInspLestrader = new ImageIcon(InspLestrader);
	     ImageIcon iconeJeremyBertr = new ImageIcon(JeremyBertr);
	     ImageIcon iconeJohnPizerr = new ImageIcon(JohnPizerr);
	     ImageIcon iconeJohnSmithr = new ImageIcon(JohnSmithr);
	     ImageIcon iconeJosephLaner = new ImageIcon(JosephLaner);
	     ImageIcon iconeMadamer = new ImageIcon(Madamer);
	     ImageIcon iconeMissStealthyr = new ImageIcon(MissStealthyr);
	     ImageIcon iconeSgtGoodleyr = new ImageIcon(SgtGoodleyr);
	     ImageIcon iconeWilliamGullr = new ImageIcon(WilliamGullr);
	     ImageIcon iconeplateau = new ImageIcon(plateau);
	     
	     JLabel image1 = new JLabel(iconeInspLestrader);
	     image1.setBounds(375, 200, 200, 200);
	     frame.add(image1);
	      
	     JLabel image2 = new JLabel(iconeJeremyBertr);
	     image2.setBounds(600, 200, 200, 200);
	     frame.add(image2);
	     
	     JLabel image3 = new JLabel(iconeJohnPizerr);
	     image3.setBounds(825, 200, 200, 200);
	     frame.add(image3);
	     
	     JLabel image4 = new JLabel(iconeJohnSmithr);
	     image4.setBounds(375, 425, 200, 200);
	     frame.add(image4);
	      
	     JLabel image5 = new JLabel(iconeJosephLaner);
	     image5.setBounds(600, 425, 200, 200);
	     frame.add(image5);
	     
	     JLabel image6 = new JLabel(iconeMadamer);
	     image6.setBounds(825, 425, 200, 200);
	     frame.add(image6);
	     
	     JLabel image7 = new JLabel(iconeMissStealthyr);
	     image7.setBounds(375, 650, 200, 200);
	     frame.add(image7);
	      
	     JLabel image8 = new JLabel(iconeSgtGoodleyr);
	     image8.setBounds(600, 650, 200, 200);
	     frame.add(image8);
	     
	     JLabel image9 = new JLabel(iconeWilliamGullr);
	     image9.setBounds(825, 650, 200, 200);
	     frame.add(image9);
	     
	     JLabel image10 = new JLabel(plateau);
	     image10.setBounds(0, 76, 200, 200);
	     frame.add(image10);
	     frame.validate();
	     
	     
	}}
*/