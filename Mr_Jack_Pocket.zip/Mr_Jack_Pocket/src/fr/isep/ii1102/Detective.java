package fr.isep.ii1102;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
/*
public class Detective {

	public static void main(String[] args) {
		
	     
		 JFrame frame = new JFrame("Mr Jack Pocket"); // TITRE
	     frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	     frame.setSize(1200,750);// TAILLE
	     frame.setLocationRelativeTo(null);
	     frame.setVisible(true);
	     
	     //URL des images repr�sentantns les jetons d�tectives
	     
	     String Sherlock="Sherlock.png";
	     String Watson="Watson.png";
	     String Tobi="Tobi.png";
	     
	     ImageIcon iconeSherlock = new ImageIcon(Sherlock);
	     ImageIcon iconeWatson = new ImageIcon(Watson);
	     ImageIcon iconeTobi = new ImageIcon(Tobi);
	     
	  // Cr�ation de JLabel pour les d�tectives
	     
	     JLabel image11 = new JLabel(iconeSherlock);
	     image11.setBounds(380, 10, 200, 200);
	     frame.add(image11);
	     
	     JLabel image12 = new JLabel(iconeWatson);
	     image12.setBounds(1000, 675, 200, 200);
	     frame.add(image12);
	     
	     JLabel image13 = new JLabel(iconeTobi);
	     image13.setBounds(625, 875, 100, 100);
	     frame.add(image13);
	     frame.validate();
	     

	}

}
*/