package fr.isep.ii1102;

public class Player {
	private String name;
	private int color;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
