package fr.isep.ii1102;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Tours {

	// Fonction permettant de savoir qui commence le tour.

	public void Quicommence() {
		int nbTours = 1; // Initialisation du nombre de tours � 1.

		if (nbTours % 2 == 0) { // Si le nombre de tour est un nombre pair alosr Mr Jack commence le tour.
			System.out.println("Mr Jack commence le tour");
		} else { // Sinon, c'est Sherlock Holmes qui commence le tour.
			System.out.println("Sherlock Holmes commence le tour en choisissant une carte action.");
		}
	}
 
    // Fonction permettant d'anoncer la fin de la partie si le nombre de tours est de 8

	public void FindePartie(int n) {
		int nbTours = 8; // Initialisation du nombre de tours � 1.
		if (nbTours == 8) { // Si le nombre detour est �gal � 8, on annonce la fin de la partie � la fin du
							// tours
			System.out.println("Fin de la partie, Mr Jack remporte la victoire");
		}
	}

	// Fonction permettant d'afficher le d�roulement du jeu
	public void Deroulementdujeu() {
		System.out.println("Tout d'abord, veuillez m�langer les cartes actions");
		Traque1et2();                   // Tours 1 et 2 avec appels � t�moins.
		Traque3et4();                   // Tours 3 et 4 avec appels � t�moins.
		Traque5et6();                   // Tours 5 et 6 avec appels � t�moins.
		Traque7et8();                   // Tours 7 et 8 avec appels � t�moins.
	}

	// Fonction permettant d'effectuer la traque pour les deux premiers tours.
	public void Traque1et2() {
		ListedesjetonsAction();
		// Liste des cartes action avant de les m�langer

	}

	public void ListedesjetonsAction() {

// Liste des cartes Action
		List<String> liste = new ArrayList<String>();
		// Liste des cartes action avant de les m�langer
		liste.add("Holmes");
		liste.add("Watson");
		liste.add("Le chien");
		liste.add("Joker");
		liste.add("Rotation");
		liste.add("Rotation");
		liste.add("Echange");
		liste.add("Alibi");
		

		// Les lignes de codes suivantes permettent de s�lectionner quatres cartes Action au hasard,
		// de les enlever de la liste principale
		// puis de les ajouter � la liste Recto des cartes Actions.

		List<String> listeR = new ArrayList<String>();                    // Permet de cr�er une liste vide de quatres cartes actions (Recto).
		
		int indiceAuHasard1 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String h = liste.get(indiceAuHasard1);                            // R�cup�re l'�l�ment d'indice 'indiceAUHasard1'.
		liste.remove(indiceAuHasard1);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'.
		listeR.add(h);                                                    // Permet d'ajouter cet �l�ment � la deuxi�me liste 'listeR'.

		int indiceAuHasard2 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String w = liste.get(indiceAuHasard2);                            // R�cup�re l'�l�ment d'indice 'indiceAUHasard2'.
		liste.remove(indiceAuHasard2);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'.
		listeR.add(w);                                                    // Permet d'ajouter cet �l�ment � la deuxi�me liste 'listeR'.                                                    

		int indiceAuHasard3 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String t = liste.get(indiceAuHasard3);                            // R�cup�re l'�l�ment d'indice 'indiceAUHasard3'.
		liste.remove(indiceAuHasard3);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'.
		listeR.add(t);                                                    // Permet d'ajouter cet �l�ment � la deuxi�me liste 'listeR'.
		
		int indiceAuHasard4 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String j = liste.get(indiceAuHasard4);                            // R�cup�re l'�l�ment d'indice 'indiceAUHasard4'.
		liste.remove(indiceAuHasard4);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'.
		listeR.add(j);                                                    // Permet d'ajouter cet �l�ment � la deuxi�me liste 'listeR'.

		// Fonction permmettant de m�langer les cartes actions

		System.out.println("Taper m pour cela");
		Scanner Carte = new Scanner(System.in);
		String c = Carte.nextLine();

		if (c.equals("m")) {
			System.out.println("Voici la liste des cartes Action pour ce tour: " + listeR);// Affiche la liste ds jetons
																							// c�t� Recto
			Quicommence();
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			Appelatemoin();                                  // Appelle la fonction permettant d'effectuer l'appel � t�moin.

			                                                    
			List<String> listeV = new ArrayList<String>();      // Permet de cr�er une liste vide des quatre cartes actions restantes (Verso).

			int indiceAuHasard5 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
			String r1 = liste.get(indiceAuHasard5);                           // R�cup�re l'�l�ment d'indice 'indiceAUHasard5'.
			liste.remove(indiceAuHasard5);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
			listeV.add(r1);                                                   // Permet d'ajouter cet �l�ment � la troisi�me liste 'listeV'.

			int indiceAuHasard6 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
			String r2 = liste.get(indiceAuHasard6);                           // R�cup�re l'�l�ment d'indice 'indiceAUHasard6'.
			liste.remove(indiceAuHasard6);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
			listeV.add(r2);                                                   // Permet d'ajouter cet �l�ment � la troisi�me liste 'listeV'.

			int indiceAuHasard7 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
			String e = liste.get(indiceAuHasard7);                            // R�cup�re l'�l�ment d'indice 'indiceAUHasard7'.
			liste.remove(indiceAuHasard7);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
			listeV.add(e);                                                    // Permet d'ajouter cet �l�ment � la troisi�me liste 'listeV'.

			int indiceAuHasard8 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
			String a = liste.get(indiceAuHasard8);                            // R�cup�re l'�l�ment d'indice 'indiceAUHasard8'.
			liste.remove(indiceAuHasard8);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
			listeV.add(a);                                                    // Permet d'ajouter cet �l�ment � la troisi�me liste 'listeV'.
			
			System.out.println("Taper m pour les quatres cartes Actions suivantess");
			Scanner Cartes = new Scanner(System.in);
			String s = Carte.nextLine();

			if (c.equals("m")) {
				System.out.println("Voici la liste des cartes Action pour ce tour: " + listeV);// Affiche la liste ds jetons
																								// c�t� Recto
				Quicommence();
				ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
				ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
				ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
				ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
				Appelatemoin();                                  // Appelle la fonction permettant d'effectuer l'appel � t�moin.
		
		}}
	}

	
	// Fonction permettant de piocher une carte Action.
	
	public void ChoisirunecarteAction() {

		// Donne les instructions au joueurs pour choisir la carte Action de son choix.
		System.out.println("Taper H pour choisir la carte Holmes ");
		System.out.println("Taper W pour choisir la carte Watson");
		System.out.println("Taper T pour choisir la carte Toby");
		System.out.println("Taper J pour choisir la carte Joker");
		System.out.println("Taper R1 pour choisir la carte Rotation");
		System.out.println("Taper R2 pour choisir la carte Rotation");
		System.out.println("Taper E pour choisir la carte Echange");
		System.out.println("Taper A pour choisir la carte Alibi");

		Scanner Action = new Scanner(System.in); // Permet � l'utilisateur de saisir du texte.
		String A = Action.nextLine();
		
		if (A.equals("H")) {                     // Si l'utilisateur tape la lettre H, alors il choisit la carte action associ�e � Sherlock Holmes.						                     
			System.out.println("Vous avez choisi la carte Holmes");
		}
		if (A.equals("W")) {                     // Si l'utilisateur tape la lettre W, alors il choisit la carte action associ�e� Watson.						
			System.out.println("Vous avez choisi la carte Watson");
		}
		if (A.equals("T")) {                     // Si l'utilisateur tape la lettre T, alors il choisit la carte action associ�e � Tobi.					
			System.out.println("Vous avez choisi la carte Toby");
		}
		if (A.equals("J")) {                     // Si l'utilisateur tape la lettre J, alors il choisit la carte action 'Joker'.
			System.out.println("Vous avez choisi la carte Joker");
		}
		if (A.equals("R1")) {                    // Si l'utilisateur tape 'R1', alors il choisit la carte action 'Rotation'.
			System.out.println("Vous avez choisi la carte Rotation");
		}
		if (A.equals("R2")) {                    // Si l'utilisateur tape 'R2', alors il choisit la carte action 'Rotation'.
			System.out.println("Vous avez choisi la carte Rotation");
		}
		if (A.equals("E")) {                     // Si l'utilisateur tape la lettre E, alors il choisit la carte action 'Echange'.						
			System.out.println("Vous avez choisi la carte Echange");
		}
		if (A.equals("A")) { // Si l'utilisateur tape la lettre A, alors il choisit la carte action 'Alibi'.
			System.out.println("Vous avez choisi la carte Alibi");
			Action a1= new Action();
			a1.carteAlibi(null);

		}
	}
	
	// Fonction permettant d'effectuer la traque pour les deux  tours suivants et de piocher des cartes actions.
	
	public void Traque3et4() { 
		
		List<String> liste = new ArrayList<String>();                            // Permet de cr�er une liste vide de cartes Actions.
        
		// Permet d'ajouter les cartes actions � cette liste 'liste'.
		liste.add("Holmes");
		liste.add("Watson");
		liste.add("Le chien");
		liste.add("Joker");
		liste.add("Rotation");
		liste.add("Rotation");
		liste.add("Echange");
		liste.add("Alibi");

		List<String> listeR = new ArrayList<String>();                            // Permet de cr�er une liste vide de quatres cartes actions (Recto).
		int indiceAuHasard1 = (int) (Math.random() * (liste.size() - 1));         // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String h = liste.get(indiceAuHasard1);                                    // R�cup�re l'�l�ment d'indice 'indiceAUHasard1'.                   
		liste.remove(indiceAuHasard1);                                            // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeR.add(h);

		int indiceAuHasard2 = (int) (Math.random() * (liste.size() - 1));         // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String w = liste.get(indiceAuHasard2);                                    // R�cup�re l'�l�ment d'indice 'indiceAUHasard2'.
		liste.remove(indiceAuHasard2);                                            // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeR.add(w);

		int indiceAuHasard3 = (int) (Math.random() * (liste.size() - 1));         // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String t = liste.get(indiceAuHasard3);                                    // R�cup�re l'�l�ment d'indice 'indiceAUHasard3'.
		liste.remove(indiceAuHasard3);                                            // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeR.add(t);

		int indiceAuHasard4 = (int) (Math.random() * (liste.size() - 1));         // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String j = liste.get(indiceAuHasard4);                                    // R�cup�re l'�l�ment d'indice 'indiceAUHasard4'.
		liste.remove(indiceAuHasard4);                                            // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeR.add(j);
		
		
		
		
		System.out.println("Taper m pour cela");
		Scanner Carte4 = new Scanner(System.in);
		String q = Carte4.nextLine();

		if (q.equals("m")) {
			System.out.println("Voici la liste des cartes Action pour ce tour: " + listeR);// Affiche la liste ds jetons
																							// c�t� Recto
			Quicommence();
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			Appelatemoin();                                  // Appelle la fonction permettant d'effectuer l'appel � t�moin.
		
		

		List<String> listeV = new ArrayList<String>();

		int indiceAuHasard5 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String r1 = liste.get(indiceAuHasard5);                           // R�cup�re l'�l�ment d'indice 'indiceAUHasard5'.
		liste.remove(indiceAuHasard5);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeV.add(r1);

		int indiceAuHasard6 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String r2 = liste.get(indiceAuHasard6);                           // R�cup�re l'�l�ment d'indice 'indiceAUHasard6'.
		liste.remove(indiceAuHasard6);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeV.add(r2);

		int indiceAuHasard7 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String e = liste.get(indiceAuHasard7);                            // R�cup�re l'�l�ment d'indice 'indiceAUHasard7'.
		liste.remove(indiceAuHasard7);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeV.add(e);

		int indiceAuHasard8 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String a = liste.get(indiceAuHasard8);                            // R�cup�re l'�l�ment d'indice 'indiceAUHasard8'.
		liste.remove(indiceAuHasard8);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeV.add(a);
		System.out.println(listeV);
		
		System.out.println("Taper m pour les quatres cartes Actions suivantess");
		Scanner Carte5 = new Scanner(System.in);
		String q1 = Carte5.nextLine();

		if (q1.equals("m")) {
			System.out.println("Voici la liste des cartes Action pour ce tour: " + listeV);// Affiche la liste ds jetons
																							// c�t� Recto
			Quicommence();
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			Appelatemoin();                                  // Appelle la fonction permettant d'effectuer l'appel � t�moin.
	}
	}
	}
public void Traque5et6() { 
		
		List<String> liste = new ArrayList<String>();                            // Permet de cr�er une liste vide de cartes Actions.
        
		// Permet d'ajouter les cartes actions � cette liste 'liste'.
		liste.add("Holmes");
		liste.add("Watson");
		liste.add("Le chien");
		liste.add("Joker");
		liste.add("Rotation");
		liste.add("Rotation");
		liste.add("Echange");
		liste.add("Alibi");

		List<String> listeR = new ArrayList<String>();                            // Permet de cr�er une liste vide de quatres cartes actions (Recto).
		int indiceAuHasard1 = (int) (Math.random() * (liste.size() - 1));         // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String h = liste.get(indiceAuHasard1);                                    // R�cup�re l'�l�ment d'indice 'indiceAUHasard1'.                   
		liste.remove(indiceAuHasard1);                                            // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeR.add(h);

		int indiceAuHasard2 = (int) (Math.random() * (liste.size() - 1));         // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String w = liste.get(indiceAuHasard2);                                    // R�cup�re l'�l�ment d'indice 'indiceAUHasard2'.
		liste.remove(indiceAuHasard2);                                            // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeR.add(w);

		int indiceAuHasard3 = (int) (Math.random() * (liste.size() - 1));         // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String t = liste.get(indiceAuHasard3);                                    // R�cup�re l'�l�ment d'indice 'indiceAUHasard3'.
		liste.remove(indiceAuHasard3);                                            // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeR.add(t);

		int indiceAuHasard4 = (int) (Math.random() * (liste.size() - 1));         // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String j = liste.get(indiceAuHasard4);                                    // R�cup�re l'�l�ment d'indice 'indiceAUHasard4'.
		liste.remove(indiceAuHasard4);                                            // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeR.add(j);
		
		
		
		
		System.out.println("Taper m pour cela");
		Scanner Carte4 = new Scanner(System.in);
		String q = Carte4.nextLine();

		if (q.equals("m")) {
			System.out.println("Voici la liste des cartes Action pour ce tour: " + listeR);// Affiche la liste ds jetons
																							// c�t� Recto
			Quicommence();
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			Appelatemoin();                                  // Appelle la fonction permettant d'effectuer l'appel � t�moin.
		

		List<String> listeV = new ArrayList<String>();

		int indiceAuHasard5 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String r1 = liste.get(indiceAuHasard5);                           // R�cup�re l'�l�ment d'indice 'indiceAUHasard5'.
		liste.remove(indiceAuHasard5);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeV.add(r1);

		int indiceAuHasard6 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String r2 = liste.get(indiceAuHasard6);                           // R�cup�re l'�l�ment d'indice 'indiceAUHasard6'.
		liste.remove(indiceAuHasard6);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeV.add(r2);

		int indiceAuHasard7 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String e = liste.get(indiceAuHasard7);                            // R�cup�re l'�l�ment d'indice 'indiceAUHasard7'.
		liste.remove(indiceAuHasard7);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeV.add(e);

		int indiceAuHasard8 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
		String a = liste.get(indiceAuHasard8);                            // R�cup�re l'�l�ment d'indice 'indiceAUHasard8'.
		liste.remove(indiceAuHasard8);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
		listeV.add(a);
		System.out.println(listeV);
		
		System.out.println("Taper m pour les quatres cartes Actions suivantess");
		Scanner Carte5 = new Scanner(System.in);
		String q1 = Carte5.nextLine();

		if (q1.equals("m")) {
			System.out.println("Voici la liste des cartes Action pour ce tour: " + listeV);// Affiche la liste ds jetons
																							// c�t� Recto
			Quicommence();
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
			Appelatemoin();                                  // Appelle la fonction permettant d'effectuer l'appel � t�moin.
	}
	}
}
public void Traque7et8() { 
	
	List<String> liste = new ArrayList<String>();                            // Permet de cr�er une liste vide de cartes Actions.
    
	// Permet d'ajouter les cartes actions � cette liste 'liste'.
	liste.add("Holmes");
	liste.add("Watson");
	liste.add("Le chien");
	liste.add("Joker");
	liste.add("Rotation");
	liste.add("Rotation");
	liste.add("Echange");
	liste.add("Alibi");

	List<String> listeR = new ArrayList<String>();                            // Permet de cr�er une liste vide de quatres cartes actions (Recto).
	int indiceAuHasard1 = (int) (Math.random() * (liste.size() - 1));         // Selectionne un indice au hasard de la premi�re liste 'liste'.
	String h = liste.get(indiceAuHasard1);                                    // R�cup�re l'�l�ment d'indice 'indiceAUHasard1'.                   
	liste.remove(indiceAuHasard1);                                            // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
	listeR.add(h);

	int indiceAuHasard2 = (int) (Math.random() * (liste.size() - 1));         // Selectionne un indice au hasard de la premi�re liste 'liste'.
	String w = liste.get(indiceAuHasard2);                                    // R�cup�re l'�l�ment d'indice 'indiceAUHasard2'.
	liste.remove(indiceAuHasard2);                                            // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
	listeR.add(w);

	int indiceAuHasard3 = (int) (Math.random() * (liste.size() - 1));         // Selectionne un indice au hasard de la premi�re liste 'liste'.
	String t = liste.get(indiceAuHasard3);                                    // R�cup�re l'�l�ment d'indice 'indiceAUHasard3'.
	liste.remove(indiceAuHasard3);                                            // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
	listeR.add(t);

	int indiceAuHasard4 = (int) (Math.random() * (liste.size() - 1));         // Selectionne un indice au hasard de la premi�re liste 'liste'.
	String j = liste.get(indiceAuHasard4);                                    // R�cup�re l'�l�ment d'indice 'indiceAUHasard4'.
	liste.remove(indiceAuHasard4);                                            // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
	listeR.add(j);
	
	
	
	
	System.out.println("Taper m pour cela");
	Scanner Carte4 = new Scanner(System.in);
	String q = Carte4.nextLine();

	if (q.equals("m")) {
		System.out.println("Voici la liste des cartes Action pour ce tour: " + listeR);// Affiche la liste ds jetons
																						// c�t� Recto
		Quicommence();
		ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
		ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
		ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
		ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
		Appelatemoin();                                  // Appelle la fonction permettant d'effectuer l'appel � t�moin.
	

	List<String> listeV = new ArrayList<String>();

	int indiceAuHasard5 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
	String r1 = liste.get(indiceAuHasard5);                           // R�cup�re l'�l�ment d'indice 'indiceAUHasard5'.
	liste.remove(indiceAuHasard5);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
	listeV.add(r1);

	int indiceAuHasard6 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
	String r2 = liste.get(indiceAuHasard6);                           // R�cup�re l'�l�ment d'indice 'indiceAUHasard6'.
	liste.remove(indiceAuHasard6);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
	listeV.add(r2);

	int indiceAuHasard7 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
	String e = liste.get(indiceAuHasard7);                            // R�cup�re l'�l�ment d'indice 'indiceAUHasard7'.
	liste.remove(indiceAuHasard7);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'
	listeV.add(e);

	int indiceAuHasard8 = (int) (Math.random() * (liste.size() - 1)); // Selectionne un indice au hasard de la premi�re liste 'liste'.
	String a = liste.get(indiceAuHasard8);                            // R�cup�re l'�l�ment d'indice 'indiceAUHasard8'.
	liste.remove(indiceAuHasard8);                                    // Permet de supprimer cet �l�ment de la premi�re liste 'liste'.
	listeV.add(a);
	System.out.println(listeV);
	
	System.out.println("Taper m pour les quatres cartes Actions suivantess");
	Scanner Carte5 = new Scanner(System.in);
	String q1 = Carte5.nextLine();

	if (q1.equals("m")) {
		System.out.println("Voici la liste des cartes Action pour ce tour: " + listeV);// Affiche la liste ds jetons
																						// c�t� Recto
		Quicommence();
		ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
		ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
		ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
		ChoisirunecarteAction();                         // Appelle la fonction permettant de choisir une carte Action.
		Appelatemoin();                                  // Appelle la fonction permettant d'effectuer l'appel � t�moin.
}
}}

// Fonction permettant au d�tective d'effectuer l'appel � t�moin

public void Appelatemoin() {
	
	System.out.println("Mr Jack est il visible par l'un des d�tectives ua moins : Oui ou Non ?");
	Scanner ATM = new Scanner(System.in);            // Permet � l'utlisitateur de saisir du texte ; 'Oui' ou 'Non'.
	String atm = ATM.nextLine();

	if (atm.equals("Oui")) {                         // Si l'utilisateur saisit 'Oui', on retourne les cartes qui ne sont pas visibles.
		System.out.println("Veuillez retourner toutes les cartes qui ne sont pas visibles");
}   if (atm.equals("Non")) {                            // Sinon, on retourne les cartes qui  sont  visibles.
	System.out.println("Veuillez retourner toutes les cartes qui sont visibles");
}
}
}
