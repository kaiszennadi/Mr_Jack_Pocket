package fr.isep.ii1102;
import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.net.URL;

 

public class Image extends Applet
{
private java.awt.Image plateau=null;
public void paint(Graphics g) {
	this.setSize(640,480);;
	if (plateau==null) {
		plateau=getImage(null, "plateau");
	Graphics2D g2=(Graphics2D)g;
	g2.drawImage(plateau, 25, 50, 25, 25,this);
	}
}
public Object getImage(String path) {
	
	Object tempImage=null;
	try {
		URL imageURL =Image.class.getResource(path);
		tempImage = Toolkit.getDefaultToolkit().getImage(imageURL);
	}
	catch (Exception e) {
		System.out.println("An error occured - "+ e.getMessage());
		
	}
	
	return tempImage;
	
}
}
