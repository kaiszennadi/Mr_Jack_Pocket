package fr.isep.ii1102;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

// Classe personnage
public class Personnage {
 
	public void qui(String n) {                /* Fonction permettant aux joueurs de choisir le personnage 
		                                        qu'ils veulent incarner lors de cette partie : Sherlock Holmes ou Mr Jack.*/
		

		System.out.println("Tout d'abbord, veuillez choisir votre personnage :"); // Permet d'afficher les chaines de caract�res ci-contre.
		System.out.println("Taper S pour choisir Sherlock Holmes");
		System.out.println("Taper J pour choisir Mr Jack");
		
		Scanner Perso = new Scanner(System.in);                       // Permet � l'utilisateur de choisir son personnage en tapant une lettre S ou J.
		String a = Perso.nextLine();

		if (a.equals("S")) {                                                          // Si l'utilisateur tape S alors il choisit Sherlock Holmes
			System.out.println("Vous avez choisi le personnage de Sherlock Holmes."); // Permet � l'utilsateur de confirmer son choix.

			System.out.println("Mr Jack pioche une carte au hasard.");                // Dans les deux cas la console affiche le message ci-contre. 
		}
		if (a.equals("J")) {                                                          // Si l'utilisateur tape J alors il choisit Mr Jack
			System.out.println("Vous avez choisi le personnage de Mr Jack.");         // Permet � l'utilisateur de confirmer son choix.

			System.out.println("Mr Jack pioche une carte au hasard.");

			String p = null;
			piocher(p);     // Si l'utilisateur choisit Mr Jack alors il peut piocher une carte Alibi pour conna�tre son identit�.
		}
	} 

	// Carte secr�te de Mr Jack
	// Fonction permettant � Mr Jack de piocher une carte Alibi afin de conna�tre l'identit� sec�te sous laquelle il se cache. 
	
	public void piocher(String n) {
		System.out.println("Veuillez piocher une carte Alibi :");
		System.out.println("Taper P pour piocher une carte");
		Scanner Carte = new Scanner(System.in);                                          // Permet � l'tilisateur de saisir du texte dans la console.
		String c = Carte.nextLine();

		if (c.equals("P")) {                                                             // Si l'utilisateur saisit la lettre "P"
			System.out.println("Vous avez pioch� la carte 'John Smith'"
					+ "ce qui signifie que Mr Jack se dissimule sous cette identit�."); // et on affiche ce message en console uniquement pour 
			                                                                             // ne pas r�v�ler cette identit� aux d�tectives.

		}
	}
	public void Piocher(String n) {                                     
		                                                               
		
		List<String> liste = new ArrayList<String>();                   // Permet de cr�er une liste "liste" des cartes ALibi.

		liste.add("Madame");                                            // Permet d'ajouter le nom du personnage en derni�re position de cette liste.
		liste.add("Sgt Goodley");
		liste.add("Jeremy Bert");
		liste.add("William Gull");
		liste.add("Miss Stealthy");
		liste.add("John Smith");
		liste.add("Inspecteur Lestrade");
		liste.add("John Pize");
		liste.add("Joseph Lane");

		int indiceAuHasard = (int) (Math.random() * (liste.size() - 1)); // Permet de s�lectionner un indice au hasard dans cette liste "liste".

		System.out.println("Veuillez piocher une carte Alibi :");
		System.out.println("Taper P pour piocher une carte");

		Scanner Carte = new Scanner(System.in);                                          // Permet � l'tilisateur de saisir du texte dans la console.
		String c = Carte.nextLine();

		if (c.equals("P")) {                                                             // Si l'utilisateur saisit la lettre "P"
			System.out.println("Vous avez pioch� la carte " + liste.get(indiceAuHasard)  // alors on r�cup�re l'�l�ment d'indice "indiceauHasard"
					+ " ce qui signifie que Mr Jack se dissimule sous cette identit�."); // et on affiche ce message en console uniquement pour 
			                                                                             // ne pas r�v�ler cette identit� aux d�tectives.

		}
	}

	// Fonction permettant d'afficher la liste des personnages  ainsi que la lettre par laquelle ils sont repr�sent�s sur le plateau de jeu
	// dans la console.
	
	public void listedesPersonnages() {               
		                                              

		System.out.println("Voici les lettres repr�sentant les diff�rents personnages sur le plateau");
		System.out.println(" ");
		System.out.println("s = Sherlock Holmes");
		System.out.println("X = Mr Jack");
		System.out.println("w = Watson");
		System.out.println("t = Toby");
		System.out.println("M = Madame");
		System.out.println("G = Sgt Goodley");
		System.out.println("B = Jeremy Bert");
		System.out.println("W = William Gull");
		System.out.println("S = Miss Stealthy");
		System.out.println("J = John Smith");
		System.out.println("I = Bleu=Inspecteur Lestrade");
		System.out.println("P = John Pize");
		System.out.println("L = Joseph Lane");

	}

}
