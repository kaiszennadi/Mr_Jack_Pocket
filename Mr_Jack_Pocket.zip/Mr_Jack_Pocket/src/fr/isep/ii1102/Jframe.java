package fr.isep.ii1102;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.text.JTextComponent;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.Image;
import java.awt.Label;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;

//////////////////// CLASSE PERMETTANT DE R�ALISER L'INTERFACE GRAPHIQUE //////////////////////////////////////////////

// Cr�ation d'une classe Jframe 

public class Jframe extends JFrame {

	 
	// Fonction Main //
	
	public static void Main() {
		fenetre(null);          // Appelle unique ment la m�thode 'fenetre' d�finie ci-dessous.
	}

	
	// Fonction principale de la classe 'Jframe' affichant dif�rents �lements de l'interface graphique.

	public static void fenetre(String[] args) {

		// Cr�ation d'une fen�tre JFrame pour afficher la fen�tre principale de jeu.

		JFrame frame = new JFrame("Mr Jack Pocket");          // Titre de la fen�tre principale
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Permet de fermer l'interface graphique 
		frame.setSize(2500, 2500);                            // Taille de la fen�tre principale
		frame.setLocationRelativeTo(null);                    // Permet de placer la fen�tre au centre de l'�cran
		frame.setVisible(true);                               // Permet de rendre cette fen�tre visible

		// Cr�ation d'un JLabel appel� 'label' qui est le label principal de la fen�tre 'frame'.
		// Un label est une zone ou l'on peut placer du texte et des images par exemple.

		JLabel label = new JLabel("District de Whitechapel"); // Cr�ation d'un JLabel appel� 'label'.
		label.setAlignmentX(0);         // Permet de r�gler l'alignement vertical du Jlabel 'label'.
		label.setAlignmentY(0);         // Permet de r�gler l'alignement horizontal du Jlabel 'label'.
		frame.add(label);               // Perme d'ajouter ce label � la fen�tre principale.

		// Texte

		/*
		 * JTextField field = new JTextField("Nouvelle Partie", 100);
		 * field.setBounds(1300, 50, 200, 40); label.add(field); frame.add(label);
		 */

		JLabel labelnp = new JLabel("District de Whitechapel");
		labelnp.setAlignmentX(0);         // Permet de r�gler l'alignement vertical.
		labelnp.setAlignmentY(0);         // Permet de r�gler l'alignement horizontal.
		label.add(labelnp);
		frame.add(label);                 // Permet d'ajouter ce label � la fen�tre principale.

		// Bouton permettant de commencer une nouvelle partie

		// Bouton permettant de m�langer et placer les tuiles de rues sur le plateau

		JButton bouton1 = new JButton("Placer le tuiles"); // Cr�ation d'un bouton "Placer les tuiles".
		bouton1.setBounds(1650, 100, 200, 50);             // Permet de r�gler la position ainsi que la taille du bouton.
		label.add(bouton1);                                // Permet d'ajouter cet �l�ment au label principal
		// frame.add(label);
		bouton1.setVisible(false);                         // Permet de rendre cet �l�ment visible.
		
		

		// Bouton permettant de commencer une nouvelle partie

		JButton boutonnp = new JButton("Nouvelle Partie"); // Pemet de cr�er un boutin 'Nouvelle Partie'.
		boutonnp.setBounds(1300, 25, 200, 40);             // Permet de r�gler le positionnement et les dimensions de ce bouton.
		label.add(boutonnp);                               // Permet d'ajputer ce bouton au label principal.
		frame.add(label);                                  // Permet d'ajouter ce label � la fen�tre principale.

		boutonnp.addActionListener(new ActionListener() {  // D�finit l'action qui va se r�alisr lorsqu'on actionne le bouton 'Nouvelle Partie'.

			@Override
			public void actionPerformed(ActionEvent e) {   
				labelnp.getText();                         // Permet d'afficher ce label.
				labelnp.setText(                           // Permet d'afficher ce texte.
						"Tout d'abord, veuillez m�langer les tuiles de rues et les placer sur le plateau de jeu");
				labelnp.setBounds(1150, 100, 605, 50);     // Permet de r�gler le positionnement et les dimensions de ce label.
				bouton1.setVisible(true);                  // Permet de rendre cet �l�ment visible.
			}

		});

		// Permet aux joueurs de m�langer et placer les 9 tuiles de rues sur le plateau
		// de jeu

		JLabel label2 = new JLabel();
		label2.setAlignmentX(0);         // Permet de r�gler l'alignement vertical.
		label2.setAlignmentY(0);         // Permet de r�gler l'alignement horizontal.
		label.add(label2);
		frame.add(label);                // Permet d'ajouter ce label � la fen�tre principale.

		// Bouton permettant au joueur de choisir le personnage de Mr Jack

		JButton bouton2 = new JButton("Mr Jack");
		bouton2.setBounds(1710, 200, 175, 35);
		label.add(bouton2);
		frame.add(label);// Permet d'ajouter ce label � la fen�tre principale.
		bouton2.setVisible(false);

		// Permet aux joueurs de choisir le personnage de Sherlock Holmes

		JButton bouton3 = new JButton("Sherlock Holmes");
		bouton3.setBounds(1500, 200, 175, 35);
		label.add(bouton3);
		// frame.add(label);
		bouton3.setVisible(false);

		JLabel labelSherlockHolmesCom = new JLabel();
		labelSherlockHolmesCom.setAlignmentX(0);         // Permet de r�gler l'alignement vertical.
		labelSherlockHolmesCom.setAlignmentY(0);         // Permet de r�gler l'alignement horizontal.
		label.add(labelSherlockHolmesCom);
		frame.add(label);                                // Permet d'ajouter ce label � la fen�tre principale.

		bouton3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				labelSherlockHolmesCom.getText();
				labelSherlockHolmesCom.setText("Sherlock commence le tour en piochant une carte Action");
				labelSherlockHolmesCom.setBounds(1150, 350, 700, 35);
			}
		});
		// Permet aux joueurs de choisir leur personnage
		
		/*bouton1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				label2.getText();
				label2.setText("Veuillez choisir votre personnage");
				label2.setBounds(1150, 200, 200, 35);
				bouton2.setVisible(true);
				bouton3.setVisible(true);
				frame.add(image13);

			}
		});*/

		// Permet d'afficher le nom du plateau de jeu

		JTextField field2 = new JTextField("           District de Whitechapel", 40);
		field2.setBounds(600, 25, 200, 35);
		label.add(field2);
		frame.add(label);                            // Permet d'ajouter ce label � la fen�tre principale.

		// Permet d'afficher le nombre de tours

		JButton NombredeTours = new JButton("Nombre de tours");
		NombredeTours.setBounds(30, 650, 200, 35);
		label.add(NombredeTours);
		frame.add(label);// Permet d'ajouter ce label � la fen�tre principale.

		// Permet aux joueurs de choisir leur personnage

		JLabel label1 = new JLabel();
		label1.setAlignmentX(0);         // Permet de r�gler l'alignement vertical.
		label1.setAlignmentY(0);         // Permet de r�gler l'alignement horizontal.
		label.add(label1);
		frame.add(label);// Permet d'ajouter ce label � la fen�tre principale.

		// Permet � Mr Jack de piocher une carte Alibi

		JButton bouton4 = new JButton("Piocher");
		bouton4.setBounds(1500, 250, 175, 35);
		label.add(bouton4);
		frame.add(label);// Permet d'ajouter ce label � la fen�tre principale.
		bouton4.setVisible(false);

		bouton2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String nom = label1.getText();
				label1.setText("Vous avez choisi Mr Jack, veuillez piocher une carte Alibi");
				label1.setBounds(1150, 250, 700, 35);
				// TODO Auto-generated method stub
				bouton4.setVisible(true);// Permet de rendre cet �l�ment visible.
				//////// imageCarteAction

			}

		});
// APPEL A TEMOIN
		JLabel labelatm = new JLabel();
		labelatm.setAlignmentX(0);         // Permet de r�gler l'alignement vertical.
		labelatm.setAlignmentY(0);         // Permet de r�gler l'alignement horizontal.
		label.add(labelatm);
		frame.add(label);                  // Permet d'ajouter ce label � la fen�tre principale.
		
		JButton boutonappelatemoin = new JButton("Appel � t�moins");
		boutonappelatemoin.setBounds(1150, 750, 150, 25);
		label.add(boutonappelatemoin);
		frame.add(label);                  // Permet d'ajouter ce label � la fen�tre principale.
		boutonappelatemoin.setVisible(false);
		
		
		JButton atmoui = new JButton("Oui");
		atmoui.setBounds(1500, 780, 85, 20);
		label.add(atmoui);
		frame.add(label);                  // Permet d'ajouter ce label � la fen�tre principale.
		atmoui.setVisible(false);
		
		JButton atmnon = new JButton("Non");
		atmnon.setBounds(1600, 780, 85, 20);
		label.add(atmnon);
		frame.add(label);                  // Permet d'ajouter ce label � la fen�tre principale.
		atmnon.setVisible(false);
		
		// Indique au joueur la carte qu'il vient de piocher et indique que Sherlock
		// Holmes commence le tour

		JLabel label3 = new JLabel();
		label3.setAlignmentX(0);         // Permet de r�gler l'alignement vertical.
		label3.setAlignmentY(0);         // Permet de r�gler l'alignement horizontal.
		label.add(label3);
		frame.add(label);

		JButton boutonCartesAction = new JButton("Cartes Action");
		boutonCartesAction.setBounds(1500, 350, 175, 35);
		label.add(boutonCartesAction);
		// frame.add(label);
		boutonCartesAction.setVisible(false);

		bouton4.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				label3.getText();
				label3.setText("Vous avez piocher la carte ...");
				label3.setBounds(1150, 300, 200, 35);
				labelSherlockHolmesCom.getText();
				labelSherlockHolmesCom.setText("Sherlock commence le tour en piochant une carte Action");
				labelSherlockHolmesCom.setBounds(1150, 350, 700, 35);
				boutonCartesAction.setVisible(true);// Permet de rendre cet �l�ment visible.
				

				// TODO Auto-generated method stub

			}

		});

		/////////////// Carte action

		//////////////////////////////////////// PLACEMENT NON ALEATOIRE DES CARTES

		///// TUILES DE RUES

		// URL des images repr�sentants les tuiles de rues

		String InspLestrader = "InspLestrade-recto.png";             // Conversion de l'URL de l'image en chaine de caract�res.
		String JeremyBertr = "JeremyBert-recto.png";                 // Conversion de l'URL de l'image en chaine de caract�res.
		String JohnPizerr = "JohnPizer-recto.png";                   // Conversion de l'URL de l'image en chaine de caract�res.
		String JohnSmithr = "JohnSmith-recto.png";                   // Conversion de l'URL de l'image en chaine de caract�res.
		String JosephLaner = "JosephLane-recto.png";                 // Conversion de l'URL de l'image en chaine de caract�res.
		String Madamer = "Madame-rector.png";                        // Conversion de l'URL de l'image en chaine de caract�res.
		String MissStealthyr = "MissStealthy-recto.png";             // Conversion de l'URL de l'image en chaine de caract�res.
		String SgtGoodleyr = "SgtGoodley-recto.png";                 // Conversion de l'URL de l'image en chaine de caract�res.
		String WilliamGullr = "WilliamGull-recto.png";               // Conversion de l'URL de l'image en chaine de caract�res.
		String Rueverso="common-verso";                              // Conversion de l'URL de l'image en chaine de caract�res.
		String plateau = "plateau.jpg";                              // Conversion de l'URL de l'image en chaine de caract�res.

		ImageIcon iconeInspLestrader = new ImageIcon(InspLestrader); // Conversion de cette image en 'ImageIcon'.
		ImageIcon iconeJeremyBertr = new ImageIcon(JeremyBertr);     // Conversion de cette image en 'ImageIcon'.
		ImageIcon iconeJohnPizerr = new ImageIcon(JohnPizerr);       // Conversion de cette image en 'ImageIcon'.
		ImageIcon iconeJohnSmithr = new ImageIcon(JohnSmithr);       // Conversion de cette image en 'ImageIcon'.
		ImageIcon iconeJosephLaner = new ImageIcon(JosephLaner);     // Conversion de cette image en 'ImageIcon'.
		ImageIcon iconeMadamer = new ImageIcon(Madamer);             // Conversion de cette image en 'ImageIcon'.
		ImageIcon iconeMissStealthyr = new ImageIcon(MissStealthyr); // Conversion de cette image en 'ImageIcon'.
		ImageIcon iconeSgtGoodleyr = new ImageIcon(SgtGoodleyr);     // Conversion de cette image en 'ImageIcon'.
		ImageIcon iconeWilliamGullr = new ImageIcon(WilliamGullr);   // Conversion de cette image en 'ImageIcon'.
		ImageIcon iconeRueverso = new ImageIcon(Rueverso);           // Conversion de cette image en 'ImageIcon'.
		ImageIcon iconeplateau = new ImageIcon(plateau);             // Conversion de cette image en 'ImageIcon'.

		// Cr�ation de JLabel pour les tuiles

		JLabel image1 = new JLabel(iconeInspLestrader); // Cr�ation d'un label pour ins�rer cette image.
		image1.setBounds(375, 200, 200, 200);           // Permet de r�gler le positionnement et les dimensions de l'image.
	

		JLabel image2 = new JLabel(iconeJeremyBertr);
		image2.setBounds(600, 200, 200, 200);
	

		JLabel image3 = new JLabel(iconeJohnPizerr);
		image3.setBounds(825, 200, 200, 200);
		
		
		JLabel image4 = new JLabel(iconeJohnSmithr);
		image4.setBounds(375, 425, 200, 200);
		
		JLabel image5 = new JLabel(iconeJosephLaner);
		image5.setBounds(600, 425, 200, 200);
		

		JLabel image6 = new JLabel(iconeMadamer);
		image6.setBounds(825, 425, 200, 200);
		

		JLabel image7 = new JLabel(iconeMissStealthyr);
		image7.setBounds(375, 650, 200, 200);
		

		JLabel image8 = new JLabel(iconeSgtGoodleyr);
		image8.setBounds(600, 650, 200, 200);

		JLabel image9 = new JLabel(iconeWilliamGullr);
		image9.setBounds(825, 650, 200, 200);
		
		
		/*JLabel imageRueverso = new JLabel(iconeRueverso);
		imageRueverso.setBounds(825, 650, 200, 200);
		//frame.add(imageRueverso);
		//imageRueverso.setVisible(false);
		*/
		///// JETONS DETECTIVES

		// URL des images repr�sentantns les jetons d�tectives

		String Sherlock = "Sherlock.png";
		String Watson = "Watson.png";
		String Tobi = "Tobi.png";

		// Icones repr�setants les jetons d�tectives

		ImageIcon iconeSherlock = new ImageIcon(Sherlock);
		ImageIcon iconeWatson = new ImageIcon(Watson);
		ImageIcon iconeTobi = new ImageIcon(Tobi);

		// Cr�ation de JLabel pour les d�tectives

		JLabel image11 = new JLabel(iconeSherlock);
		image11.setBounds(380, 30, 200, 200);
		

		JLabel image12 = new JLabel(iconeWatson);
		image12.setBounds(1000, 675, 200, 200);
		
		
		JLabel image13 = new JLabel(iconeTobi);
		image13.setBounds(625, 875, 200, 200);
		
		
		JLabel image10 = new JLabel(plateau);
	
		
		// Cr�ation de boutons permettant de retourner les tuiles de rues lors de l'appek � t�moins.
		
		JButton Lestradeatm = new JButton("Lestrade");
		Lestradeatm.setBounds(1700, 780, 85, 15);
		label.add(Lestradeatm);
		Lestradeatm.setVisible(false);

		JButton JeremyBertatm = new JButton("Bert");
		JeremyBertatm.setBounds(1700, 795, 85, 15);
		label.add(JeremyBertatm);
		JeremyBertatm.setVisible(false);

		JButton Pizeratm = new JButton("Pizer");
		Pizeratm.setBounds(1700, 810, 85, 15);
		label.add(Pizeratm);
		Pizeratm.setVisible(false);

		JButton Smithatm = new JButton("Smith");
		Smithatm.setBounds(1700, 825, 85, 15);
		label.add(Smithatm);
		Smithatm.setVisible(false);

		JButton Laneatm = new JButton("Lane");
		Laneatm.setBounds(1700, 840, 85, 15);
		label.add(Laneatm);
		Laneatm.setVisible(false);

		JButton Madameatm = new JButton("Madame");
		Madameatm.setBounds(1700, 855, 85, 15);
		label.add(Madameatm);
		Madameatm.setVisible(false);

		JButton Stealthyatm = new JButton("Stealthy");
		Stealthyatm.setBounds(1700, 870, 85, 15);
		label.add(Stealthyatm);
		Stealthyatm.setVisible(false);

		JButton Gullatm = new JButton("Gull");
		Gullatm.setBounds(1700, 885, 85, 15);
		label.add(Gullatm);
		Gullatm.setVisible(false);
		
		/*
		Gullatm.addActionListener(new ActionListener() {
			@Override
				public void actionPerformed(ActionEvent e) {
				
				JLabel imageRueverso = new JLabel(iconeRueverso);
				imageRueverso.setBounds(825, 650, 200, 200);
				frame.add(imageRueverso);
				imageRueverso.setVisible(true);
				image9.setVisible(false);
				frame.add(image10);
			}});
*/
		JButton Goodleyatm = new JButton("Goodley");
		Goodleyatm.setBounds(1700, 900, 85, 15);
		label.add(Goodleyatm);
		Goodleyatm.setVisible(false);
		
		
		bouton1.addActionListener(new ActionListener() {
		@Override
			public void actionPerformed(ActionEvent e) {

			label2.getText();                                    // Permet d'afficher le texte du label.
			label2.setText("Veuillez choisir votre personnage"); // Permet d'�crire ce texte dans ce label.
			label2.setBounds(1150, 200, 200, 35);                // Permet de r�gler le positionnement et les dimensions de ce label.
			bouton2.setVisible(true);                            // Permet de rendre cet �l�ment visible.
			bouton3.setVisible(true);                            // Permet de rendre cet �l�ment visible.
				frame.add(image1);
				frame.add(image2);
				frame.add(image3);
				frame.add(image4);
				frame.add(image5);
				frame.add(image6);
				frame.add(image7);
				frame.add(image8);
				frame.add(image9);
				frame.add(image11);
				frame.add(image12);
				frame.add(image13);
				frame.add(image10);
				}
		});
		
		
		
		// APPEL A T�MOIN
		

		
		
		
		
		boutonappelatemoin.addActionListener(new ActionListener() {
		@Override
			public void actionPerformed(ActionEvent e) {

			labelatm.getText();
			labelatm.setText("Mr Jack est-il visible par l'un des d�tectives au moins ?");
			labelatm.setBounds(1150, 775, 500, 35);
			labelatm.setVisible(true); // Permet de rendre cet �l�ment visible.
			atmoui.setVisible(true);   // Permet de rendre cet �l�ment visible.
			atmnon.setVisible(true); 
		}});
		
		
		atmoui.addActionListener(new ActionListener() {
			@Override
				public void actionPerformed(ActionEvent e) {
				Lestradeatm.setVisible(true);   // Permet de rendre cet �l�ment visible. 
				JeremyBertatm.setVisible(true); // Permet de rendre cet �l�ment visible.
				Pizeratm.setVisible(true);      // Permet de rendre cet �l�ment visible.
				Smithatm.setVisible(true);      // Permet de rendre cet �l�ment visible.
				Laneatm.setVisible(true);       // Permet de rendre cet �l�ment visible.
				Madameatm.setVisible(true);     // Permet de rendre cet �l�ment visible.
				Stealthyatm.setVisible(true);   // Permet de rendre cet �l�ment visible.
				Gullatm.setVisible(true);       // Permet de rendre cet �l�ment visible.
				Goodleyatm.setVisible(true);    // Permet de rendre cet �l�ment visible.
			}
			});
		
		atmnon.addActionListener(new ActionListener() {
			@Override
				public void actionPerformed(ActionEvent e) {
				Lestradeatm.setVisible(true);
				JeremyBertatm.setVisible(true);
				Pizeratm.setVisible(true);
				Smithatm.setVisible(true);
				Laneatm.setVisible(true);
				Madameatm.setVisible(true);
				Stealthyatm.setVisible(true);
				Gullatm.setVisible(true);
				Goodleyatm.setVisible(true);
			}
			});
		
		
		 
		/*Gullatm.addActionListener(new ActionListener() {
			@Override
				public void actionPerformed(ActionEvent e) {
				
				JLabel imageRueverso = new JLabel(iconeRueverso);
				imageRueverso.setBounds(825, 650, 200, 200);
				frame.add(imageRueverso);
				imageRueverso.setVisible(true);
				image9.setVisible(false);
				frame.add(image10);
			}});*/
		///// CARTES ALIBI

		// URL des images repr�sentants les cartes Alibi

		String Alibiverso = "alibi-card.png";
		// Icones repr�setants les cartes Alibi

		ImageIcon iconeAlibiverso = new ImageIcon(Alibiverso);
		// Cr�ation de JLabel pour les cartes Alibi

		JLabel image14 = new JLabel(iconeAlibiverso);
		image14.setBounds(10, 10, 300, 300);
		frame.add(image14);

		///// JETONS TEMPS

		// URL des images repr�sentants les jetons temps

		String JetonTemps1 = "JetonTemps1.png";
		String JetonTemps2 = "JetonTemps2.png";
		String JetonTemps3 = "JetonTemps3.png";
		String JetonTemps4 = "JetonTemps4.png";
		String JetonTemps5 = "JetonTemps5.png";
		String JetonTemps6 = "JetonTemps6.png";
		String JetonTemps7 = "JetonTemps7.png";
		String JetonTemps8 = "JetonTemps8.png";
		String JetonTempsSablier = "JetonTempsSablier.png";

		// Icones repr�sentants les jetons temps

		ImageIcon iconeJetonTemps1 = new ImageIcon(JetonTemps1);
		ImageIcon iconeJetonTemps2 = new ImageIcon(JetonTemps2);
		ImageIcon iconeJetonTemps3 = new ImageIcon(JetonTemps3);
		ImageIcon iconeJetonTemps4 = new ImageIcon(JetonTemps4);
		ImageIcon iconeJetonTemps5 = new ImageIcon(JetonTemps5);
		ImageIcon iconeJetonTemps6 = new ImageIcon(JetonTemps6);
		ImageIcon iconeJetonTemps7 = new ImageIcon(JetonTemps7);
		ImageIcon iconeJetonTemps8 = new ImageIcon(JetonTemps8);
		ImageIcon iconeJetonTempsSablier = new ImageIcon(JetonTempsSablier);

		// Cr�ation de JLabel pour les jetons temps.

		JLabel imageJetonTemps1 = new JLabel(iconeJetonTemps1);
		imageJetonTemps1.setBounds(10, 800, 200, 200);
		frame.add(imageJetonTemps1);

		//////////////////// pas encore les bonnes images
		/*
		 * JLabel image16 = new JLabel(iconeJetonTemps2); image16.setBounds(10, 780,
		 * 200, 200); frame.add(image16);
		 * 
		 * JLabel image17 = new JLabel(iconeJetonTemps3); image17.setBounds(10, 760,
		 * 200, 200); frame.add(image17);
		 * 
		 * JLabel image18 = new JLabel(iconeJetonTemps4); image18.setBounds(10, 740,
		 * 200, 200); frame.add(image18);
		 * 
		 * JLabel image19 = new JLabel(iconeJetonTemps5); image19.setBounds(10, 720,
		 * 200, 200); frame.add(image19);
		 * 
		 * JLabel image20 = new JLabel(iconeJetonTemps6); image20.setBounds(10, 700,
		 * 200, 200); frame.add(image20);
		 * 
		 * JLabel image21 = new JLabel(iconeJetonTemps7); image21.setBounds(10, 680,
		 * 200, 200); frame.add(image21);
		 */
		///////////////////////////////

		JLabel imageJetonTemps8 = new JLabel(iconeJetonTemps8);
		imageJetonTemps8.setBounds(10, 690, 200, 200);
		frame.add(imageJetonTemps8);

		JLabel imageJetonTempsSablier = new JLabel(iconeJetonTempsSablier);
		imageJetonTempsSablier.setBounds(10, 640, 200, 200);
		frame.add(imageJetonTempsSablier);

		///// CARTES ACTIONS

		// URL des images repr�sentantns les cartes Action

		String ActionEchange = "Jeton1-Face1.png";
		String ActionRotation1 = "Jeton1-Face2.png";
		String ActionLeChien = "Jeton2-Face1.png";
		String ActionWatson = "Jeton2-Face2.png";
		String ActionSherlockHolmes = "Jeton3-Face1.png";
		String ActionAlibi = "Jeton3-Face2.png";
		String ActionJoker = "Jeton4-Face1.png";
		String ActionRotation2 = "Jeton4-Face2.png";

		// Icones repr�sentants les cartes Actions

		ImageIcon iconeActionEchange = new ImageIcon(ActionEchange);
		ImageIcon iconeActionRotation1 = new ImageIcon(ActionRotation1);
		ImageIcon iconeActionLeChien = new ImageIcon(ActionLeChien);
		ImageIcon iconeActionWatson = new ImageIcon(ActionWatson);
		ImageIcon iconeActionSherlockHolmes = new ImageIcon(ActionSherlockHolmes);
		ImageIcon iconeActionAlibi = new ImageIcon(ActionAlibi);
		ImageIcon iconeActionJoker = new ImageIcon(ActionJoker);
		ImageIcon iconeActionRotation2 = new ImageIcon(ActionRotation2);

		// JLabel pour les cartes Action

		JLabel imageActionEchange = new JLabel(iconeActionEchange);
		imageActionEchange.setBounds(1485, 400, 200, 200);
		frame.add(imageActionEchange);
		imageActionEchange.setVisible(false);

		JLabel labelActionEchange = new JLabel();
		labelActionEchange.setAlignmentX(0);         // Permet de r�gler l'alignement vertical.
		labelActionEchange.setAlignmentY(0);         // Permet de r�gler l'alignement horizontal.
		label.add(labelActionEchange);
		frame.add(label);

		JButton boutonActionEchange = new JButton("Echange");
		boutonActionEchange.setBounds(1550, 550, 85, 15);
		label.add(boutonActionEchange);
		boutonActionEchange.setVisible(false);

		JLabel imageActionRotation1 = new JLabel(iconeActionRotation1);
		imageActionRotation1.setBounds(1165, 400, 200, 200);
		frame.add(imageActionRotation1);
		imageActionRotation1.setVisible(false);

		JButton boutonActionRotation1 = new JButton("Rotation");
		boutonActionRotation1.setBounds(1225, 550, 85, 15);
		label.add(boutonActionRotation1);
		boutonActionRotation1.setVisible(false);

		JLabel imageActionLeChien = new JLabel(iconeActionLeChien);
		imageActionLeChien.setBounds(1240, 400, 200, 200);
		frame.add(imageActionLeChien);
		imageActionLeChien.setVisible(false);

		JButton boutonActionLeChien = new JButton("Tobi");
		boutonActionLeChien.setBounds(1300, 550, 85, 15);
		label.add(boutonActionLeChien);
		boutonActionLeChien.setVisible(false);

		JLabel imageActionWatson = new JLabel(iconeActionWatson);
		imageActionWatson.setBounds(1315, 400, 200, 200);
		frame.add(imageActionWatson);
		imageActionWatson.setVisible(false);

		JButton boutonActionWatson = new JButton("Watson");
		boutonActionWatson.setBounds(1375, 550, 85, 15);
		label.add(boutonActionWatson);
		boutonActionWatson.setVisible(false);

		JLabel imageActionSherlockHolmes = new JLabel(iconeActionSherlockHolmes);
		imageActionSherlockHolmes.setBounds(1410, 400, 200, 200);
		frame.add(imageActionSherlockHolmes);
		imageActionSherlockHolmes.setVisible(false);

		JButton boutonActionSherlockHolmes = new JButton("Sherlock Holmes");
		boutonActionSherlockHolmes.setBounds(1475, 550, 85, 15);
		label.add(boutonActionSherlockHolmes);
		boutonActionSherlockHolmes.setVisible(false);

		JLabel imageActionAlibi = new JLabel(iconeActionAlibi);
		imageActionAlibi.setBounds(1090, 400, 200, 200);
		frame.add(imageActionAlibi);
		imageActionAlibi.setVisible(false);

		JButton boutonActionAlibi = new JButton("Alibi");
		boutonActionAlibi.setBounds(1150, 550, 85, 15);
		label.add(boutonActionAlibi);
		boutonActionAlibi.setVisible(false);

		JLabel imageActionJoker = new JLabel(iconeActionJoker);
		imageActionJoker.setBounds(1560, 400, 200, 200);
		frame.add(imageActionJoker);
		imageActionJoker.setVisible(false);

		JButton boutonActionJoker = new JButton("Joker");
		boutonActionJoker.setBounds(1625, 550, 85, 15);
		label.add(boutonActionJoker);
		boutonActionJoker.setVisible(false);

		JLabel imageActionRotation2 = new JLabel(iconeActionRotation2);
		imageActionRotation2.setBounds(1635, 400, 200, 200);
		frame.add(imageActionRotation2);
		imageActionRotation2.setVisible(false);

		JButton boutonActionRotation2 = new JButton("Rotation");
		boutonActionRotation2.setBounds(1700, 550, 85, 15);
		label.add(boutonActionRotation2);
		boutonActionRotation2.setVisible(false);

		// Indique le num�ro du tour

		JLabel Tours1 = new JLabel();
		Tours1.setAlignmentX(0);         // Permet de r�gler l'alignement vertical.
		Tours1.setAlignmentY(0);         // Permet de r�gler l'alignement horizontal.
		label.add(Tours1);
		frame.add(label);

		JLabel Tours2 = new JLabel();
		Tours2.setAlignmentX(0);         // Permet de r�gler l'alignement vertical.
		Tours2.setAlignmentY(0);         // Permet de r�gler l'alignement horizontal.
		label.add(Tours2);
		frame.add(label);

		// Permet e passer aux deux tours suivants

		JButton ToursSuivants = new JButton("Tours suivants");
		ToursSuivants.setBounds(1780, 485, 125, 25);
		label.add(ToursSuivants);
		ToursSuivants.setVisible(false);
 
		// Permet d'afficher les cartes actions

		boutonCartesAction.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				imageActionEchange.setVisible(true);
				boutonActionEchange.setVisible(true);

				imageActionRotation1.setVisible(true);
				boutonActionRotation1.setVisible(true);

				imageActionLeChien.setVisible(true);
				boutonActionLeChien.setVisible(true);

				imageActionWatson.setVisible(true);
				boutonActionWatson.setVisible(true);

				imageActionSherlockHolmes.setVisible(true);
				boutonActionSherlockHolmes.setVisible(true);

				imageActionAlibi.setVisible(true);
				boutonActionAlibi.setVisible(true);

				imageActionJoker.setVisible(true);
				boutonActionJoker.setVisible(true);

				imageActionRotation2.setVisible(true);
				boutonActionRotation2.setVisible(true);

				Tours1.getText();
				Tours1.setText("Tour n�1");
				Tours1.setBounds(1150, 425, 300, 20);

				Tours2.getText();
				Tours2.setText("Tour n�2");
				Tours2.setBounds(1475, 425, 300, 20);

				ToursSuivants.setVisible(true);
				boutonappelatemoin.setVisible(true);
			}

		});

////////////////////////////////////////////////////////////////////////////////////////////////////////
		
// Boutons permettant de tourner les images vers la droite ou vers la gauche, d'un quartd e tours ou d'un demi-tours

		JButton QuartdeTourDroite = new JButton("1/4 D");
		QuartdeTourDroite.setBounds(1225, 580, 85, 15);
		label.add(QuartdeTourDroite);
		QuartdeTourDroite.setVisible(false);

		JButton DemiTourDroite = new JButton("1/2 Tour");
		DemiTourDroite.setBounds(1225, 595, 85, 15);
		label.add(DemiTourDroite);
		DemiTourDroite.setVisible(false);

		JButton QuartdeTourGauche = new JButton("1/4 G");
		QuartdeTourGauche.setBounds(1225, 610, 85, 15);
		label.add(QuartdeTourGauche);
		QuartdeTourGauche.setVisible(false);

		JButton Positioninitiale = new JButton("-");
		Positioninitiale.setBounds(1225, 625, 85, 15);
		label.add(Positioninitiale);
		Positioninitiale.setVisible(false);

		boutonActionRotation1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(true);
				DemiTourDroite.setVisible(true);
				QuartdeTourGauche.setVisible(true);
				Positioninitiale.setVisible(true);	}
		});

		JButton LestradeQD = new JButton("Lestrade");
		LestradeQD.setBounds(1225, 580, 85, 15);
		label.add(LestradeQD);
		LestradeQD.setVisible(false);

		JButton JeremyBertQD = new JButton("Bert");
		JeremyBertQD.setBounds(1225, 595, 85, 15);
		label.add(JeremyBertQD);
		JeremyBertQD.setVisible(false);

		JButton PizerQD = new JButton("Pizer");
		PizerQD.setBounds(1225, 610, 85, 15);
		label.add(PizerQD);
		PizerQD.setVisible(false);

		JButton SmithQD = new JButton("Smith");
		SmithQD.setBounds(1225, 625, 85, 15);
		label.add(SmithQD);
		SmithQD.setVisible(false);

		JButton LaneQD = new JButton("Lane");
		LaneQD.setBounds(1225, 640, 85, 15);
		label.add(LaneQD);
		LaneQD.setVisible(false);

		JButton MadameQD = new JButton("Madame");
		MadameQD.setBounds(1225, 655, 85, 15);
		label.add(MadameQD);
		MadameQD.setVisible(false);

		JButton StealthyQD = new JButton("Stealthy");
		StealthyQD.setBounds(1225, 670, 85, 15);
		label.add(StealthyQD);
		StealthyQD.setVisible(false);

		JButton GullQD = new JButton("Gull");
		GullQD.setBounds(1225, 685, 85, 15);
		label.add(GullQD);
		GullQD.setVisible(false);

		JButton GoodleyQD = new JButton("Goodley");
		GoodleyQD.setBounds(1225, 700, 85, 15);
		label.add(GoodleyQD);
		GoodleyQD.setVisible(false);

		QuartdeTourDroite.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQD.setVisible(true);
				JeremyBertQD.setVisible(true);
				PizerQD.setVisible(true);
				SmithQD.setVisible(true);
				LaneQD.setVisible(true);
				MadameQD.setVisible(true);
				StealthyQD.setVisible(true);
				GullQD.setVisible(true);
				GoodleyQD.setVisible(true);

			}
		});

		String LestraderQD = "LestraderQD-recto.png";
		ImageIcon iconeLestraderQD = new ImageIcon(LestraderQD);
		JLabel image1QD = new JLabel(iconeLestraderQD);
		image1QD.setBounds(375, 200, 200, 200);
		frame.add(image1QD);
		image1QD.setVisible(false);

		String JeremyBertrQD = "JeremyBertQD-recto.png";
		ImageIcon iconeJeremyBertrQD = new ImageIcon(JeremyBertrQD);
		JLabel image2QD = new JLabel(iconeJeremyBertrQD);
		image2QD.setBounds(600, 200, 200, 200);
		frame.add(image2QD);
		image2QD.setVisible(false);

		String PizerrQD = "JohnPizerrQD-recto.png";
		ImageIcon iconePizerrQD = new ImageIcon(PizerrQD);
		JLabel image3QD = new JLabel(iconePizerrQD);
		image3QD.setBounds(825, 200, 200, 200);
		frame.add(image3QD);
		image3QD.setVisible(false);

		String SmithrQD = "JohnSmithrQD-recto.png";
		ImageIcon iconeSmithrQD = new ImageIcon(SmithrQD);
		JLabel image4QD = new JLabel(iconeSmithrQD);
		image4QD.setBounds(375, 425, 200, 200);
		frame.add(image4QD);
		image4QD.setVisible(false);

		String LanerQD = "JosephLanerQD-recto.png";
		ImageIcon iconeLanerQD = new ImageIcon(LanerQD);
		JLabel image5QD = new JLabel(iconeLanerQD);
		image5QD.setBounds(600, 425, 200, 200);
		frame.add(image5QD);
		image5QD.setVisible(false);

		String MadamerQD = "MadamerQD-recto.png";
		ImageIcon iconeMadamerQD = new ImageIcon(MadamerQD);
		JLabel image6QD = new JLabel(iconeMadamerQD);
		image6QD.setBounds(825, 425, 200, 200);
		frame.add(image6QD);
		image6QD.setVisible(false);

		String StealthyrQD = "StealthyrQD-recto.png";
		ImageIcon iconeStealthyrQD = new ImageIcon(StealthyrQD);
		JLabel image7QD = new JLabel(iconeStealthyrQD);
		image7QD.setBounds(375, 650, 200, 200);
		frame.add(image7QD);
		image7QD.setVisible(false);

		String GoodleyrQD = "GoodleyrQD-recto.png";
		ImageIcon iconeGoodleyrQD = new ImageIcon(GoodleyrQD);
		JLabel image8QD = new JLabel(iconeGoodleyrQD);
		image8QD.setBounds(600, 650, 200, 200);
		frame.add(image8QD);
		image8QD.setVisible(false);

		String GullrQD = "GullrQD-recto.png";
		ImageIcon iconeGullrQD = new ImageIcon(GullrQD);
		JLabel image9QD = new JLabel(iconeGullrQD);
		image9QD.setBounds(825, 650, 200, 200);
		frame.add(image9QD);
		image9QD.setVisible(false);

		String LestraderDD = "LestraderDD-recto.png";
		ImageIcon iconeLestraderDD = new ImageIcon(LestraderDD);
		JLabel image1DD = new JLabel(iconeLestraderDD);
		image1DD.setBounds(375, 200, 200, 200);
		frame.add(image1DD);
		image1DD.setVisible(false);

		String JeremyBertrDD = "JeremyBertDD-recto.png";
		ImageIcon iconeJeremyBertrDD = new ImageIcon(JeremyBertrDD);
		JLabel image2DD = new JLabel(iconeJeremyBertrDD);
		image2DD.setBounds(600, 200, 200, 200);
		frame.add(image2DD);
		image2DD.setVisible(false);

		String PizerrDD = "JohnPizerrDD-recto.png";
		ImageIcon iconePizerrDD = new ImageIcon(PizerrDD);
		JLabel image3DD = new JLabel(iconePizerrDD);
		image3DD.setBounds(825, 200, 200, 200);
		frame.add(image3DD);
		image3DD.setVisible(false);

		String SmithrDD = "JohnSmithrDD-recto.png";
		ImageIcon iconeSmithrDD = new ImageIcon(SmithrDD);
		JLabel image4DD = new JLabel(iconeSmithrDD);
		image4DD.setBounds(375, 425, 200, 200);
		frame.add(image4DD);
		image4DD.setVisible(false);

		String LanerDD = "JosephLanerDD-recto.png";
		ImageIcon iconeLanerDD = new ImageIcon(LanerDD);
		JLabel image5DD = new JLabel(iconeLanerDD);
		image5DD.setBounds(600, 425, 200, 200);
		frame.add(image5DD);
		image5DD.setVisible(false);

		String MadamerDD = "MadamerDD-recto.png";
		ImageIcon iconeMadamerDD = new ImageIcon(MadamerDD);
		JLabel image6DD = new JLabel(iconeMadamerDD);
		image6DD.setBounds(825, 425, 200, 200);
		frame.add(image6DD);
		image6DD.setVisible(false);

		String StealthyrDD = "StealthyrDD-recto.png";
		ImageIcon iconeStealthyrDD = new ImageIcon(StealthyrDD);
		JLabel image7DD = new JLabel(iconeStealthyrDD);
		image7DD.setBounds(375, 650, 200, 200);
		frame.add(image7DD);
		image7DD.setVisible(false);

		String GoodleyrDD = "GoodleyrDD-recto.png";
		ImageIcon iconeGoodleyrDD = new ImageIcon(GoodleyrDD);
		JLabel image8DD = new JLabel(iconeGoodleyrDD);
		image8DD.setBounds(600, 650, 200, 200);
		frame.add(image8DD);
		image8DD.setVisible(false);

		String GullrDD = "GullrDD-recto.png";
		ImageIcon iconeGullrDD = new ImageIcon(GullrDD);
		JLabel image9DD = new JLabel(iconeGullrDD);
		image9DD.setBounds(825, 650, 200, 200);
		frame.add(image9DD);
		image9DD.setVisible(false);

		String LestraderQG = "LestraderQG-recto.png";
		ImageIcon iconeLestraderQG = new ImageIcon(LestraderQG);
		JLabel image1QG = new JLabel(iconeLestraderQG);
		image1QG.setBounds(375, 200, 200, 200);
		frame.add(image1QG);
		image1QG.setVisible(false);

		String JeremyBertrQG = "JeremyBertQG-recto.png";
		ImageIcon iconeJeremyBertrQG = new ImageIcon(JeremyBertrQG);
		JLabel image2QG = new JLabel(iconeJeremyBertrQG);
		image2QG.setBounds(600, 200, 200, 200);
		frame.add(image2QG);
		image2QG.setVisible(false);

		String PizerrQG = "JohnPizerrQG-recto.png";
		ImageIcon iconePizerrQG = new ImageIcon(PizerrQG);
		JLabel image3QG = new JLabel(iconePizerrQG);
		image3QG.setBounds(825, 200, 200, 200);
		frame.add(image3QG);
		image3QG.setVisible(false);

		String SmithrQG = "JohnSmithrQG-recto.png";
		ImageIcon iconeSmithrQG = new ImageIcon(SmithrQG);
		JLabel image4QG = new JLabel(iconeSmithrQG);
		image4QG.setBounds(375, 425, 200, 200);
		frame.add(image4QG);
		image4QG.setVisible(false);

		String LanerQG = "JosephLanerQG-recto.png";
		ImageIcon iconeLanerQG = new ImageIcon(LanerQG);
		JLabel image5QG = new JLabel(iconeLanerQG);
		image5QG.setBounds(600, 425, 200, 200);
		frame.add(image5QG);
		image5QG.setVisible(false);

		String MadamerQG = "MadamerQG-recto.png";
		ImageIcon iconeMadamerQG = new ImageIcon(MadamerQG);
		JLabel image6QG = new JLabel(iconeMadamerQG);
		image6QG.setBounds(825, 425, 200, 200);
		frame.add(image6QG);
		image6QG.setVisible(false);

		String StealthyrQG = "StealthyrQG-recto.png";
		ImageIcon iconeStealthyrQG = new ImageIcon(StealthyrQG);
		JLabel image7QG = new JLabel(iconeStealthyrQG);
		image7QG.setBounds(375, 650, 200, 200);
		frame.add(image7QG);
		image7QG.setVisible(false);

		String GoodleyrQG = "GoodleyrQG-recto.png";
		ImageIcon iconeGoodleyrQG = new ImageIcon(GoodleyrQG);
		JLabel image8QG = new JLabel(iconeGoodleyrQG);
		image8QG.setBounds(600, 650, 200, 200);
		frame.add(image8QG);
		image8QG.setVisible(false);

		String GullrQG = "GullrQG-recto.png";
		ImageIcon iconeGullrQG = new ImageIcon(GullrQG);
		JLabel image9QG = new JLabel(iconeGullrQG);
		image9QG.setBounds(825, 650, 200, 200);
		frame.add(image9QG);
		image9QG.setVisible(false);

		LestradeQD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQD.setVisible(false);
				JeremyBertQD.setVisible(false);
				PizerQD.setVisible(false);
				SmithQD.setVisible(false);
				LaneQD.setVisible(false);
				MadameQD.setVisible(false);
				StealthyQD.setVisible(false);
				GullQD.setVisible(false);
				GoodleyQD.setVisible(false);
				image1.setVisible(false);
				image1QD.setVisible(true);
				image1DD.setVisible(false);
				image1QG.setVisible(false);

			}
		});

		JeremyBertQD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQD.setVisible(false);
				JeremyBertQD.setVisible(false);
				PizerQD.setVisible(false);
				SmithQD.setVisible(false);
				LaneQD.setVisible(false);
				MadameQD.setVisible(false);
				StealthyQD.setVisible(false);
				GullQD.setVisible(false);
				GoodleyQD.setVisible(false);
				image2.setVisible(false);
				image2QD.setVisible(true);
				image2DD.setVisible(false);
				image2QG.setVisible(false);

			}
		});

		PizerQD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQD.setVisible(false);
				JeremyBertQD.setVisible(false);
				PizerQD.setVisible(false);
				SmithQD.setVisible(false);
				LaneQD.setVisible(false);
				MadameQD.setVisible(false);
				StealthyQD.setVisible(false);
				GullQD.setVisible(false);
				GoodleyQD.setVisible(false);
				image3.setVisible(false);
				image3QD.setVisible(true);
				image3DD.setVisible(false);
				image3QG.setVisible(false);

			}
		});

		SmithQD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQD.setVisible(false);
				JeremyBertQD.setVisible(false);
				PizerQD.setVisible(false);
				SmithQD.setVisible(false);
				LaneQD.setVisible(false);
				MadameQD.setVisible(false);
				StealthyQD.setVisible(false);
				GullQD.setVisible(false);
				GoodleyQD.setVisible(false);
				image4.setVisible(false);
				image4QD.setVisible(true);
				image4DD.setVisible(false);
				image4QG.setVisible(false);

			}
		});

		LaneQD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQD.setVisible(false);
				JeremyBertQD.setVisible(false);
				PizerQD.setVisible(false);
				SmithQD.setVisible(false);
				LaneQD.setVisible(false);
				MadameQD.setVisible(false);
				StealthyQD.setVisible(false);
				GullQD.setVisible(false);
				GoodleyQD.setVisible(false);
				image5.setVisible(false);
				image5QD.setVisible(true);
				image5DD.setVisible(false);
				image5QG.setVisible(false);
			}
		});

		MadameQD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQD.setVisible(false);
				JeremyBertQD.setVisible(false);
				PizerQD.setVisible(false);
				SmithQD.setVisible(false);
				LaneQD.setVisible(false);
				MadameQD.setVisible(false);
				StealthyQD.setVisible(false);
				GullQD.setVisible(false);
				GoodleyQD.setVisible(false);
				image6.setVisible(false);
				image6QD.setVisible(true);
				image6DD.setVisible(false);
				image6QG.setVisible(false);
			}
		});

		StealthyQD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQD.setVisible(false);
				JeremyBertQD.setVisible(false);
				PizerQD.setVisible(false);
				SmithQD.setVisible(false);
				LaneQD.setVisible(false);
				MadameQD.setVisible(false);
				StealthyQD.setVisible(false);
				GullQD.setVisible(false);
				GoodleyQD.setVisible(false);
				image7.setVisible(false);
				image7QD.setVisible(true);
				image7DD.setVisible(false);
				image7QG.setVisible(false);
			}
		});

		GoodleyQD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQD.setVisible(false);
				JeremyBertQD.setVisible(false);
				PizerQD.setVisible(false);
				SmithQD.setVisible(false);
				LaneQD.setVisible(false);
				MadameQD.setVisible(false);
				StealthyQD.setVisible(false);
				GullQD.setVisible(false);
				GoodleyQD.setVisible(false);
				image8.setVisible(false);
				image8QD.setVisible(true);
				image8DD.setVisible(false);
				image8QG.setVisible(false);

			}
		});

		GullQD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQD.setVisible(false);
				JeremyBertQD.setVisible(false);
				PizerQD.setVisible(false);
				SmithQD.setVisible(false);
				LaneQD.setVisible(false);
				MadameQD.setVisible(false);
				StealthyQD.setVisible(false);
				GullQD.setVisible(false);
				GoodleyQD.setVisible(false);
				image9.setVisible(false);
				image9QD.setVisible(true);
				image9DD.setVisible(false);
				image9QG.setVisible(false);

			}
		});

		JButton LestradeDD = new JButton("Lestrade");
		LestradeDD.setBounds(1225, 580, 85, 15);
		label.add(LestradeDD);
		LestradeDD.setVisible(false);

		JButton JeremyBertDD = new JButton("Bert");
		JeremyBertDD.setBounds(1225, 595, 85, 15);
		label.add(JeremyBertDD);
		JeremyBertDD.setVisible(false);

		JButton PizerDD = new JButton("Pizer");
		PizerDD.setBounds(1225, 610, 85, 15);
		label.add(PizerDD);
		PizerDD.setVisible(false);

		JButton SmithDD = new JButton("Smith");
		SmithDD.setBounds(1225, 625, 85, 15);
		label.add(SmithDD);
		SmithDD.setVisible(false);

		JButton LaneDD = new JButton("Lane");
		LaneDD.setBounds(1225, 640, 85, 15);
		label.add(LaneDD);
		LaneDD.setVisible(false);

		JButton MadameDD = new JButton("Madame");
		MadameDD.setBounds(1225, 655, 85, 15);
		label.add(MadameDD);
		MadameDD.setVisible(false);

		JButton StealthyDD = new JButton("Stealthy");
		StealthyDD.setBounds(1225, 670, 85, 15);
		label.add(StealthyDD);
		StealthyDD.setVisible(false);

		JButton GullDD = new JButton("Gull");
		GullDD.setBounds(1225, 685, 85, 15);
		label.add(GullDD);
		GullDD.setVisible(false);

		JButton GoodleyDD = new JButton("Goodley");
		GoodleyDD.setBounds(1225, 700, 85, 15);
		label.add(GoodleyDD);
		GoodleyDD.setVisible(false);

		DemiTourDroite.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeDD.setVisible(true);
				JeremyBertDD.setVisible(true);
				PizerDD.setVisible(true);
				SmithDD.setVisible(true);
				LaneDD.setVisible(true);
				MadameDD.setVisible(true);
				StealthyDD.setVisible(true);
				GullDD.setVisible(true);
				GoodleyDD.setVisible(true);

			}
		});

		LestradeDD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeDD.setVisible(false);
				JeremyBertDD.setVisible(false);
				PizerDD.setVisible(false);
				SmithDD.setVisible(false);
				LaneDD.setVisible(false);
				MadameDD.setVisible(false);
				StealthyDD.setVisible(false);
				GullDD.setVisible(false);
				GoodleyDD.setVisible(false);

				image1QD.setVisible(false);
				image1DD.setVisible(true);
				image1QG.setVisible(false);
				image1.setVisible(false);

			}
		});

		JeremyBertDD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeDD.setVisible(false);
				JeremyBertDD.setVisible(false);
				PizerDD.setVisible(false);
				SmithDD.setVisible(false);
				LaneDD.setVisible(false);
				MadameDD.setVisible(false);
				StealthyDD.setVisible(false);
				GullDD.setVisible(false);
				GoodleyDD.setVisible(false);
				image2.setVisible(false);
				image2QD.setVisible(false);
				image2DD.setVisible(true);
				image2QG.setVisible(false);

			}
		});

		PizerDD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeDD.setVisible(false);
				JeremyBertDD.setVisible(false);
				PizerDD.setVisible(false);
				SmithDD.setVisible(false);
				LaneDD.setVisible(false);
				MadameDD.setVisible(false);
				StealthyDD.setVisible(false);
				GullDD.setVisible(false);
				GoodleyDD.setVisible(false);
				image3.setVisible(false);
				image3QD.setVisible(false);
				image3DD.setVisible(true);
				image3QG.setVisible(false);
			}
		});

		SmithDD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeDD.setVisible(false);
				JeremyBertDD.setVisible(false);
				PizerDD.setVisible(false);
				SmithDD.setVisible(false);
				LaneDD.setVisible(false);
				MadameDD.setVisible(false);
				StealthyDD.setVisible(false);
				GullDD.setVisible(false);
				GoodleyDD.setVisible(false);
				image4.setVisible(false);
				image4QD.setVisible(false);
				image4DD.setVisible(true);
				image4QG.setVisible(false);

			}
		});

		LaneDD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeDD.setVisible(false);
				JeremyBertDD.setVisible(false);
				PizerDD.setVisible(false);
				SmithDD.setVisible(false);
				LaneDD.setVisible(false);
				MadameDD.setVisible(false);
				StealthyDD.setVisible(false);
				GullDD.setVisible(false);
				GoodleyDD.setVisible(false);
				image5.setVisible(false);
				image5QD.setVisible(false);
				image5DD.setVisible(true);
				image5QG.setVisible(false);
			}
		});

		MadameDD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeDD.setVisible(false);
				JeremyBertDD.setVisible(false);
				PizerDD.setVisible(false);
				SmithDD.setVisible(false);
				LaneDD.setVisible(false);
				MadameDD.setVisible(false);
				StealthyDD.setVisible(false);
				GullDD.setVisible(false);
				GoodleyDD.setVisible(false);

				image6.setVisible(false);
				image6QD.setVisible(false);

				image6DD.setVisible(true);
				image6QG.setVisible(false);
			}
		});

		StealthyDD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeDD.setVisible(false);
				JeremyBertDD.setVisible(false);
				PizerDD.setVisible(false);
				SmithDD.setVisible(false);
				LaneDD.setVisible(false);
				MadameDD.setVisible(false);
				StealthyDD.setVisible(false);
				GullDD.setVisible(false);
				GoodleyDD.setVisible(false);
				image7.setVisible(false);
				image7QD.setVisible(false);

				image7DD.setVisible(true);
				image7QG.setVisible(false);

			}
		});

		GoodleyDD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeDD.setVisible(false);
				JeremyBertDD.setVisible(false);
				PizerDD.setVisible(false);
				SmithDD.setVisible(false);
				LaneDD.setVisible(false);
				MadameDD.setVisible(false);
				StealthyDD.setVisible(false);
				GullDD.setVisible(false);
				GoodleyDD.setVisible(false);
				image8.setVisible(false);
				image8QD.setVisible(false);
				image8DD.setVisible(true);
				image8QG.setVisible(false);
				image8QG.setVisible(false);

			}
		});

		GullDD.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeDD.setVisible(false);
				JeremyBertDD.setVisible(false);
				PizerDD.setVisible(false);
				SmithDD.setVisible(false);
				LaneDD.setVisible(false);
				MadameDD.setVisible(false);
				StealthyDD.setVisible(false);
				GullDD.setVisible(false);
				GoodleyDD.setVisible(false);

				image9QD.setVisible(false);
				image9DD.setVisible(true);
				image9QG.setVisible(false);
				image9.setVisible(false);

			}
		});

		JButton LestradeQG = new JButton("Lestrade");
		LestradeQG.setBounds(1225, 580, 85, 15);
		label.add(LestradeQG);
		LestradeQG.setVisible(false);

		JButton JeremyBertQG = new JButton("Bert");
		JeremyBertQG.setBounds(1225, 595, 85, 15);
		label.add(JeremyBertQG);
		JeremyBertQG.setVisible(false);

		JButton PizerQG = new JButton("Pizer");
		PizerQG.setBounds(1225, 610, 85, 15);
		label.add(PizerQG);
		PizerQG.setVisible(false);

		JButton SmithQG = new JButton("Smith");
		SmithQG.setBounds(1225, 625, 85, 15);
		label.add(SmithQG);
		SmithQG.setVisible(false);

		JButton LaneQG = new JButton("Lane");
		LaneQG.setBounds(1225, 640, 85, 15);
		label.add(LaneQG);
		LaneQG.setVisible(false);

		JButton MadameQG = new JButton("Madame");
		MadameQG.setBounds(1225, 655, 85, 15);
		label.add(MadameQG);
		MadameQG.setVisible(false);

		JButton StealthyQG = new JButton("Stealthy");
		StealthyQG.setBounds(1225, 670, 85, 15);
		label.add(StealthyQG);
		StealthyQG.setVisible(false);

		JButton GullQG = new JButton("Gull");
		GullQG.setBounds(1225, 685, 85, 15);
		label.add(GullQG);
		GullQG.setVisible(false);

		JButton GoodleyQG = new JButton("Goodley");
		GoodleyQG.setBounds(1225, 700, 85, 15);
		label.add(GoodleyQG);
		GoodleyQG.setVisible(false);

		QuartdeTourGauche.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQG.setVisible(true);
				JeremyBertQG.setVisible(true);
				PizerQG.setVisible(true);
				SmithQG.setVisible(true);
				LaneQG.setVisible(true);
				MadameQG.setVisible(true);
				StealthyQG.setVisible(true);
				GullQG.setVisible(true);
				GoodleyQG.setVisible(true);

			}
		});

		LestradeQG.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQG.setVisible(false);
				JeremyBertQG.setVisible(false);
				PizerQG.setVisible(false);
				SmithQG.setVisible(false);
				LaneQG.setVisible(false);
				MadameQG.setVisible(false);
				StealthyQG.setVisible(false);
				GullQG.setVisible(false);
				GoodleyQG.setVisible(false);

				image1QD.setVisible(false);
				image1DD.setVisible(false);
				image1QG.setVisible(true);
				image1.setVisible(false);

			}
		});

		JeremyBertQG.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQG.setVisible(false);
				JeremyBertQG.setVisible(false);
				PizerQG.setVisible(false);
				SmithQG.setVisible(false);
				LaneQG.setVisible(false);
				MadameQG.setVisible(false);
				StealthyQG.setVisible(false);
				GullQG.setVisible(false);
				GoodleyQG.setVisible(false);
				image2.setVisible(false);
				image2QD.setVisible(false);
				image2DD.setVisible(false);
				image2QG.setVisible(true);

			}
		});

		PizerQG.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQG.setVisible(false);
				JeremyBertQG.setVisible(false);
				PizerQG.setVisible(false);
				SmithQG.setVisible(false);
				LaneQG.setVisible(false);
				MadameQG.setVisible(false);
				StealthyQG.setVisible(false);
				GullQG.setVisible(false);
				GoodleyQG.setVisible(false);
				image3.setVisible(false);
				image3QD.setVisible(false);
				image3DD.setVisible(false);
				image3QG.setVisible(true);

			}
		});

		SmithQG.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQG.setVisible(false);
				JeremyBertQG.setVisible(false);
				PizerQG.setVisible(false);
				SmithQG.setVisible(false);
				LaneQG.setVisible(false);
				MadameQG.setVisible(false);
				StealthyQG.setVisible(false);
				GullQG.setVisible(false);
				GoodleyQG.setVisible(false);
				image4.setVisible(false);
				image4QD.setVisible(false);
				image4DD.setVisible(false);
				image4QG.setVisible(true);

			}
		});

		LaneQG.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQG.setVisible(false);
				JeremyBertQG.setVisible(false);
				PizerQG.setVisible(false);
				SmithQG.setVisible(false);
				LaneQG.setVisible(false);
				MadameQG.setVisible(false);
				StealthyQG.setVisible(false);
				GullQG.setVisible(false);
				GoodleyQG.setVisible(false);
				image5.setVisible(false);
				image5QD.setVisible(false);
				image5DD.setVisible(false);
				image5QG.setVisible(true);

			}
		});

		MadameQG.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQG.setVisible(false);
				JeremyBertQG.setVisible(false);
				PizerQG.setVisible(false);
				SmithQG.setVisible(false);
				LaneQG.setVisible(false);
				MadameQG.setVisible(false);
				StealthyQG.setVisible(false);
				GullQG.setVisible(false);
				GoodleyQG.setVisible(false);
				image6.setVisible(false);
				image6QD.setVisible(false);
				image6DD.setVisible(false);
				image6QG.setVisible(true);

			}
		});

		StealthyQG.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQG.setVisible(false);
				JeremyBertQG.setVisible(false);
				PizerQG.setVisible(false);
				SmithQG.setVisible(false);
				LaneQG.setVisible(false);
				MadameQG.setVisible(false);
				StealthyQG.setVisible(false);
				GullQG.setVisible(false);
				GoodleyQG.setVisible(false);
				image7.setVisible(false);
				image7QD.setVisible(false);
				image7DD.setVisible(false);
				image7QG.setVisible(true);

			}
		});

		GoodleyQG.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQG.setVisible(false);
				JeremyBertQG.setVisible(false);
				PizerQG.setVisible(false);
				SmithQG.setVisible(false);
				LaneQG.setVisible(false);
				MadameQG.setVisible(false);
				StealthyQG.setVisible(false);
				GullQG.setVisible(false);
				GoodleyQG.setVisible(false);
				image8.setVisible(false);
				image8QD.setVisible(false);
				image8DD.setVisible(false);
				image8QG.setVisible(true);

			}
		});

		GullQG.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradeQG.setVisible(false);
				JeremyBertQG.setVisible(false);
				PizerQG.setVisible(false);
				SmithQG.setVisible(false);
				LaneQG.setVisible(false);
				MadameQG.setVisible(false);
				StealthyQG.setVisible(false);
				GullQG.setVisible(false);
				GoodleyQG.setVisible(false);

				image9QD.setVisible(false);
				image9DD.setVisible(false);
				image9QG.setVisible(true);
				image9.setVisible(false);

			}
		});

		JButton LestradePI = new JButton("Lestrade");
		LestradePI.setBounds(1225, 580, 85, 15);
		label.add(LestradePI);
		LestradePI.setVisible(false);

		JButton JeremyBertPI = new JButton("Bert");
		JeremyBertPI.setBounds(1225, 595, 85, 15);
		label.add(JeremyBertPI);
		JeremyBertPI.setVisible(false);

		JButton PizerPI = new JButton("Pizer");
		PizerPI.setBounds(1225, 610, 85, 15);
		label.add(PizerPI);
		PizerPI.setVisible(false);

		JButton SmithPI = new JButton("Smith");
		SmithPI.setBounds(1225, 625, 85, 15);
		label.add(SmithPI);
		SmithPI.setVisible(false);

		JButton LanePI = new JButton("Lane");
		LanePI.setBounds(1225, 640, 85, 15);
		label.add(LanePI);
		LanePI.setVisible(false);

		JButton MadamePI = new JButton("Madame");
		MadamePI.setBounds(1225, 655, 85, 15);
		label.add(MadamePI);
		MadamePI.setVisible(false);

		JButton StealthyPI = new JButton("Stealthy");
		StealthyPI.setBounds(1225, 670, 85, 15);
		label.add(StealthyPI);
		StealthyPI.setVisible(false);

		JButton GullPI = new JButton("Gull");
		GullPI.setBounds(1225, 685, 85, 15);
		label.add(GullPI);
		GullPI.setVisible(false);

		JButton GoodleyPI = new JButton("Goodley");
		GoodleyPI.setBounds(1225, 700, 85, 15);
		label.add(GoodleyPI);
		GoodleyPI.setVisible(false);

		Positioninitiale.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradePI.setVisible(true);
				JeremyBertPI.setVisible(true);
				PizerPI.setVisible(true);
				SmithPI.setVisible(true);
				LanePI.setVisible(true);
				MadamePI.setVisible(true);
				StealthyPI.setVisible(true);
				GullPI.setVisible(true);
				GoodleyPI.setVisible(true);

			}
		});

		LestradePI.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradePI.setVisible(false);
				JeremyBertPI.setVisible(false);
				PizerPI.setVisible(false);
				SmithPI.setVisible(false);
				LanePI.setVisible(false);
				MadamePI.setVisible(false);
				StealthyPI.setVisible(false);
				GullPI.setVisible(false);
				GoodleyPI.setVisible(false);

				image1QD.setVisible(false);
				image1DD.setVisible(false);
				image1QG.setVisible(false);
				image1.setVisible(true);

			}
		});
		JeremyBertPI.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradePI.setVisible(false);
				JeremyBertPI.setVisible(false);
				PizerPI.setVisible(false);
				SmithPI.setVisible(false);
				LanePI.setVisible(false);
				MadamePI.setVisible(false);
				StealthyPI.setVisible(false);
				GullPI.setVisible(false);
				GoodleyPI.setVisible(false);

				image2QD.setVisible(false);
				image2DD.setVisible(false);
				image2QG.setVisible(false);
				image2.setVisible(true);

			}
		});

		PizerPI.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradePI.setVisible(false);
				JeremyBertPI.setVisible(false);
				PizerPI.setVisible(false);
				SmithPI.setVisible(false);
				LanePI.setVisible(false);
				MadamePI.setVisible(false);
				StealthyPI.setVisible(false);
				GullPI.setVisible(false);
				GoodleyPI.setVisible(false);
				image3.setVisible(true);
				image3QD.setVisible(false);
				image3DD.setVisible(false);
				image3QG.setVisible(false);

			}
		});

		SmithPI.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradePI.setVisible(false);
				JeremyBertPI.setVisible(false);
				PizerPI.setVisible(false);
				SmithPI.setVisible(false);
				LanePI.setVisible(false);
				MadamePI.setVisible(false);
				StealthyPI.setVisible(false);
				GullPI.setVisible(false);
				GoodleyPI.setVisible(false);
				image4.setVisible(true);
				image4QD.setVisible(false);
				image4DD.setVisible(false);
				image4QG.setVisible(false);

			}
		});

		LanePI.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradePI.setVisible(false);
				JeremyBertPI.setVisible(false);
				PizerPI.setVisible(false);
				SmithPI.setVisible(false);
				LanePI.setVisible(false);
				MadamePI.setVisible(false);
				StealthyPI.setVisible(false);
				GullPI.setVisible(false);
				GoodleyPI.setVisible(false);
				image5.setVisible(true);
				image5QD.setVisible(false);
				image5DD.setVisible(false);
				image5QG.setVisible(false);

			}
		});

		MadamePI.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradePI.setVisible(false);
				JeremyBertPI.setVisible(false);
				PizerPI.setVisible(false);
				SmithPI.setVisible(false);
				LanePI.setVisible(false);
				MadamePI.setVisible(false);
				StealthyPI.setVisible(false);
				GullPI.setVisible(false);
				GoodleyPI.setVisible(false);
				image6.setVisible(true);
				image6QD.setVisible(false);
				image6DD.setVisible(false);
				image6QG.setVisible(false);

			}
		});

		StealthyPI.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradePI.setVisible(false);
				JeremyBertPI.setVisible(false);
				PizerPI.setVisible(false);
				SmithPI.setVisible(false);
				LanePI.setVisible(false);
				MadamePI.setVisible(false);
				StealthyPI.setVisible(false);
				GullPI.setVisible(false);
				GoodleyPI.setVisible(false);
				image7.setVisible(true);
				image7QD.setVisible(false);
				image7DD.setVisible(false);
				image7QG.setVisible(false);

			}
		});

		GoodleyPI.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradePI.setVisible(false);
				JeremyBertPI.setVisible(false);
				PizerPI.setVisible(false);
				SmithPI.setVisible(false);
				LanePI.setVisible(false);
				MadamePI.setVisible(false);
				StealthyPI.setVisible(false);
				GullPI.setVisible(false);
				GoodleyPI.setVisible(false);
				image8.setVisible(true);
				image8QD.setVisible(false);
				image8DD.setVisible(false);
				image8QG.setVisible(false);

			}
		});

		GullPI.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroite.setVisible(false);
				DemiTourDroite.setVisible(false);
				QuartdeTourGauche.setVisible(false);
				Positioninitiale.setVisible(false);
				LestradePI.setVisible(false);
				JeremyBertPI.setVisible(false);
				PizerPI.setVisible(false);
				SmithPI.setVisible(false);
				LanePI.setVisible(false);
				MadamePI.setVisible(false);
				StealthyPI.setVisible(false);
				GullPI.setVisible(false);
				GoodleyPI.setVisible(false);

				image9QD.setVisible(false);
				image9DD.setVisible(false);
				image9QG.setVisible(false);
				image9.setVisible(true);

			}
		});
////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////Boutons permettant d'echanger les tuiles de rues de place /////////////////////////

		// Definit la position des d�tectives sur le plateau de jeu de 1 � 12

		// Deplacement de Tobi

		JLabel positionDetective1 = new JLabel("Position n�1");
		positionDetective1.getText();
		positionDetective1.setText("1");
		positionDetective1.setBounds(470, 175, 100, 15);
		label.add(positionDetective1);
		frame.add(label);

		JLabel positionDetective2 = new JLabel("Position n�2");
		positionDetective2.getText();
		positionDetective2.setText("2");
		positionDetective2.setBounds(695, 175, 100, 15);
		label.add(positionDetective2);
		frame.add(label);

		JLabel positionDetective3 = new JLabel("Position n�3");
		positionDetective3.getText();
		positionDetective3.setText("3");
		positionDetective3.setBounds(920, 175, 100, 15);
		label.add(positionDetective3);
		frame.add(label);

		JLabel positionDetective4 = new JLabel("Position n�4");
		positionDetective4.getText();
		positionDetective4.setText("4");
		positionDetective4.setBounds(1040, 295, 100, 15);
		label.add(positionDetective4);
		frame.add(label);

		JLabel positionDetective5 = new JLabel("Position n�5");
		positionDetective5.getText();
		positionDetective5.setText("5");
		positionDetective5.setBounds(1040, 520, 100, 15);
		label.add(positionDetective5);
		frame.add(label);

		JLabel positionDetective6 = new JLabel("Position n�6");
		positionDetective6.getText();
		positionDetective6.setText("6");
		positionDetective6.setBounds(1040, 745, 100, 15);
		label.add(positionDetective6);
		frame.add(label);

		JLabel positionDetective7 = new JLabel("Position n�7");
		positionDetective7.getText();
		positionDetective7.setText("7");
		positionDetective7.setBounds(920, 865, 100, 15);
		label.add(positionDetective7);
		frame.add(label);

		JLabel positionDetective8 = new JLabel("Position n�8");
		positionDetective8.getText();
		positionDetective8.setText("8");
		positionDetective8.setBounds(695, 865, 100, 15);
		label.add(positionDetective8);
		frame.add(label);

		JLabel positionDetective9 = new JLabel("Position n�9");
		positionDetective9.getText();
		positionDetective9.setText("9");
		positionDetective9.setBounds(470, 865, 100, 15);
		label.add(positionDetective9);
		frame.add(label);

		JLabel positionDetective10 = new JLabel("Position n�10");
		positionDetective10.getText();
		positionDetective10.setText("10");
		positionDetective10.setBounds(345, 745, 100, 15);
		label.add(positionDetective10);
		frame.add(label);

		JLabel positionDetective11 = new JLabel("Position n�11");
		positionDetective11.getText();
		positionDetective11.setText("11");
		positionDetective11.setBounds(345, 520, 100, 15);
		label.add(positionDetective11);
		frame.add(label);

		JLabel positionDetective12 = new JLabel("Position n�12");
		positionDetective12.getText();
		positionDetective12.setText("12");
		positionDetective12.setBounds(345, 295, 100, 15);
		label.add(positionDetective12);
		frame.add(label);

		JButton Position1 = new JButton("1");
		Position1.setBounds(1300, 580, 85, 15);
		label.add(Position1);
		Position1.setVisible(false);

		JButton Position2 = new JButton("2");
		Position2.setBounds(1300, 595, 85, 15);
		label.add(Position2);
		Position2.setVisible(false);

		JButton Position3 = new JButton("3");
		Position3.setBounds(1300, 610, 85, 15);
		label.add(Position3);
		Position3.setVisible(false);

		JButton Position4 = new JButton("4");
		Position4.setBounds(1300, 625, 85, 15);
		label.add(Position4);
		Position4.setVisible(false);

		JButton Position5 = new JButton("5");
		Position5.setBounds(1300, 640, 85, 15);
		label.add(Position5);
		Position5.setVisible(false);

		JButton Position6 = new JButton("6");
		Position6.setBounds(1300, 655, 85, 15);
		label.add(Position6);
		Position6.setVisible(false);

		JButton Position7 = new JButton("7");
		Position7.setBounds(1300, 670, 85, 15);
		label.add(Position7);
		Position7.setVisible(false);

		JButton Position8 = new JButton("8");
		Position8.setBounds(1300, 685, 85, 15);
		label.add(Position8);
		Position8.setVisible(false);

		JButton Position9 = new JButton("9");
		Position9.setBounds(1300, 700, 85, 15);
		label.add(Position9);
		Position9.setVisible(false);

		JButton Position10 = new JButton("10");
		Position10.setBounds(1300, 715, 85, 15);
		label.add(Position10);
		Position10.setVisible(false);

		JButton Position11 = new JButton("11");
		Position11.setBounds(1300, 730, 85, 15);
		label.add(Position11);
		Position11.setVisible(false);

		JButton Position12 = new JButton("12");
		Position12.setBounds(1300, 745, 85, 15);
		label.add(Position12);
		Position12.setVisible(false);

		boutonActionLeChien.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1.setVisible(true);
				Position2.setVisible(true);
				Position3.setVisible(true);
				Position4.setVisible(true);
				Position5.setVisible(true);
				Position6.setVisible(true);
				Position7.setVisible(true);
				Position8.setVisible(true);
				Position9.setVisible(true);
				Position10.setVisible(true);
				Position11.setVisible(true);
				Position12.setVisible(true);
			}

		});

		Position1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1.setVisible(false);
				Position2.setVisible(false);
				Position3.setVisible(false);
				Position4.setVisible(false);
				Position5.setVisible(false);
				Position6.setVisible(false);
				Position7.setVisible(false);
				Position8.setVisible(false);
				Position9.setVisible(false);
				Position10.setVisible(false);
				Position11.setVisible(false);
				Position12.setVisible(false);
				image13.setBounds(300, 30, 200, 200);

			}
		});
		Position2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1.setVisible(false);
				Position2.setVisible(false);
				Position3.setVisible(false);
				Position4.setVisible(false);
				Position5.setVisible(false);
				Position6.setVisible(false);
				Position7.setVisible(false);
				Position8.setVisible(false);
				Position9.setVisible(false);
				Position10.setVisible(false);
				Position11.setVisible(false);
				Position12.setVisible(false);
				image13.setBounds(600, 30, 200, 200);

			}
		});
		Position3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1.setVisible(false);
				Position2.setVisible(false);
				Position3.setVisible(false);
				Position4.setVisible(false);
				Position5.setVisible(false);
				Position6.setVisible(false);
				Position7.setVisible(false);
				Position8.setVisible(false);
				Position9.setVisible(false);
				Position10.setVisible(false);
				Position11.setVisible(false);
				Position12.setVisible(false);
				image13.setBounds(780, 30, 200, 200);

			}
		});
		Position4.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1.setVisible(false);
				Position2.setVisible(false);
				Position3.setVisible(false);
				Position4.setVisible(false);
				Position5.setVisible(false);
				Position6.setVisible(false);
				Position7.setVisible(false);
				Position8.setVisible(false);
				Position9.setVisible(false);
				Position10.setVisible(false);
				Position11.setVisible(false);
				Position12.setVisible(false);
				image13.setBounds(1000, 260, 200, 200);

			}
		});
		Position5.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1.setVisible(false);
				Position2.setVisible(false);
				Position3.setVisible(false);
				Position4.setVisible(false);
				Position5.setVisible(false);
				Position6.setVisible(false);
				Position7.setVisible(false);
				Position8.setVisible(false);
				Position9.setVisible(false);
				Position10.setVisible(false);
				Position11.setVisible(false);
				Position12.setVisible(false);
				image13.setBounds(1000, 460, 200, 200);

			}
		});
		Position6.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1.setVisible(false);
				Position2.setVisible(false);
				Position3.setVisible(false);
				Position4.setVisible(false);
				Position5.setVisible(false);
				Position6.setVisible(false);
				Position7.setVisible(false);
				Position8.setVisible(false);
				Position9.setVisible(false);
				Position10.setVisible(false);
				Position11.setVisible(false);
				Position12.setVisible(false);
				image13.setBounds(1000, 645, 200, 200);

			}
		});
		Position7.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1.setVisible(false);
				Position2.setVisible(false);
				Position3.setVisible(false);
				Position4.setVisible(false);
				Position5.setVisible(false);
				Position6.setVisible(false);
				Position7.setVisible(false);
				Position8.setVisible(false);
				Position9.setVisible(false);
				Position10.setVisible(false);
				Position11.setVisible(false);
				Position12.setVisible(false);
				image13.setBounds(780, 820, 200, 200);

			}
		});
		Position8.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1.setVisible(false);
				Position2.setVisible(false);
				Position3.setVisible(false);
				Position4.setVisible(false);
				Position5.setVisible(false);
				Position6.setVisible(false);
				Position7.setVisible(false);
				Position8.setVisible(false);
				Position9.setVisible(false);
				Position10.setVisible(false);
				Position11.setVisible(false);
				Position12.setVisible(false);
				image13.setBounds(600, 820, 200, 200);

			}
		});
		Position9.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1.setVisible(false);
				Position2.setVisible(false);
				Position3.setVisible(false);
				Position4.setVisible(false);
				Position5.setVisible(false);
				Position6.setVisible(false);
				Position7.setVisible(false);
				Position8.setVisible(false);
				Position9.setVisible(false);
				Position10.setVisible(false);
				Position11.setVisible(false);
				Position12.setVisible(false);
				image13.setBounds(340, 820, 200, 200);

			}
		});
		Position10.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1.setVisible(false);
				Position2.setVisible(false);
				Position3.setVisible(false);
				Position4.setVisible(false);
				Position5.setVisible(false);
				Position6.setVisible(false);
				Position7.setVisible(false);
				Position8.setVisible(false);
				Position9.setVisible(false);
				Position10.setVisible(false);
				Position11.setVisible(false);
				Position12.setVisible(false);
				image13.setBounds(200, 645, 200, 200);

			}
		});
		Position11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1.setVisible(false);
				Position2.setVisible(false);
				Position3.setVisible(false);
				Position4.setVisible(false);
				Position5.setVisible(false);
				Position6.setVisible(false);
				Position7.setVisible(false);
				Position8.setVisible(false);
				Position9.setVisible(false);
				Position10.setVisible(false);
				Position11.setVisible(false);
				Position12.setVisible(false);
				image13.setBounds(200, 460, 200, 200);

			}
		});
		Position12.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1.setVisible(false);
				Position2.setVisible(false);
				Position3.setVisible(false);
				Position4.setVisible(false);
				Position5.setVisible(false);
				Position6.setVisible(false);
				Position7.setVisible(false);
				Position8.setVisible(false);
				Position9.setVisible(false);
				Position10.setVisible(false);
				Position11.setVisible(false);
				Position12.setVisible(false);
				image13.setBounds(200, 260, 200, 200);

			}
		});

		// Deplacement de Watson

		JButton Position1W = new JButton("1");
		Position1W.setBounds(1375, 580, 85, 15);
		label.add(Position1W);
		Position1W.setVisible(false);

		JButton Position2W = new JButton("2");
		Position2W.setBounds(1375, 595, 85, 15);
		label.add(Position2W);
		Position2W.setVisible(false);

		JButton Position3W = new JButton("3");
		Position3W.setBounds(1375, 610, 85, 15);
		label.add(Position3W);
		Position3W.setVisible(false);

		JButton Position4W = new JButton("4");
		Position4W.setBounds(1375, 625, 85, 15);
		label.add(Position4W);
		Position4W.setVisible(false);

		JButton Position5W = new JButton("5");
		Position5W.setBounds(1375, 640, 85, 15);
		label.add(Position5W);
		Position5W.setVisible(false);

		JButton Position6W = new JButton("6");
		Position6W.setBounds(1375, 655, 85, 15);
		label.add(Position6W);
		Position6W.setVisible(false);

		JButton Position7W = new JButton("7");
		Position7W.setBounds(1375, 670, 85, 15);
		label.add(Position7W);
		Position7W.setVisible(false);

		JButton Position8W = new JButton("8");
		Position8W.setBounds(1375, 685, 85, 15);
		label.add(Position8W);
		Position8W.setVisible(false);

		JButton Position9W = new JButton("9");
		Position9W.setBounds(1375, 700, 85, 15);
		label.add(Position9W);
		Position9W.setVisible(false);

		JButton Position10W = new JButton("10");
		Position10W.setBounds(1375, 715, 85, 15);
		label.add(Position10W);
		Position10W.setVisible(false);

		JButton Position11W = new JButton("11");
		Position11W.setBounds(1375, 730, 85, 15);
		label.add(Position11W);
		Position11W.setVisible(false);

		JButton Position12W = new JButton("12");
		Position12W.setBounds(1375, 745, 85, 15);
		label.add(Position12W);
		Position12W.setVisible(false);

		boutonActionWatson.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1W.setVisible(true);
				Position2W.setVisible(true);
				Position3W.setVisible(true);
				Position4W.setVisible(true);
				Position5W.setVisible(true);
				Position6W.setVisible(true);
				Position7W.setVisible(true);
				Position8W.setVisible(true);
				Position9W.setVisible(true);
				Position10W.setVisible(true);
				Position11W.setVisible(true);
				Position12W.setVisible(true);

			}
		});

		Position1W.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1W.setVisible(false);
				Position2W.setVisible(false);
				Position3W.setVisible(false);
				Position4W.setVisible(false);
				Position5W.setVisible(false);
				Position6W.setVisible(false);
				Position7W.setVisible(false);
				Position8W.setVisible(false);
				Position9W.setVisible(false);
				Position10W.setVisible(false);
				Position11W.setVisible(false);
				Position12W.setVisible(false);
				image12.setBounds(340, 30, 200, 200);

			}
		});
		Position2W.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1W.setVisible(false);
				Position2W.setVisible(false);
				Position3W.setVisible(false);
				Position4W.setVisible(false);
				Position5W.setVisible(false);
				Position6W.setVisible(false);
				Position7W.setVisible(false);
				Position8W.setVisible(false);
				Position9W.setVisible(false);
				Position10W.setVisible(false);
				Position11W.setVisible(false);
				Position12W.setVisible(false);
				image12.setBounds(550, 30, 200, 200);
			}
		});
		Position3W.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1W.setVisible(false);
				Position2W.setVisible(false);
				Position3W.setVisible(false);
				Position4W.setVisible(false);
				Position5W.setVisible(false);
				Position6W.setVisible(false);
				Position7W.setVisible(false);
				Position8W.setVisible(false);
				Position9W.setVisible(false);
				Position10W.setVisible(false);
				Position11W.setVisible(false);
				Position12W.setVisible(false);
				image12.setBounds(830, 30, 200, 200);

			}
		});
		Position4W.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1W.setVisible(false);
				Position2W.setVisible(false);
				Position3W.setVisible(false);
				Position4W.setVisible(false);
				Position5W.setVisible(false);
				Position6W.setVisible(false);
				Position7W.setVisible(false);
				Position8W.setVisible(false);
				Position9W.setVisible(false);
				Position10W.setVisible(false);
				Position11W.setVisible(false);
				Position12W.setVisible(false);
				image12.setBounds(1000, 210, 200, 200);

			}
		});
		Position5W.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1W.setVisible(false);
				Position2W.setVisible(false);
				Position3W.setVisible(false);
				Position4W.setVisible(false);
				Position5W.setVisible(false);
				Position6W.setVisible(false);
				Position7W.setVisible(false);
				Position8W.setVisible(false);
				Position9W.setVisible(false);
				Position10W.setVisible(false);
				Position11W.setVisible(false);
				Position12W.setVisible(false);
				image12.setBounds(1000, 410, 200, 200);

			}
		});
		Position6W.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1W.setVisible(false);
				Position2W.setVisible(false);
				Position3W.setVisible(false);
				Position4W.setVisible(false);
				Position5W.setVisible(false);
				Position6W.setVisible(false);
				Position7W.setVisible(false);
				Position8W.setVisible(false);
				Position9W.setVisible(false);
				Position10W.setVisible(false);
				Position11W.setVisible(false);
				Position12W.setVisible(false);
				image12.setBounds(1000, 595, 200, 200);

			}
		});
		Position7W.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1W.setVisible(false);
				Position2W.setVisible(false);
				Position3W.setVisible(false);
				Position4W.setVisible(false);
				Position5W.setVisible(false);
				Position6W.setVisible(false);
				Position7W.setVisible(false);
				Position8W.setVisible(false);
				Position9W.setVisible(false);
				Position10W.setVisible(false);
				Position11W.setVisible(false);
				Position12W.setVisible(false);
				image12.setBounds(830, 820, 200, 200);

			}
		});
		Position8W.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1W.setVisible(false);
				Position2W.setVisible(false);
				Position3W.setVisible(false);
				Position4W.setVisible(false);
				Position5W.setVisible(false);
				Position6W.setVisible(false);
				Position7W.setVisible(false);
				Position8W.setVisible(false);
				Position9W.setVisible(false);
				Position10W.setVisible(false);
				Position11W.setVisible(false);
				Position12W.setVisible(false);
				image12.setBounds(550, 820, 200, 200);

			}
		});
		Position9W.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1W.setVisible(false);
				Position2W.setVisible(false);
				Position3W.setVisible(false);
				Position4W.setVisible(false);
				Position5W.setVisible(false);
				Position6W.setVisible(false);
				Position7W.setVisible(false);
				Position8W.setVisible(false);
				Position9W.setVisible(false);
				Position10W.setVisible(false);
				Position11W.setVisible(false);
				Position12W.setVisible(false);
				image12.setBounds(310, 820, 200, 200);

			}
		});
		Position10W.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1W.setVisible(false);
				Position2W.setVisible(false);
				Position3W.setVisible(false);
				Position4W.setVisible(false);
				Position5W.setVisible(false);
				Position6W.setVisible(false);
				Position7W.setVisible(false);
				Position8W.setVisible(false);
				Position9W.setVisible(false);
				Position10W.setVisible(false);
				Position11W.setVisible(false);
				Position12W.setVisible(false);
				image12.setBounds(200, 605, 200, 200);

			}
		});
		Position11W.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1W.setVisible(false);
				Position2W.setVisible(false);
				Position3W.setVisible(false);
				Position4W.setVisible(false);
				Position5W.setVisible(false);
				Position6W.setVisible(false);
				Position7W.setVisible(false);
				Position8W.setVisible(false);
				Position9W.setVisible(false);
				Position10W.setVisible(false);
				Position11W.setVisible(false);
				Position12W.setVisible(false);
				image12.setBounds(200, 420, 200, 200);

			}
		});
		Position12W.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1W.setVisible(false);
				Position2W.setVisible(false);
				Position3W.setVisible(false);
				Position4W.setVisible(false);
				Position5W.setVisible(false);
				Position6W.setVisible(false);
				Position7W.setVisible(false);
				Position8W.setVisible(false);
				Position9W.setVisible(false);
				Position10W.setVisible(false);
				Position11W.setVisible(false);
				Position12W.setVisible(false);
				image12.setBounds(200, 220, 200, 200);

			}
		});

		// Deplacement de Sherlock Holmes

		JButton Position1S = new JButton("1");
		Position1S.setBounds(1475, 580, 85, 15);
		label.add(Position1S);
		Position1S.setVisible(false);

		JButton Position2S = new JButton("2");
		Position2S.setBounds(1475, 595, 85, 15);
		label.add(Position2S);
		Position2S.setVisible(false);

		JButton Position3S = new JButton("3");
		Position3S.setBounds(1475, 610, 85, 15);
		label.add(Position3S);
		Position3S.setVisible(false);

		JButton Position4S = new JButton("4");
		Position4S.setBounds(1475, 625, 85, 15);
		label.add(Position4S);
		Position4S.setVisible(false);

		JButton Position5S = new JButton("5");
		Position5S.setBounds(1475, 640, 85, 15);
		label.add(Position5S);
		Position5S.setVisible(false);

		JButton Position6S = new JButton("6");
		Position6S.setBounds(1475, 655, 85, 15);
		label.add(Position6S);
		Position6S.setVisible(false);

		JButton Position7S = new JButton("7");
		Position7S.setBounds(1475, 670, 85, 15);
		label.add(Position7S);
		Position7S.setVisible(false);

		JButton Position8S = new JButton("8");
		Position8S.setBounds(1475, 685, 85, 15);
		label.add(Position8S);
		Position8S.setVisible(false);

		JButton Position9S = new JButton("9");
		Position9S.setBounds(1475, 700, 85, 15);
		label.add(Position9S);
		Position9S.setVisible(false);

		JButton Position10S = new JButton("10");
		Position10S.setBounds(1475, 715, 85, 15);
		label.add(Position10S);
		Position10S.setVisible(false);

		JButton Position11S = new JButton("11");
		Position11S.setBounds(1475, 730, 85, 15);
		;
		label.add(Position11S);
		Position11S.setVisible(false);

		JButton Position12S = new JButton("12");
		Position12S.setBounds(1475, 745, 85, 15);
		label.add(Position12S);
		Position12S.setVisible(false);

		boutonActionSherlockHolmes.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1S.setVisible(true);
				Position2S.setVisible(true);
				Position3S.setVisible(true);
				Position4S.setVisible(true);
				Position5S.setVisible(true);
				Position6S.setVisible(true);
				Position7S.setVisible(true);
				Position8S.setVisible(true);
				Position9S.setVisible(true);
				Position10S.setVisible(true);
				Position11S.setVisible(true);
				Position12S.setVisible(true);

			}
		});

		Position1S.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1S.setVisible(false);
				Position2S.setVisible(false);
				Position3S.setVisible(false);
				Position4S.setVisible(false);
				Position5S.setVisible(false);
				Position6S.setVisible(false);
				Position7S.setVisible(false);
				Position8S.setVisible(false);
				Position9S.setVisible(false);
				Position10S.setVisible(false);
				Position11S.setVisible(false);
				Position12S.setVisible(false);
				image11.setBounds(420, 30, 200, 200);

			}
		});
		Position2S.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1S.setVisible(false);
				Position2S.setVisible(false);
				Position3S.setVisible(false);
				Position4S.setVisible(false);
				Position5S.setVisible(false);
				Position6S.setVisible(false);
				Position7S.setVisible(false);
				Position8S.setVisible(false);
				Position9S.setVisible(false);
				Position10S.setVisible(false);
				Position11S.setVisible(false);
				Position12S.setVisible(false);
				image11.setBounds(660, 30, 200, 200);
			}
		});
		Position3S.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1S.setVisible(false);
				Position2S.setVisible(false);
				Position3S.setVisible(false);
				Position4S.setVisible(false);
				Position5S.setVisible(false);
				Position6S.setVisible(false);
				Position7S.setVisible(false);
				Position8S.setVisible(false);
				Position9S.setVisible(false);
				Position10S.setVisible(false);
				Position11S.setVisible(false);
				Position12S.setVisible(false);
				image11.setBounds(900, 30, 200, 200);

			}
		});
		Position4S.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1S.setVisible(false);
				Position2S.setVisible(false);
				Position3S.setVisible(false);
				Position4S.setVisible(false);
				Position5S.setVisible(false);
				Position6S.setVisible(false);
				Position7S.setVisible(false);
				Position8S.setVisible(false);
				Position9S.setVisible(false);
				Position10S.setVisible(false);
				Position11S.setVisible(false);
				Position12S.setVisible(false);
				image11.setBounds(1000, 170, 200, 200);

			}
		});
		Position5S.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1S.setVisible(false);
				Position2S.setVisible(false);
				Position3S.setVisible(false);
				Position4S.setVisible(false);
				Position5S.setVisible(false);
				Position6S.setVisible(false);
				Position7S.setVisible(false);
				Position8S.setVisible(false);
				Position9S.setVisible(false);
				Position10S.setVisible(false);
				Position11S.setVisible(false);
				Position12S.setVisible(false);
				image11.setBounds(1000, 360, 200, 200);

			}
		});
		Position6S.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1S.setVisible(false);
				Position2S.setVisible(false);
				Position3S.setVisible(false);
				Position4S.setVisible(false);
				Position5S.setVisible(false);
				Position6S.setVisible(false);
				Position7S.setVisible(false);
				Position8S.setVisible(false);
				Position9S.setVisible(false);
				Position10S.setVisible(false);
				Position11S.setVisible(false);
				Position12S.setVisible(false);
				image11.setBounds(1000, 700, 200, 200);

			}
		});
		Position7S.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1S.setVisible(false);
				Position2S.setVisible(false);
				Position3S.setVisible(false);
				Position4S.setVisible(false);
				Position5S.setVisible(false);
				Position6S.setVisible(false);
				Position7S.setVisible(false);
				Position8S.setVisible(false);
				Position9S.setVisible(false);
				Position10S.setVisible(false);
				Position11S.setVisible(false);
				Position12S.setVisible(false);
				image11.setBounds(890, 820, 200, 200);

			}
		});
		Position8S.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1S.setVisible(false);
				Position2S.setVisible(false);
				Position3S.setVisible(false);
				Position4S.setVisible(false);
				Position5S.setVisible(false);
				Position6S.setVisible(false);
				Position7S.setVisible(false);
				Position8S.setVisible(false);
				Position9S.setVisible(false);
				Position10S.setVisible(false);
				Position11S.setVisible(false);
				Position12S.setVisible(false);
				image11.setBounds(650, 820, 200, 200);

			}
		});
		Position9S.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1S.setVisible(false);
				Position2S.setVisible(false);
				Position3S.setVisible(false);
				Position4S.setVisible(false);
				Position5S.setVisible(false);
				Position6S.setVisible(false);
				Position7S.setVisible(false);
				Position8S.setVisible(false);
				Position9S.setVisible(false);
				Position10S.setVisible(false);
				Position11S.setVisible(false);
				Position12S.setVisible(false);
				image11.setBounds(410, 820, 200, 200);

			}
		});
		Position10S.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				Position1S.setVisible(false);
				Position2S.setVisible(false);
				Position3S.setVisible(false);
				Position4S.setVisible(false);
				Position5S.setVisible(false);
				Position6S.setVisible(false);
				Position7S.setVisible(false);
				Position8S.setVisible(false);
				Position9S.setVisible(false);
				Position10S.setVisible(false);
				Position11S.setVisible(false);
				Position12S.setVisible(false);
				image11.setBounds(200, 705, 200, 200);

			}
		});
		Position11S.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1S.setVisible(false);
				Position2S.setVisible(false);
				Position3S.setVisible(false);
				Position4S.setVisible(false);
				Position5S.setVisible(false);
				Position6S.setVisible(false);
				Position7S.setVisible(false);
				Position8S.setVisible(false);
				Position9S.setVisible(false);
				Position10S.setVisible(false);
				Position11S.setVisible(false);
				Position12S.setVisible(false);
				image11.setBounds(200, 370, 200, 200);

			}
		});
		Position12S.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Position1S.setVisible(false);
				Position2S.setVisible(false);
				Position3S.setVisible(false);
				Position4S.setVisible(false);
				Position5S.setVisible(false);
				Position6S.setVisible(false);
				Position7S.setVisible(false);
				Position8S.setVisible(false);
				Position9S.setVisible(false);
				Position10S.setVisible(false);
				Position11S.setVisible(false);
				Position12S.setVisible(false);
				image11.setBounds(200, 170, 200, 200);

			}
		});

////////////////////////////////////////////////////////////////////////////////////////////////////////

		// Bouton Joker /////////////////////////////////////////

		JButton SherlockJ = new JButton("Sherlock");
		SherlockJ.setBounds(1625, 580, 85, 15);
		label.add(SherlockJ);
		SherlockJ.setVisible(false);

		JButton WatsonJ = new JButton("Watson");
		WatsonJ.setBounds(1625, 595, 85, 15);
		label.add(WatsonJ);
		WatsonJ.setVisible(false);

		JButton TobiJ = new JButton("Tobi");
		TobiJ.setBounds(1625, 610, 85, 15);
		label.add(TobiJ);
		TobiJ.setVisible(false);

		SherlockJ.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				SherlockJ.setVisible(false);
				WatsonJ.setVisible(false);
				TobiJ.setVisible(false);
			}
		});

		WatsonJ.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) { 
				SherlockJ.setVisible(false);
				WatsonJ.setVisible(false);
				TobiJ.setVisible(false);
			}
		});

		TobiJ.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				SherlockJ.setVisible(false);
				WatsonJ.setVisible(false);
				TobiJ.setVisible(false);
			}
		});

		boutonActionJoker.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				SherlockJ.setVisible(true);
				WatsonJ.setVisible(true);
				TobiJ.setVisible(true);
			}
		}); 

	//	JLabel image10 = new JLabel(plateau);
		image10.setBounds(0, 76, 200, 200);
		//frame.add(image10);

		frame.validate(); // Permet de valider et d'afficher

		
		//////////////////////////// Boutons permettant d'echanger les tuiles de rues de
		//////////////////////////// places

		JButton LestradeE = new JButton("Lestrade");
		LestradeE.setBounds(1550, 580, 85, 15);
		label.add(LestradeE);
		LestradeE.setVisible(false);

		JButton JeremyBertE = new JButton("Bert");
		JeremyBertE.setBounds(1550, 595, 85, 15);
		label.add(JeremyBertE);
		JeremyBertE.setVisible(false);

		JButton PizerE = new JButton("Pizer");
		PizerE.setBounds(1550, 610, 85, 15);
		label.add(PizerE);
		PizerE.setVisible(false);

		JButton SmithE = new JButton("Smith");
		SmithE.setBounds(1550, 625, 85, 15);
		label.add(SmithE);
		SmithE.setVisible(false);

		JButton LaneE = new JButton("Lane");
		LaneE.setBounds(1550, 640, 85, 15);
		label.add(LaneE);
		LaneE.setVisible(false);

		JButton MadameE = new JButton("Madame");
		MadameE.setBounds(1550, 655, 85, 15);
		label.add(MadameE);
		MadameE.setVisible(false);

		JButton StealthyE = new JButton("Stealthy");
		StealthyE.setBounds(1550, 670, 85, 15);
		label.add(StealthyE);
		StealthyE.setVisible(false);

		JButton GullE = new JButton("Gull");
		GullE.setBounds(1550, 685, 85, 15);
		label.add(GullE);
		GullE.setVisible(false);

		JButton GoodleyE = new JButton("Goodley");
		GoodleyE.setBounds(1550, 700, 85, 15);
		label.add(GoodleyE);
		GoodleyE.setVisible(false);

		JButton QuartdeTourDroiteE = new JButton("1/4 D");
		QuartdeTourDroiteE.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteE);
		QuartdeTourDroiteE.setVisible(false);

		JButton DemiTourDroiteE = new JButton("1/2 Tour");
		DemiTourDroiteE.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteE);
		DemiTourDroiteE.setVisible(false);

		JButton QuartdeTourGaucheE = new JButton("1/4 G");
		QuartdeTourGaucheE.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheE);
		QuartdeTourGaucheE.setVisible(false);

		JButton PositioninitialeE = new JButton("-");
		PositioninitialeE.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeE);
		PositioninitialeE.setVisible(false);

		JButton LestradeEE = new JButton("Lestrade");
		LestradeEE.setBounds(1550, 580, 85, 15);
		label.add(LestradeEE);
		LestradeEE.setVisible(false);

		JButton JeremyBertEE = new JButton("Bert");
		JeremyBertEE.setBounds(1550, 595, 85, 15);
		label.add(JeremyBertEE);
		JeremyBertEE.setVisible(false);

		JButton PizerEE = new JButton("Pizer");
		PizerEE.setBounds(1550, 610, 85, 15);
		label.add(PizerEE);
		PizerEE.setVisible(false);

		JButton SmithEE = new JButton("Smith");
		SmithEE.setBounds(1550, 625, 85, 15);
		label.add(SmithEE);
		SmithEE.setVisible(false);

		JButton LaneEE = new JButton("Lane");
		LaneEE.setBounds(1550, 640, 85, 15);
		label.add(LaneEE);
		LaneEE.setVisible(false);

		JButton MadameEE = new JButton("Madame");
		MadameEE.setBounds(1550, 655, 85, 15);
		label.add(MadameEE);
		MadameEE.setVisible(false);

		JButton StealthyEE = new JButton("Stealthy");
		StealthyEE.setBounds(1550, 670, 85, 15);
		label.add(StealthyEE);
		StealthyEE.setVisible(false);

		JButton GullEE = new JButton("Gull");
		GullEE.setBounds(1550, 685, 85, 15);
		label.add(GullEE);
		GullEE.setVisible(false);

		JButton GoodleyEE = new JButton("Goodley");
		GoodleyEE.setBounds(1550, 700, 85, 15);
		label.add(GoodleyEE);
		GoodleyEE.setVisible(false);

		boutonActionEchange.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeE.setVisible(true);
				JeremyBertE.setVisible(true);
				PizerE.setVisible(true);
				SmithE.setVisible(true);
				LaneE.setVisible(true);
				MadameE.setVisible(true);
				StealthyE.setVisible(true);
				GullE.setVisible(true);
				GoodleyE.setVisible(true);

				/*
				 * image2.setBounds(375, 200, 200, 200); image1.setBounds(600, 200, 200, 200);
				 */

			}
		});

		LestradeE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeE.setVisible(false);
				JeremyBertE.setVisible(false);
				PizerE.setVisible(false);
				SmithE.setVisible(false);
				LaneE.setVisible(false);
				MadameE.setVisible(false);
				StealthyE.setVisible(false);
				GullE.setVisible(false);
				GoodleyE.setVisible(false);

				QuartdeTourDroiteE.setVisible(true);
				DemiTourDroiteE.setVisible(true);
				QuartdeTourGaucheE.setVisible(true);
				PositioninitialeE.setVisible(true);
				LestradeEE.setVisible(false);

				/*
				 * QuartdeTourDroiteE.setVisible(false); DemiTourDroiteE.setVisible(false);
				 * QuartdeTourGaucheE.setVisible(false); PositioninitialeE.setVisible(false);
				 */
			}

		});

		QuartdeTourDroiteE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteE.setVisible(false);
				DemiTourDroiteE.setVisible(false);
				QuartdeTourGaucheE.setVisible(false);
				PositioninitialeE.setVisible(false);

				JeremyBertEE.setVisible(true);
				PizerEE.setVisible(true);
				SmithEE.setVisible(true);
				LaneEE.setVisible(true);
				MadameEE.setVisible(true);
				StealthyEE.setVisible(true);
				GullEE.setVisible(true);
				GoodleyEE.setVisible(true);

			}

		});

		JButton QuartdeTourDroiteEE = new JButton("1/4 D");
		QuartdeTourDroiteEE.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEE);
		QuartdeTourDroiteEE.setVisible(false);

		JButton DemiTourDroiteEE = new JButton("1/2 Tour");
		DemiTourDroiteEE.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEE);
		DemiTourDroiteEE.setVisible(false);

		JButton QuartdeTourGaucheEE = new JButton("1/4 G");
		QuartdeTourGaucheEE.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEE);
		QuartdeTourGaucheEE.setVisible(false);

		JButton PositioninitialeEE = new JButton("-");
		PositioninitialeEE.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEE);
		PositioninitialeEE.setVisible(false);

		JeremyBertEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEE.setVisible(true);
				DemiTourDroiteEE.setVisible(true);
				QuartdeTourGaucheEE.setVisible(true);
				PositioninitialeEE.setVisible(true);

				/*
				 * image1.setVisible(false); image2.setVisible(false); image1QD.setBounds(600,
				 * 200, 200,200); image2QD.setBounds(375, 200, 200,200);
				 * image1QG.setVisible(false); image2QG.setVisible(false);
				 */

			}
		});

		QuartdeTourDroiteEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE.setVisible(false);
				DemiTourDroiteEE.setVisible(false);
				QuartdeTourGaucheEE.setVisible(false);
				PositioninitialeEE.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1QD.setBounds(600, 200, 200, 200);
				image2QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image2DD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);

			}
		});

		DemiTourDroiteEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE.setVisible(false);
				DemiTourDroiteEE.setVisible(false);
				QuartdeTourGaucheEE.setVisible(false);
				PositioninitialeEE.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1QD.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);
				image1DD.setVisible(false);
				image2DD.setBounds(375, 200, 200, 200);
			}
		});

		QuartdeTourGaucheEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE.setVisible(false);
				DemiTourDroiteEE.setVisible(false);
				QuartdeTourGaucheEE.setVisible(false);
				PositioninitialeEE.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1QD.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		PositioninitialeEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE.setVisible(false);
				DemiTourDroiteEE.setVisible(false);
				QuartdeTourGaucheEE.setVisible(false);
				PositioninitialeEE.setVisible(false);

				image1.setVisible(false);
				image2.setBounds(375, 200, 200, 200);
				image1QD.setBounds(600, 200, 200, 200);
				image1QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);
				image1DD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEP = new JButton("1/4 D");
		QuartdeTourDroiteEEP.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEP);
		QuartdeTourDroiteEEP.setVisible(false);

		JButton DemiTourDroiteEEP = new JButton("1/2 Tour");
		DemiTourDroiteEEP.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEP);
		DemiTourDroiteEEP.setVisible(false);

		JButton QuartdeTourGaucheEEP = new JButton("1/4 G");
		QuartdeTourGaucheEEP.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEP);
		QuartdeTourGaucheEEP.setVisible(false);

		JButton PositioninitialeEEP = new JButton("-");
		PositioninitialeEEP.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEP);
		PositioninitialeEEP.setVisible(false);

		PizerEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEEP.setVisible(true);
				DemiTourDroiteEEP.setVisible(true);
				QuartdeTourGaucheEEP.setVisible(true);
				PositioninitialeEEP.setVisible(true);

			}
		});

		QuartdeTourDroiteEEP.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP.setVisible(false);
				DemiTourDroiteEEP.setVisible(false);
				QuartdeTourGaucheEEP.setVisible(false);
				PositioninitialeEEP.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1QD.setBounds(825, 200, 200, 200);
				image3QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image3DD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setVisible(false);

			}
		});

		DemiTourDroiteEEP.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP.setVisible(false);
				DemiTourDroiteEEP.setVisible(false);
				QuartdeTourGaucheEEP.setVisible(false);
				PositioninitialeEEP.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1QD.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setVisible(false);
				image1DD.setVisible(false);
				image3DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEP.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP.setVisible(false);
				DemiTourDroiteEEP.setVisible(false);
				QuartdeTourGaucheEEP.setVisible(false);
				PositioninitialeEEP.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1QD.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image3DD.setVisible(false);

			}
		});
		PositioninitialeEEP.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP.setVisible(false);
				DemiTourDroiteEEP.setVisible(false);
				QuartdeTourGaucheEEP.setVisible(false);
				PositioninitialeEEP.setVisible(false);

				image1.setVisible(false);
				image3.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image3QG.setVisible(false);
				image1QD.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1DD.setVisible(false);
				image3DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEES = new JButton("1/4 D");
		QuartdeTourDroiteEES.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEES);
		QuartdeTourDroiteEES.setVisible(false);

		JButton DemiTourDroiteEES = new JButton("1/2 Tour");
		DemiTourDroiteEES.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEES);
		DemiTourDroiteEES.setVisible(false);

		JButton QuartdeTourGaucheEES = new JButton("1/4 G");
		QuartdeTourGaucheEES.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEES);
		QuartdeTourGaucheEES.setVisible(false);

		JButton PositioninitialeEES = new JButton("-");
		PositioninitialeEES.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEES);
		PositioninitialeEES.setVisible(false);

		SmithEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEES.setVisible(true);
				DemiTourDroiteEES.setVisible(true);
				QuartdeTourGaucheEES.setVisible(true);
				PositioninitialeEES.setVisible(true);

			}
		});

		QuartdeTourDroiteEES.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES.setVisible(false);
				DemiTourDroiteEES.setVisible(false);
				QuartdeTourGaucheEES.setVisible(false);
				PositioninitialeEES.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1QD.setBounds(375, 425, 200, 200);
				image4QD.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1DD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		DemiTourDroiteEES.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES.setVisible(false);
				DemiTourDroiteEES.setVisible(false);
				QuartdeTourGaucheEES.setVisible(false);
				PositioninitialeEES.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1QD.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1DD.setVisible(false);
				image4DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEES.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES.setVisible(false);
				DemiTourDroiteEES.setVisible(false);
				QuartdeTourGaucheEES.setVisible(false);
				PositioninitialeEES.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1QD.setBounds(375, 425, 200, 200);
				image1QD.setVisible(false);
				image1QG.setVisible(false);
				image4QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image4DD.setVisible(false);

			}
		});
		PositioninitialeEES.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES.setVisible(false);
				DemiTourDroiteEES.setVisible(false);
				QuartdeTourGaucheEES.setVisible(false);
				PositioninitialeEES.setVisible(false);

				image1.setVisible(false);
				image4.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1QD.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1DD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEL = new JButton("1/4 D");
		QuartdeTourDroiteEEL.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEL);
		QuartdeTourDroiteEEL.setVisible(false);

		JButton DemiTourDroiteEEL = new JButton("1/2 Tour");
		DemiTourDroiteEEL.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEL);
		DemiTourDroiteEEL.setVisible(false);

		JButton QuartdeTourGaucheEEL = new JButton("1/4 G");
		QuartdeTourGaucheEEL.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEL);
		QuartdeTourGaucheEEL.setVisible(false);

		JButton PositioninitialeEEL = new JButton("-");
		PositioninitialeEEL.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEL);
		PositioninitialeEEL.setVisible(false);

		LaneEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEL.setVisible(true);
				DemiTourDroiteEEL.setVisible(true);
				QuartdeTourGaucheEEL.setVisible(true);
				PositioninitialeEEL.setVisible(true);

			}
		});

		QuartdeTourDroiteEEL.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL.setVisible(false);
				DemiTourDroiteEEL.setVisible(false);
				QuartdeTourGaucheEEL.setVisible(false);
				PositioninitialeEEL.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1QD.setBounds(600, 425, 200, 200);
				image5QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image5DD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);

			}
		});

		DemiTourDroiteEEL.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL.setVisible(false);
				DemiTourDroiteEEL.setVisible(false);
				QuartdeTourGaucheEEL.setVisible(false);
				PositioninitialeEEL.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1QD.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);
				image1DD.setVisible(false);
				image5DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEL.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL.setVisible(false);
				DemiTourDroiteEEL.setVisible(false);
				QuartdeTourGaucheEEL.setVisible(false);
				PositioninitialeEEL.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1QD.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image5DD.setVisible(false);

			}
		});
		PositioninitialeEEL.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL.setVisible(false);
				DemiTourDroiteEEL.setVisible(false);
				QuartdeTourGaucheEEL.setVisible(false);
				PositioninitialeEEL.setVisible(false);

				image1.setVisible(false);
				image5.setBounds(375, 200, 200, 200);

				image1QD.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);
				image1DD.setVisible(false);
				image5DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEM = new JButton("1/4 D");
		QuartdeTourDroiteEEM.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEM);
		QuartdeTourDroiteEEM.setVisible(false);

		JButton DemiTourDroiteEEM = new JButton("1/2 Tour");
		DemiTourDroiteEEM.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEM);
		DemiTourDroiteEEM.setVisible(false);

		JButton QuartdeTourGaucheEEM = new JButton("1/4 G");
		QuartdeTourGaucheEEM.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEM);
		QuartdeTourGaucheEEM.setVisible(false);

		JButton PositioninitialeEEM = new JButton("-");
		PositioninitialeEEM.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEM);
		PositioninitialeEEM.setVisible(false);

		MadameEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEM.setVisible(true);
				DemiTourDroiteEEM.setVisible(true);
				QuartdeTourGaucheEEM.setVisible(true);
				PositioninitialeEEM.setVisible(true);

			}
		});

		QuartdeTourDroiteEEM.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM.setVisible(false);
				DemiTourDroiteEEM.setVisible(false);
				QuartdeTourGaucheEEM.setVisible(false);
				PositioninitialeEEM.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1QD.setBounds(825, 425, 200, 200);
				image6QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image6DD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);

			}
		});

		DemiTourDroiteEEM.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM.setVisible(false);
				DemiTourDroiteEEM.setVisible(false);
				QuartdeTourGaucheEEM.setVisible(false);
				PositioninitialeEEM.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1QD.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);
				image1DD.setVisible(false);
				image6DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEM.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM.setVisible(false);
				DemiTourDroiteEEM.setVisible(false);
				QuartdeTourGaucheEEM.setVisible(false);
				PositioninitialeEEM.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1QD.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image6DD.setVisible(false);

			}
		});
		PositioninitialeEEM.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM.setVisible(false);
				DemiTourDroiteEEM.setVisible(false);
				QuartdeTourGaucheEEM.setVisible(false);
				PositioninitialeEEM.setVisible(false);

				image1.setVisible(false);
				image6.setBounds(375, 200, 200, 200);
				image1QD.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);
				image1DD.setVisible(false);
				image6DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEMS = new JButton("1/4 D");
		QuartdeTourDroiteEEMS.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEMS);
		QuartdeTourDroiteEEMS.setVisible(false);

		JButton DemiTourDroiteEEMS = new JButton("1/2 Tour");
		DemiTourDroiteEEMS.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEMS);
		DemiTourDroiteEEMS.setVisible(false);

		JButton QuartdeTourGaucheEEMS = new JButton("1/4 G");
		QuartdeTourGaucheEEMS.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEMS);
		QuartdeTourGaucheEEMS.setVisible(false);

		JButton PositioninitialeEEMS = new JButton("-");
		PositioninitialeEEMS.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEMS);
		PositioninitialeEEMS.setVisible(false);

		StealthyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEMS.setVisible(true);
				DemiTourDroiteEEMS.setVisible(true);
				QuartdeTourGaucheEEMS.setVisible(true);
				PositioninitialeEEMS.setVisible(true);

			}
		});

		QuartdeTourDroiteEEMS.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS.setVisible(false);
				DemiTourDroiteEEMS.setVisible(false);
				QuartdeTourGaucheEEMS.setVisible(false);
				PositioninitialeEEMS.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1QD.setBounds(375, 650, 200, 200);
				image7QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image7DD.setVisible(false);
				image1QG.setVisible(false);
				image7QG.setVisible(false);

			}
		});

		DemiTourDroiteEEMS.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS.setVisible(false);
				DemiTourDroiteEEMS.setVisible(false);
				QuartdeTourGaucheEEMS.setVisible(false);
				PositioninitialeEEMS.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1QD.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1DD.setVisible(false);
				image7DD.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image7QG.setVisible(false);

			}
		});
		QuartdeTourGaucheEEMS.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS.setVisible(false);
				DemiTourDroiteEEMS.setVisible(false);
				QuartdeTourGaucheEEMS.setVisible(false);
				PositioninitialeEEMS.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1QD.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1QG.setVisible(false);
				image7QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image7DD.setVisible(false);

			}
		});
		PositioninitialeEEMS.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS.setVisible(false);
				DemiTourDroiteEEMS.setVisible(false);
				QuartdeTourGaucheEEMS.setVisible(false);
				PositioninitialeEEMS.setVisible(false);

				image1.setVisible(false);
				image7.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image7QG.setVisible(false);
				image1QD.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1DD.setVisible(false);
				image7DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEGU = new JButton("1/4 D");
		QuartdeTourDroiteEEGU.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEGU);
		QuartdeTourDroiteEEGU.setVisible(false);

		JButton DemiTourDroiteEEGU = new JButton("1/2 Tour");
		DemiTourDroiteEEGU.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEGU);
		DemiTourDroiteEEGU.setVisible(false);

		JButton QuartdeTourGaucheEEGU = new JButton("1/4 G");
		QuartdeTourGaucheEEGU.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEGU);
		QuartdeTourGaucheEEGU.setVisible(false);

		JButton PositioninitialeEEGU = new JButton("-");
		PositioninitialeEEGU.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEGU);
		PositioninitialeEEGU.setVisible(false);

		GullEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEGU.setVisible(true);
				DemiTourDroiteEEGU.setVisible(true);
				QuartdeTourGaucheEEGU.setVisible(true);
				PositioninitialeEEGU.setVisible(true);

			}
		});

		QuartdeTourDroiteEEGU.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU.setVisible(false);
				DemiTourDroiteEEGU.setVisible(false);
				QuartdeTourGaucheEEGU.setVisible(false);
				PositioninitialeEEGU.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1QD.setBounds(825, 650, 200, 200);
				image9QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image9DD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);

			}
		});

		DemiTourDroiteEEGU.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU.setVisible(false);
				DemiTourDroiteEEGU.setVisible(false);
				QuartdeTourGaucheEEGU.setVisible(false);
				PositioninitialeEEGU.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1QD.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);
				image1DD.setVisible(false);
				image9DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEGU.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU.setVisible(false);
				DemiTourDroiteEEGU.setVisible(false);
				QuartdeTourGaucheEEGU.setVisible(false);
				PositioninitialeEEGU.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1QD.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		PositioninitialeEEGU.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU.setVisible(false);
				DemiTourDroiteEEGU.setVisible(false);
				QuartdeTourGaucheEEGU.setVisible(false);
				PositioninitialeEEGU.setVisible(false);

				image1.setVisible(false);
				image9.setBounds(375, 200, 200, 200);
				image1QD.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);
				image1DD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEG = new JButton("1/4 D");
		QuartdeTourDroiteEEG.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEG);
		QuartdeTourDroiteEEG.setVisible(false);

		JButton DemiTourDroiteEEG = new JButton("1/2 Tour");
		DemiTourDroiteEEG.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEG);
		DemiTourDroiteEEG.setVisible(false);

		JButton QuartdeTourGaucheEEG = new JButton("1/4 G");
		QuartdeTourGaucheEEG.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEG);
		QuartdeTourGaucheEEG.setVisible(false);

		JButton PositioninitialeEEG = new JButton("-");
		PositioninitialeEEG.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEG);
		PositioninitialeEEG.setVisible(false);

		GoodleyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEG.setVisible(true);
				DemiTourDroiteEEG.setVisible(true);
				QuartdeTourGaucheEEG.setVisible(true);
				PositioninitialeEEG.setVisible(true);

			}
		});

		QuartdeTourDroiteEEG.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG.setVisible(false);
				DemiTourDroiteEEG.setVisible(false);
				QuartdeTourGaucheEEG.setVisible(false);
				PositioninitialeEEG.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1QD.setBounds(600, 650, 200, 200);
				image8QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image8DD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);

			}
		});

		DemiTourDroiteEEG.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG.setVisible(false);
				DemiTourDroiteEEG.setVisible(false);
				QuartdeTourGaucheEEG.setVisible(false);
				PositioninitialeEEG.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1QD.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);
				image1DD.setVisible(false);
				image8DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEG.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG.setVisible(false);
				DemiTourDroiteEEG.setVisible(false);
				QuartdeTourGaucheEEG.setVisible(false);
				PositioninitialeEEG.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1QD.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image8DD.setVisible(false);

			}
		});

		PositioninitialeEEG.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG.setVisible(false);
				DemiTourDroiteEEG.setVisible(false);
				QuartdeTourGaucheEEG.setVisible(false);
				PositioninitialeEEG.setVisible(false);

				image1.setVisible(false);
				image8.setBounds(375, 200, 200, 200);
				image1QD.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);
				image1DD.setVisible(false);
				image8DD.setVisible(false);

			}
		});

		DemiTourDroiteE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteE.setVisible(false);
				DemiTourDroiteE.setVisible(false);
				QuartdeTourGaucheE.setVisible(false);
				PositioninitialeE.setVisible(false);

				JeremyBertEE.setVisible(true);
				PizerEE.setVisible(true);
				SmithEE.setVisible(true);
				LaneEE.setVisible(true);
				MadameEE.setVisible(true);
				StealthyEE.setVisible(true);
				GullEE.setVisible(true);
				GoodleyEE.setVisible(true);

			}

		});

		JButton QuartdeTourDroiteEE1 = new JButton("1/4 D");
		QuartdeTourDroiteEE1.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEE1);
		QuartdeTourDroiteEE1.setVisible(false);

		JButton DemiTourDroiteEE1 = new JButton("1/2 Tour");
		DemiTourDroiteEE1.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEE1);
		DemiTourDroiteEE1.setVisible(false);

		JButton QuartdeTourGaucheEE1 = new JButton("1/4 G");
		QuartdeTourGaucheEE1.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEE1);
		QuartdeTourGaucheEE1.setVisible(false);

		JButton PositioninitialeEE1 = new JButton("-");
		PositioninitialeEE1.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEE1);
		PositioninitialeEE1.setVisible(false);

		JeremyBertEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEE1.setVisible(true);
				DemiTourDroiteEE1.setVisible(true);
				QuartdeTourGaucheEE1.setVisible(true);
				PositioninitialeEE1.setVisible(true);

				/*
				 * image1.setVisible(false); image2.setVisible(false); image1QD.setBounds(600,
				 * 200, 200,200); image2QD.setBounds(375, 200, 200,200);
				 * image1QG.setVisible(false); image2QG.setVisible(false);
				 */

			}
		});

		QuartdeTourDroiteEE1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE1.setVisible(false);
				DemiTourDroiteEE1.setVisible(false);
				QuartdeTourGaucheEE1.setVisible(false);
				PositioninitialeEE1.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1DD.setBounds(600, 200, 200, 200);
				image2QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image2DD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);

			}
		});

		DemiTourDroiteEE1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE1.setVisible(false);
				DemiTourDroiteEE1.setVisible(false);
				QuartdeTourGaucheEE1.setVisible(false);
				PositioninitialeEE1.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1DD.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);
				image1QD.setVisible(false);
				image2DD.setBounds(375, 200, 200, 200);
			}
		});

		QuartdeTourGaucheEE1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE1.setVisible(false);
				DemiTourDroiteEE1.setVisible(false);
				QuartdeTourGaucheEE1.setVisible(false);
				PositioninitialeEE1.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1DD.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		PositioninitialeEE1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE1.setVisible(false);
				DemiTourDroiteEE1.setVisible(false);
				QuartdeTourGaucheEE1.setVisible(false);
				PositioninitialeEE1.setVisible(false);

				image1.setVisible(false);
				image2.setBounds(375, 200, 200, 200);
				image1DD.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);
				image1QD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEP1 = new JButton("1/4 D");
		QuartdeTourDroiteEEP1.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEP1);
		QuartdeTourDroiteEEP1.setVisible(false);

		JButton DemiTourDroiteEEP1 = new JButton("1/2 Tour");
		DemiTourDroiteEEP1.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEP1);
		DemiTourDroiteEEP1.setVisible(false);

		JButton QuartdeTourGaucheEEP1 = new JButton("1/4 G");
		QuartdeTourGaucheEEP1.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEP1);
		QuartdeTourGaucheEEP1.setVisible(false);

		JButton PositioninitialeEEP1 = new JButton("-");
		PositioninitialeEEP1.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEP1);
		PositioninitialeEEP1.setVisible(false);

		PizerEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEEP1.setVisible(true);
				DemiTourDroiteEEP1.setVisible(true);
				QuartdeTourGaucheEEP1.setVisible(true);
				PositioninitialeEEP1.setVisible(true);

			}
		});

		QuartdeTourDroiteEEP1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP1.setVisible(false);
				DemiTourDroiteEEP1.setVisible(false);
				QuartdeTourGaucheEEP1.setVisible(false);
				PositioninitialeEEP1.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1DD.setBounds(825, 200, 200, 200);
				image3QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image3QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setVisible(false);

			}
		});

		DemiTourDroiteEEP1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP1.setVisible(false);
				DemiTourDroiteEEP1.setVisible(false);
				QuartdeTourGaucheEEP1.setVisible(false);
				PositioninitialeEEP1.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1DD.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setVisible(false);
				image1QD.setVisible(false);
				image3DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEP1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP1.setVisible(false);
				DemiTourDroiteEEP1.setVisible(false);
				QuartdeTourGaucheEEP1.setVisible(false);
				PositioninitialeEEP1.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1DD.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image3DD.setVisible(false);

			}
		});
		PositioninitialeEEP1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP1.setVisible(false);
				DemiTourDroiteEEP1.setVisible(false);
				QuartdeTourGaucheEEP1.setVisible(false);
				PositioninitialeEEP1.setVisible(false);

				image1.setVisible(false);
				image3.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image3QG.setVisible(false);
				image1DD.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QD.setVisible(false);
				image3DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEES1 = new JButton("1/4 D");
		QuartdeTourDroiteEES1.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEES1);
		QuartdeTourDroiteEES1.setVisible(false);

		JButton DemiTourDroiteEES1 = new JButton("1/2 Tour");
		DemiTourDroiteEES1.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEES1);
		DemiTourDroiteEES1.setVisible(false);

		JButton QuartdeTourGaucheEES1 = new JButton("1/4 G");
		QuartdeTourGaucheEES1.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEES1);
		QuartdeTourGaucheEES1.setVisible(false);

		JButton PositioninitialeEES1 = new JButton("-");
		PositioninitialeEES1.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEES1);
		PositioninitialeEES1.setVisible(false);

		SmithEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEES1.setVisible(true);
				DemiTourDroiteEES1.setVisible(true);
				QuartdeTourGaucheEES1.setVisible(true);
				PositioninitialeEES1.setVisible(true);

			}
		});

		QuartdeTourDroiteEES1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES1.setVisible(false);
				DemiTourDroiteEES1.setVisible(false);
				QuartdeTourGaucheEES1.setVisible(false);
				PositioninitialeEES1.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1DD.setBounds(375, 425, 200, 200);
				image4QD.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		DemiTourDroiteEES1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES1.setVisible(false);
				DemiTourDroiteEES1.setVisible(false);
				QuartdeTourGaucheEES1.setVisible(false);
				PositioninitialeEES1.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1DD.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEES1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES1.setVisible(false);
				DemiTourDroiteEES1.setVisible(false);
				QuartdeTourGaucheEES1.setVisible(false);
				PositioninitialeEES1.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1DD.setBounds(375, 425, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image4QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});
		PositioninitialeEES1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES1.setVisible(false);
				DemiTourDroiteEES1.setVisible(false);
				QuartdeTourGaucheEES1.setVisible(false);
				PositioninitialeEES1.setVisible(false);

				image1.setVisible(false);
				image4.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1DD.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEL1 = new JButton("1/4 D");
		QuartdeTourDroiteEEL1.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEL1);
		QuartdeTourDroiteEEL1.setVisible(false);

		JButton DemiTourDroiteEEL1 = new JButton("1/2 Tour");
		DemiTourDroiteEEL1.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEL1);
		DemiTourDroiteEEL1.setVisible(false);

		JButton QuartdeTourGaucheEEL1 = new JButton("1/4 G");
		QuartdeTourGaucheEEL1.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEL1);
		QuartdeTourGaucheEEL1.setVisible(false);

		JButton PositioninitialeEEL1 = new JButton("-");
		PositioninitialeEEL1.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEL1);
		PositioninitialeEEL1.setVisible(false);

		LaneEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEL1.setVisible(true);
				DemiTourDroiteEEL1.setVisible(true);
				QuartdeTourGaucheEEL1.setVisible(true);
				PositioninitialeEEL1.setVisible(true);

			}
		});

		QuartdeTourDroiteEEL1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL1.setVisible(false);
				DemiTourDroiteEEL1.setVisible(false);
				QuartdeTourGaucheEEL1.setVisible(false);
				PositioninitialeEEL1.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1DD.setBounds(600, 425, 200, 200);
				image5QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image5DD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);

			}
		});

		DemiTourDroiteEEL1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL1.setVisible(false);
				DemiTourDroiteEEL1.setVisible(false);
				QuartdeTourGaucheEEL1.setVisible(false);
				PositioninitialeEEL1.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1DD.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);
				image1QD.setVisible(false);
				image5DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEL1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL1.setVisible(false);
				DemiTourDroiteEEL1.setVisible(false);
				QuartdeTourGaucheEEL1.setVisible(false);
				PositioninitialeEEL1.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1DD.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image5DD.setVisible(false);

			}
		});
		PositioninitialeEEL1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL1.setVisible(false);
				DemiTourDroiteEEL1.setVisible(false);
				QuartdeTourGaucheEEL1.setVisible(false);
				PositioninitialeEEL1.setVisible(false);

				image1.setVisible(false);
				image5.setBounds(375, 200, 200, 200);

				image1DD.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);
				image1QD.setVisible(false);
				image5DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEM1 = new JButton("1/4 D");
		QuartdeTourDroiteEEM1.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEM1);
		QuartdeTourDroiteEEM1.setVisible(false);

		JButton DemiTourDroiteEEM1 = new JButton("1/2 Tour");
		DemiTourDroiteEEM1.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEM1);
		DemiTourDroiteEEM1.setVisible(false);

		JButton QuartdeTourGaucheEEM1 = new JButton("1/4 G");
		QuartdeTourGaucheEEM1.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEM1);
		QuartdeTourGaucheEEM1.setVisible(false);

		JButton PositioninitialeEEM1 = new JButton("-");
		PositioninitialeEEM1.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEM1);
		PositioninitialeEEM1.setVisible(false);

		MadameEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEM1.setVisible(true);
				DemiTourDroiteEEM1.setVisible(true);
				QuartdeTourGaucheEEM1.setVisible(true);
				PositioninitialeEEM1.setVisible(true);

			}
		});

		QuartdeTourDroiteEEM1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM1.setVisible(false);
				DemiTourDroiteEEM1.setVisible(false);
				QuartdeTourGaucheEEM1.setVisible(false);
				PositioninitialeEEM1.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1DD.setBounds(825, 425, 200, 200);
				image6QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image6DD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);

			}
		});

		DemiTourDroiteEEM1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM1.setVisible(false);
				DemiTourDroiteEEM1.setVisible(false);
				QuartdeTourGaucheEEM1.setVisible(false);
				PositioninitialeEEM1.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1DD.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);
				image1QD.setVisible(false);
				image6DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEM1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM1.setVisible(false);
				DemiTourDroiteEEM1.setVisible(false);
				QuartdeTourGaucheEEM1.setVisible(false);
				PositioninitialeEEM1.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1DD.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image6DD.setVisible(false);

			}
		});
		PositioninitialeEEM1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM1.setVisible(false);
				DemiTourDroiteEEM1.setVisible(false);
				QuartdeTourGaucheEEM1.setVisible(false);
				PositioninitialeEEM1.setVisible(false);

				image1.setVisible(false);
				image6.setBounds(375, 200, 200, 200);
				image1DD.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);
				image1QD.setVisible(false);
				image6DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEMS1 = new JButton("1/4 D");
		QuartdeTourDroiteEEMS1.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEMS1);
		QuartdeTourDroiteEEMS1.setVisible(false);

		JButton DemiTourDroiteEEMS1 = new JButton("1/2 Tour");
		DemiTourDroiteEEMS1.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEMS1);
		DemiTourDroiteEEMS1.setVisible(false);

		JButton QuartdeTourGaucheEEMS1 = new JButton("1/4 G");
		QuartdeTourGaucheEEMS1.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEMS1);
		QuartdeTourGaucheEEMS1.setVisible(false);

		JButton PositioninitialeEEMS1 = new JButton("-");
		PositioninitialeEEMS1.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEMS1);
		PositioninitialeEEMS1.setVisible(false);

		StealthyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEMS1.setVisible(true);
				DemiTourDroiteEEMS1.setVisible(true);
				QuartdeTourGaucheEEMS1.setVisible(true);
				PositioninitialeEEMS1.setVisible(true);

			}
		});

		QuartdeTourDroiteEEMS1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS1.setVisible(false);
				DemiTourDroiteEEMS1.setVisible(false);
				QuartdeTourGaucheEEMS1.setVisible(false);
				PositioninitialeEEMS1.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1DD.setBounds(375, 650, 200, 200);
				image7QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image7QD.setVisible(false);
				image1QG.setVisible(false);
				image7QG.setVisible(false);

			}
		});

		DemiTourDroiteEEMS1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS1.setVisible(false);
				DemiTourDroiteEEMS1.setVisible(false);
				QuartdeTourGaucheEEMS1.setVisible(false);
				PositioninitialeEEMS1.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1DD.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1QD.setVisible(false);
				image7QD.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image7QG.setVisible(false);

			}
		});
		QuartdeTourGaucheEEMS1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS1.setVisible(false);
				DemiTourDroiteEEMS1.setVisible(false);
				QuartdeTourGaucheEEMS1.setVisible(false);
				PositioninitialeEEMS1.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1DD.setBounds(375, 650, 200, 200);
				image7DD.setVisible(false);
				image1QG.setVisible(false);
				image7QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image7DD.setVisible(false);

			}
		});
		PositioninitialeEEMS1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS1.setVisible(false);
				DemiTourDroiteEEMS1.setVisible(false);
				QuartdeTourGaucheEEMS1.setVisible(false);
				PositioninitialeEEMS1.setVisible(false);

				image1.setVisible(false);
				image7.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image7QG.setVisible(false);
				image1DD.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1QD.setVisible(false);
				image7DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEGU1 = new JButton("1/4 D");
		QuartdeTourDroiteEEGU1.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEGU1);
		QuartdeTourDroiteEEGU1.setVisible(false);

		JButton DemiTourDroiteEEGU1 = new JButton("1/2 Tour");
		DemiTourDroiteEEGU1.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEGU1);
		DemiTourDroiteEEGU1.setVisible(false);

		JButton QuartdeTourGaucheEEGU1 = new JButton("1/4 G");
		QuartdeTourGaucheEEGU1.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEGU1);
		QuartdeTourGaucheEEGU1.setVisible(false);

		JButton PositioninitialeEEGU1 = new JButton("-");
		PositioninitialeEEGU1.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEGU1);
		PositioninitialeEEGU1.setVisible(false);

		GullEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEGU1.setVisible(true);
				DemiTourDroiteEEGU1.setVisible(true);
				QuartdeTourGaucheEEGU1.setVisible(true);
				PositioninitialeEEGU1.setVisible(true);

			}
		});

		QuartdeTourDroiteEEGU1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU1.setVisible(false);
				DemiTourDroiteEEGU1.setVisible(false);
				QuartdeTourGaucheEEGU1.setVisible(false);
				PositioninitialeEEGU1.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1DD.setBounds(825, 650, 200, 200);
				image9QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image9DD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);

			}
		});

		DemiTourDroiteEEGU1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU1.setVisible(false);
				DemiTourDroiteEEGU1.setVisible(false);
				QuartdeTourGaucheEEGU1.setVisible(false);
				PositioninitialeEEGU1.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1DD.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);
				image1QD.setVisible(false);
				image9DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEGU1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU1.setVisible(false);
				DemiTourDroiteEEGU1.setVisible(false);
				QuartdeTourGaucheEEGU1.setVisible(false);
				PositioninitialeEEGU1.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1DD.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		PositioninitialeEEGU1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU1.setVisible(false);
				DemiTourDroiteEEGU1.setVisible(false);
				QuartdeTourGaucheEEGU1.setVisible(false);
				PositioninitialeEEGU1.setVisible(false);

				image1.setVisible(false);
				image9.setBounds(375, 200, 200, 200);
				image1DD.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);
				image1QD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEG1 = new JButton("1/4 D");
		QuartdeTourDroiteEEG1.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEG1);
		QuartdeTourDroiteEEG1.setVisible(false);

		JButton DemiTourDroiteEEG1 = new JButton("1/2 Tour");
		DemiTourDroiteEEG1.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEG1);
		DemiTourDroiteEEG1.setVisible(false);

		JButton QuartdeTourGaucheEEG1 = new JButton("1/4 G");
		QuartdeTourGaucheEEG1.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEG1);
		QuartdeTourGaucheEEG1.setVisible(false);

		JButton PositioninitialeEEG1 = new JButton("-");
		PositioninitialeEEG1.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEG1);
		PositioninitialeEEG1.setVisible(false);

		GoodleyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEG1.setVisible(true);
				DemiTourDroiteEEG1.setVisible(true);
				QuartdeTourGaucheEEG1.setVisible(true);
				PositioninitialeEEG1.setVisible(true);

			}
		});

		QuartdeTourDroiteEEG1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG1.setVisible(false);
				DemiTourDroiteEEG1.setVisible(false);
				QuartdeTourGaucheEEG1.setVisible(false);
				PositioninitialeEEG1.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1DD.setBounds(600, 650, 200, 200);
				image8QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image8DD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);

			}
		});

		DemiTourDroiteEEG1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG1.setVisible(false);
				DemiTourDroiteEEG1.setVisible(false);
				QuartdeTourGaucheEEG1.setVisible(false);
				PositioninitialeEEG1.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1DD.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);
				image1QD.setVisible(false);
				image8DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEG1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG1.setVisible(false);
				DemiTourDroiteEEG1.setVisible(false);
				QuartdeTourGaucheEEG1.setVisible(false);
				PositioninitialeEEG1.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1DD.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image8DD.setVisible(false);

			}
		});

		PositioninitialeEEG1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG1.setVisible(false);
				DemiTourDroiteEEG1.setVisible(false);
				QuartdeTourGaucheEEG1.setVisible(false);
				PositioninitialeEEG1.setVisible(false);

				image1.setVisible(false);
				image8.setBounds(375, 200, 200, 200);
				image1DD.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);
				image1QD.setVisible(false);
				image8DD.setVisible(false);

			}
		});

		QuartdeTourGaucheE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteE.setVisible(false);
				DemiTourDroiteE.setVisible(false);
				QuartdeTourGaucheE.setVisible(false);
				PositioninitialeE.setVisible(false);

				JeremyBertEE.setVisible(true);
				PizerEE.setVisible(true);
				SmithEE.setVisible(true);
				LaneEE.setVisible(true);
				MadameEE.setVisible(true);
				StealthyEE.setVisible(true);
				GullEE.setVisible(true);
				GoodleyEE.setVisible(true);

			}

		});

		JButton QuartdeTourDroiteEE2 = new JButton("1/4 D");
		QuartdeTourDroiteEE2.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEE2);
		QuartdeTourDroiteEE2.setVisible(false);

		JButton DemiTourDroiteEE2 = new JButton("1/2 Tour");
		DemiTourDroiteEE2.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEE2);
		DemiTourDroiteEE2.setVisible(false);

		JButton QuartdeTourGaucheEE2 = new JButton("1/4 G");
		QuartdeTourGaucheEE2.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEE2);
		QuartdeTourGaucheEE2.setVisible(false);

		JButton PositioninitialeEE2 = new JButton("-");
		PositioninitialeEE2.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEE2);
		PositioninitialeEE2.setVisible(false);

		JeremyBertEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEE2.setVisible(true);
				DemiTourDroiteEE2.setVisible(true);
				QuartdeTourGaucheEE2.setVisible(true);
				PositioninitialeEE2.setVisible(true);

				/*
				 * image1.setVisible(false); image2.setVisible(false); image1QD.setBounds(600,
				 * 200, 200,200); image2QD.setBounds(375, 200, 200,200);
				 * image1QG.setVisible(false); image2QG.setVisible(false);
				 */

			}
		});

		QuartdeTourDroiteEE2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE2.setVisible(false);
				DemiTourDroiteEE2.setVisible(false);
				QuartdeTourGaucheEE2.setVisible(false);
				PositioninitialeEE2.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1QG.setBounds(600, 200, 200, 200);
				image2QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image2DD.setVisible(false);
				image1DD.setVisible(false);
				image2QG.setVisible(false);

			}
		});

		DemiTourDroiteEE2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE2.setVisible(false);
				DemiTourDroiteEE2.setVisible(false);
				QuartdeTourGaucheEE2.setVisible(false);
				PositioninitialeEE2.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1QG.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1DD.setVisible(false);
				image2QG.setVisible(false);
				image1QD.setVisible(false);
				image2DD.setBounds(375, 200, 200, 200);
			}
		});

		QuartdeTourGaucheEE2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE2.setVisible(false);
				DemiTourDroiteEE2.setVisible(false);
				QuartdeTourGaucheEE2.setVisible(false);
				PositioninitialeEE2.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1QG.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1DD.setVisible(false);
				image2QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		PositioninitialeEE2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE2.setVisible(false);
				DemiTourDroiteEE2.setVisible(false);
				QuartdeTourGaucheEE2.setVisible(false);
				PositioninitialeEE2.setVisible(false);

				image1.setVisible(false);
				image2.setBounds(375, 200, 200, 200);
				image1QG.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1DD.setVisible(false);
				image2QG.setVisible(false);
				image1QD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEP2 = new JButton("1/4 D");
		QuartdeTourDroiteEEP2.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEP2);
		QuartdeTourDroiteEEP2.setVisible(false);

		JButton DemiTourDroiteEEP2 = new JButton("1/2 Tour");
		DemiTourDroiteEEP2.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEP2);
		DemiTourDroiteEEP2.setVisible(false);

		JButton QuartdeTourGaucheEEP2 = new JButton("1/4 G");
		QuartdeTourGaucheEEP2.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEP2);
		QuartdeTourGaucheEEP2.setVisible(false);

		JButton PositioninitialeEEP2 = new JButton("-");
		PositioninitialeEEP2.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEP2);
		PositioninitialeEEP2.setVisible(false);

		PizerEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEEP2.setVisible(true);
				DemiTourDroiteEEP2.setVisible(true);
				QuartdeTourGaucheEEP2.setVisible(true);
				PositioninitialeEEP2.setVisible(true);

			}
		});

		QuartdeTourDroiteEEP2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP2.setVisible(false);
				DemiTourDroiteEEP2.setVisible(false);
				QuartdeTourGaucheEEP2.setVisible(false);
				PositioninitialeEEP2.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1QG.setBounds(825, 200, 200, 200);
				image3QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image3QD.setVisible(false);
				image1DD.setVisible(false);
				image3QG.setVisible(false);

			}
		});

		DemiTourDroiteEEP2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP2.setVisible(false);
				DemiTourDroiteEEP2.setVisible(false);
				QuartdeTourGaucheEEP2.setVisible(false);
				PositioninitialeEEP2.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1QG.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1DD.setVisible(false);
				image3QG.setVisible(false);
				image1QD.setVisible(false);
				image3DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEP2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP2.setVisible(false);
				DemiTourDroiteEEP2.setVisible(false);
				QuartdeTourGaucheEEP2.setVisible(false);
				PositioninitialeEEP2.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1QG.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1DD.setVisible(false);
				image3QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image3DD.setVisible(false);

			}
		});
		PositioninitialeEEP2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP2.setVisible(false);
				DemiTourDroiteEEP2.setVisible(false);
				QuartdeTourGaucheEEP2.setVisible(false);
				PositioninitialeEEP2.setVisible(false);

				image1.setVisible(false);
				image3.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image3QG.setVisible(false);
				image1QG.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QD.setVisible(false);
				image3DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEES2 = new JButton("1/4 D");
		QuartdeTourDroiteEES2.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEES2);
		QuartdeTourDroiteEES2.setVisible(false);

		JButton DemiTourDroiteEES2 = new JButton("1/2 Tour");
		DemiTourDroiteEES2.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEES2);
		DemiTourDroiteEES2.setVisible(false);

		JButton QuartdeTourGaucheEES2 = new JButton("1/4 G");
		QuartdeTourGaucheEES2.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEES2);
		QuartdeTourGaucheEES2.setVisible(false);

		JButton PositioninitialeEES2 = new JButton("-");
		PositioninitialeEES2.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEES2);
		PositioninitialeEES2.setVisible(false);

		SmithEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEES2.setVisible(true);
				DemiTourDroiteEES2.setVisible(true);
				QuartdeTourGaucheEES2.setVisible(true);
				PositioninitialeEES2.setVisible(true);

			}
		});

		QuartdeTourDroiteEES2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES2.setVisible(false);
				DemiTourDroiteEES2.setVisible(false);
				QuartdeTourGaucheEES2.setVisible(false);
				PositioninitialeEES2.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1QG.setBounds(375, 425, 200, 200);
				image4QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image4QG.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		DemiTourDroiteEES2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES2.setVisible(false);
				DemiTourDroiteEES2.setVisible(false);
				QuartdeTourGaucheEES2.setVisible(false);
				PositioninitialeEES2.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1QG.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1DD.setVisible(false);
				image4QG.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEES2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES2.setVisible(false);
				DemiTourDroiteEES2.setVisible(false);
				QuartdeTourGaucheEES2.setVisible(false);
				PositioninitialeEES2.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1QG.setBounds(375, 425, 200, 200);
				image2QD.setVisible(false);
				image1DD.setVisible(false);
				image4QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});
		PositioninitialeEES2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES2.setVisible(false);
				DemiTourDroiteEES2.setVisible(false);
				QuartdeTourGaucheEES2.setVisible(false);
				PositioninitialeEES2.setVisible(false);

				image1.setVisible(false);
				image4.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image4QG.setVisible(false);
				image1QG.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEL2 = new JButton("1/4 D");
		QuartdeTourDroiteEEL2.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEL2);
		QuartdeTourDroiteEEL2.setVisible(false);

		JButton DemiTourDroiteEEL2 = new JButton("1/2 Tour");
		DemiTourDroiteEEL2.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEL2);
		DemiTourDroiteEEL2.setVisible(false);

		JButton QuartdeTourGaucheEEL2 = new JButton("1/4 G");
		QuartdeTourGaucheEEL2.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEL2);
		QuartdeTourGaucheEEL2.setVisible(false);

		JButton PositioninitialeEEL2 = new JButton("-");
		PositioninitialeEEL2.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEL2);
		PositioninitialeEEL2.setVisible(false);

		LaneEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEL2.setVisible(true);
				DemiTourDroiteEEL2.setVisible(true);
				QuartdeTourGaucheEEL2.setVisible(true);
				PositioninitialeEEL2.setVisible(true);

			}
		});

		QuartdeTourDroiteEEL2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL2.setVisible(false);
				DemiTourDroiteEEL2.setVisible(false);
				QuartdeTourGaucheEEL2.setVisible(false);
				PositioninitialeEEL2.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1QG.setBounds(600, 425, 200, 200);
				image5QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image5DD.setVisible(false);
				image1DD.setVisible(false);
				image5QG.setVisible(false);

			}
		});

		DemiTourDroiteEEL2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL2.setVisible(false);
				DemiTourDroiteEEL2.setVisible(false);
				QuartdeTourGaucheEEL2.setVisible(false);
				PositioninitialeEEL2.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1QG.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1DD.setVisible(false);
				image5QG.setVisible(false);
				image1QD.setVisible(false);
				image5DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEL2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL2.setVisible(false);
				DemiTourDroiteEEL2.setVisible(false);
				QuartdeTourGaucheEEL2.setVisible(false);
				PositioninitialeEEL2.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1QG.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1DD.setVisible(false);
				image5QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image5DD.setVisible(false);

			}
		});
		PositioninitialeEEL2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL2.setVisible(false);
				DemiTourDroiteEEL2.setVisible(false);
				QuartdeTourGaucheEEL2.setVisible(false);
				PositioninitialeEEL2.setVisible(false);

				image1.setVisible(false);
				image5.setBounds(375, 200, 200, 200);

				image1QG.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1DD.setVisible(false);
				image5QG.setVisible(false);
				image1QD.setVisible(false);
				image5DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEM2 = new JButton("1/4 D");
		QuartdeTourDroiteEEM2.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEM2);
		QuartdeTourDroiteEEM2.setVisible(false);

		JButton DemiTourDroiteEEM2 = new JButton("1/2 Tour");
		DemiTourDroiteEEM2.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEM2);
		DemiTourDroiteEEM2.setVisible(false);

		JButton QuartdeTourGaucheEEM2 = new JButton("1/4 G");
		QuartdeTourGaucheEEM2.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEM2);
		QuartdeTourGaucheEEM2.setVisible(false);

		JButton PositioninitialeEEM2 = new JButton("-");
		PositioninitialeEEM2.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEM2);
		PositioninitialeEEM2.setVisible(false);

		MadameEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEM2.setVisible(true);
				DemiTourDroiteEEM2.setVisible(true);
				QuartdeTourGaucheEEM2.setVisible(true);
				PositioninitialeEEM2.setVisible(true);

			}
		});

		QuartdeTourDroiteEEM2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM2.setVisible(false);
				DemiTourDroiteEEM2.setVisible(false);
				QuartdeTourGaucheEEM2.setVisible(false);
				PositioninitialeEEM2.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1QG.setBounds(825, 425, 200, 200);
				image6QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image6DD.setVisible(false);
				image1DD.setVisible(false);
				image6QG.setVisible(false);

			}
		});

		DemiTourDroiteEEM2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM2.setVisible(false);
				DemiTourDroiteEEM2.setVisible(false);
				QuartdeTourGaucheEEM2.setVisible(false);
				PositioninitialeEEM2.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1QG.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1DD.setVisible(false);
				image6QG.setVisible(false);
				image1QD.setVisible(false);
				image6DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEM2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM2.setVisible(false);
				DemiTourDroiteEEM2.setVisible(false);
				QuartdeTourGaucheEEM2.setVisible(false);
				PositioninitialeEEM2.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1QG.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1DD.setVisible(false);
				image6QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image6DD.setVisible(false);

			}
		});
		PositioninitialeEEM2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM2.setVisible(false);
				DemiTourDroiteEEM2.setVisible(false);
				QuartdeTourGaucheEEM2.setVisible(false);
				PositioninitialeEEM2.setVisible(false);

				image1.setVisible(false);
				image6.setBounds(375, 200, 200, 200);
				image1QG.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1DD.setVisible(false);
				image6QG.setVisible(false);
				image1QD.setVisible(false);
				image6DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEMS2 = new JButton("1/4 D");
		QuartdeTourDroiteEEMS2.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEMS2);
		QuartdeTourDroiteEEMS2.setVisible(false);

		JButton DemiTourDroiteEEMS2 = new JButton("1/2 Tour");
		DemiTourDroiteEEMS2.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEMS2);
		DemiTourDroiteEEMS2.setVisible(false);

		JButton QuartdeTourGaucheEEMS2 = new JButton("1/4 G");
		QuartdeTourGaucheEEMS2.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEMS2);
		QuartdeTourGaucheEEMS2.setVisible(false);

		JButton PositioninitialeEEMS2 = new JButton("-");
		PositioninitialeEEMS2.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEMS2);
		PositioninitialeEEMS2.setVisible(false);

		StealthyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEMS2.setVisible(true);
				DemiTourDroiteEEMS2.setVisible(true);
				QuartdeTourGaucheEEMS2.setVisible(true);
				PositioninitialeEEMS2.setVisible(true);

			}
		});

		QuartdeTourDroiteEEMS2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS2.setVisible(false);
				DemiTourDroiteEEMS2.setVisible(false);
				QuartdeTourGaucheEEMS2.setVisible(false);
				PositioninitialeEEMS2.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1QG.setBounds(375, 650, 200, 200);
				image7QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image7QD.setVisible(false);
				image1DD.setVisible(false);
				image7QG.setVisible(false);

			}
		});

		DemiTourDroiteEEMS2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS2.setVisible(false);
				DemiTourDroiteEEMS2.setVisible(false);
				QuartdeTourGaucheEEMS2.setVisible(false);
				PositioninitialeEEMS2.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1QG.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1QD.setVisible(false);
				image7QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image7QG.setVisible(false);

			}
		});
		QuartdeTourGaucheEEMS2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS2.setVisible(false);
				DemiTourDroiteEEMS2.setVisible(false);
				QuartdeTourGaucheEEMS2.setVisible(false);
				PositioninitialeEEMS2.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1QG.setBounds(375, 650, 200, 200);
				image7DD.setVisible(false);
				image1DD.setVisible(false);
				image7QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image7DD.setVisible(false);

			}
		});
		PositioninitialeEEMS2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS2.setVisible(false);
				DemiTourDroiteEEMS2.setVisible(false);
				QuartdeTourGaucheEEMS2.setVisible(false);
				PositioninitialeEEMS2.setVisible(false);

				image1.setVisible(false);
				image7.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image7QG.setVisible(false);
				image1QG.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1QD.setVisible(false);
				image7DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEGU2 = new JButton("1/4 D");
		QuartdeTourDroiteEEGU2.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEGU2);
		QuartdeTourDroiteEEGU2.setVisible(false);

		JButton DemiTourDroiteEEGU2 = new JButton("1/2 Tour");
		DemiTourDroiteEEGU2.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEGU2);
		DemiTourDroiteEEGU2.setVisible(false);

		JButton QuartdeTourGaucheEEGU2 = new JButton("1/4 G");
		QuartdeTourGaucheEEGU2.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEGU2);
		QuartdeTourGaucheEEGU2.setVisible(false);

		JButton PositioninitialeEEGU2 = new JButton("-");
		PositioninitialeEEGU2.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEGU2);
		PositioninitialeEEGU2.setVisible(false);

		GullEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEGU2.setVisible(true);
				DemiTourDroiteEEGU2.setVisible(true);
				QuartdeTourGaucheEEGU2.setVisible(true);
				PositioninitialeEEGU2.setVisible(true);

			}
		});

		QuartdeTourDroiteEEGU2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU2.setVisible(false);
				DemiTourDroiteEEGU2.setVisible(false);
				QuartdeTourGaucheEEGU2.setVisible(false);
				PositioninitialeEEGU2.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1QG.setBounds(825, 650, 200, 200);
				image9QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image9DD.setVisible(false);
				image1DD.setVisible(false);
				image9QG.setVisible(false);

			}
		});

		DemiTourDroiteEEGU2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU2.setVisible(false);
				DemiTourDroiteEEGU2.setVisible(false);
				QuartdeTourGaucheEEGU2.setVisible(false);
				PositioninitialeEEGU2.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1QG.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1DD.setVisible(false);
				image9QG.setVisible(false);
				image1QD.setVisible(false);
				image9DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEGU2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU2.setVisible(false);
				DemiTourDroiteEEGU2.setVisible(false);
				QuartdeTourGaucheEEGU2.setVisible(false);
				PositioninitialeEEGU2.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1QG.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1DD.setVisible(false);
				image9QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		PositioninitialeEEGU2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU2.setVisible(false);
				DemiTourDroiteEEGU2.setVisible(false);
				QuartdeTourGaucheEEGU2.setVisible(false);
				PositioninitialeEEGU2.setVisible(false);

				image1.setVisible(false);
				image9.setBounds(375, 200, 200, 200);
				image1QG.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1DD.setVisible(false);
				image9QG.setVisible(false);
				image1QD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEG2 = new JButton("1/4 D");
		QuartdeTourDroiteEEG2.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEG2);
		QuartdeTourDroiteEEG2.setVisible(false);

		JButton DemiTourDroiteEEG2 = new JButton("1/2 Tour");
		DemiTourDroiteEEG2.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEG2);
		DemiTourDroiteEEG2.setVisible(false);

		JButton QuartdeTourGaucheEEG2 = new JButton("1/4 G");
		QuartdeTourGaucheEEG2.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEG2);
		QuartdeTourGaucheEEG2.setVisible(false);

		JButton PositioninitialeEEG2 = new JButton("-");
		PositioninitialeEEG2.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEG2);
		PositioninitialeEEG2.setVisible(false);

		GoodleyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEG2.setVisible(true);
				DemiTourDroiteEEG2.setVisible(true);
				QuartdeTourGaucheEEG2.setVisible(true);
				PositioninitialeEEG2.setVisible(true);

			}
		});

		QuartdeTourDroiteEEG2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG2.setVisible(false);
				DemiTourDroiteEEG2.setVisible(false);
				QuartdeTourGaucheEEG2.setVisible(false);
				PositioninitialeEEG2.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1QG.setBounds(600, 650, 200, 200);
				image8QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image8DD.setVisible(false);
				image1DD.setVisible(false);
				image8QG.setVisible(false);

			}
		});

		DemiTourDroiteEEG2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG2.setVisible(false);
				DemiTourDroiteEEG2.setVisible(false);
				QuartdeTourGaucheEEG2.setVisible(false);
				PositioninitialeEEG2.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1QG.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1DD.setVisible(false);
				image8QG.setVisible(false);
				image1QD.setVisible(false);
				image8DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEG2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG2.setVisible(false);
				DemiTourDroiteEEG2.setVisible(false);
				QuartdeTourGaucheEEG2.setVisible(false);
				PositioninitialeEEG2.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1QG.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1DD.setVisible(false);
				image8QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image8DD.setVisible(false);

			}
		});

		PositioninitialeEEG2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG2.setVisible(false);
				DemiTourDroiteEEG2.setVisible(false);
				QuartdeTourGaucheEEG2.setVisible(false);
				PositioninitialeEEG2.setVisible(false);

				image1.setVisible(false);
				image8.setBounds(375, 200, 200, 200);
				image1QG.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1DD.setVisible(false);
				image8QG.setVisible(false);
				image1QD.setVisible(false);
				image8DD.setVisible(false);

			}
		});
		//////////////////////////// place ////////

		PositioninitialeE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteE.setVisible(false);
				DemiTourDroiteE.setVisible(false);
				QuartdeTourGaucheE.setVisible(false);

				PositioninitialeE.setVisible(false);

				JeremyBertEE.setVisible(true);
				PizerEE.setVisible(true);
				SmithEE.setVisible(true);
				LaneEE.setVisible(true);
				MadameEE.setVisible(true);
				StealthyEE.setVisible(true);
				GullEE.setVisible(true);
				GoodleyEE.setVisible(true);

			}

		});

		JButton QuartdeTourDroiteEE3 = new JButton("1/4 D");
		QuartdeTourDroiteEE3.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEE3);
		QuartdeTourDroiteEE3.setVisible(false);

		JButton DemiTourDroiteEE3 = new JButton("1/2 Tour");
		DemiTourDroiteEE3.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEE3);
		DemiTourDroiteEE3.setVisible(false);

		JButton QuartdeTourGaucheEE3 = new JButton("1/4 G");
		QuartdeTourGaucheEE3.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEE3);
		QuartdeTourGaucheEE3.setVisible(false);

		JButton PositioninitialeEE3 = new JButton("-");
		PositioninitialeEE3.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEE3);
		PositioninitialeEE3.setVisible(false);

		JeremyBertEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEE3.setVisible(true);
				DemiTourDroiteEE3.setVisible(true);
				QuartdeTourGaucheEE1.setVisible(true);
				PositioninitialeEE3.setVisible(true);

				/*
				 * image1.setVisible(false); image2.setVisible(false); image1QD.setBounds(600,
				 * 200, 200,200); image2QD.setBounds(375, 200, 200,200);
				 * image1QG.setVisible(false); image2QG.setVisible(false);
				 */

			}
		});

		QuartdeTourDroiteEE3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE3.setVisible(false);
				DemiTourDroiteEE3.setVisible(false);
				QuartdeTourGaucheEE1.setVisible(false);
				PositioninitialeEE3.setVisible(false);

				image1DD.setVisible(false);
				image2.setVisible(false);
				image1.setBounds(600, 200, 200, 200);
				image2QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image2DD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);

			}
		});

		DemiTourDroiteEE3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE3.setVisible(false);
				DemiTourDroiteEE3.setVisible(false);
				QuartdeTourGaucheEE1.setVisible(false);
				PositioninitialeEE3.setVisible(false);

				image1DD.setVisible(false);
				image2.setVisible(false);
				image1.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);
				image1QD.setVisible(false);
				image2DD.setBounds(375, 200, 200, 200);
			}
		});

		QuartdeTourGaucheEE1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE3.setVisible(false);
				DemiTourDroiteEE3.setVisible(false);
				QuartdeTourGaucheEE1.setVisible(false);
				PositioninitialeEE3.setVisible(false);

				image1DD.setVisible(false);
				image2.setVisible(false);
				image1.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		PositioninitialeEE3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE3.setVisible(false);
				DemiTourDroiteEE3.setVisible(false);
				QuartdeTourGaucheEE1.setVisible(false);
				PositioninitialeEE3.setVisible(false);

				image1DD.setVisible(false);
				image2.setBounds(375, 200, 200, 200);
				image1.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);
				image1QD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEP3 = new JButton("1/4 D");
		QuartdeTourDroiteEEP3.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEP3);
		QuartdeTourDroiteEEP3.setVisible(false);

		JButton DemiTourDroiteEEP3 = new JButton("1/2 Tour");
		DemiTourDroiteEEP3.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEP3);
		DemiTourDroiteEEP3.setVisible(false);

		JButton QuartdeTourGaucheEEP3 = new JButton("1/4 G");
		QuartdeTourGaucheEEP3.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEP3);
		QuartdeTourGaucheEEP3.setVisible(false);

		JButton PositioninitialeEEP3 = new JButton("-");
		PositioninitialeEEP3.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEP3);
		PositioninitialeEEP3.setVisible(false);

		PizerEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEEP3.setVisible(true);
				DemiTourDroiteEEP3.setVisible(true);
				QuartdeTourGaucheEEP3.setVisible(true);
				PositioninitialeEEP3.setVisible(true);

			}
		});

		QuartdeTourDroiteEEP3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP3.setVisible(false);
				DemiTourDroiteEEP3.setVisible(false);
				QuartdeTourGaucheEEP3.setVisible(false);
				PositioninitialeEEP3.setVisible(false);

				image1DD.setVisible(false);
				image3.setVisible(false);
				image1.setBounds(825, 200, 200, 200);
				image3QD.setBounds(375, 200, 200, 200);
				image3DD.setVisible(false);
				image1QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setVisible(false);

			}
		});

		DemiTourDroiteEEP3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP3.setVisible(false);
				DemiTourDroiteEEP3.setVisible(false);
				QuartdeTourGaucheEEP3.setVisible(false);
				PositioninitialeEEP3.setVisible(false);

				image1DD.setVisible(false);
				image3.setVisible(false);
				image1.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setVisible(false);
				image1QD.setVisible(false);
				image3DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEP3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP3.setVisible(false);
				DemiTourDroiteEEP3.setVisible(false);
				QuartdeTourGaucheEEP3.setVisible(false);
				PositioninitialeEEP3.setVisible(false);

				image1DD.setVisible(false);
				image3.setVisible(false);
				image1.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image3DD.setVisible(false);

			}
		});
		PositioninitialeEEP3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP3.setVisible(false);
				DemiTourDroiteEEP3.setVisible(false);
				QuartdeTourGaucheEEP3.setVisible(false);
				PositioninitialeEEP3.setVisible(false);

				image1DD.setVisible(false);
				image3.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image3QG.setVisible(false);
				image1.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QD.setVisible(false);
				image3DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEES3 = new JButton("1/4 D");
		QuartdeTourDroiteEES3.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEES3);
		QuartdeTourDroiteEES3.setVisible(false);

		JButton DemiTourDroiteEES3 = new JButton("1/2 Tour");
		DemiTourDroiteEES3.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEES3);
		DemiTourDroiteEES3.setVisible(false);

		JButton QuartdeTourGaucheEES3 = new JButton("1/4 G");
		QuartdeTourGaucheEES3.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEES3);
		QuartdeTourGaucheEES3.setVisible(false);

		JButton PositioninitialeEES3 = new JButton("-");
		PositioninitialeEES3.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEES3);
		PositioninitialeEES3.setVisible(false);

		SmithEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEES3.setVisible(true);
				DemiTourDroiteEES3.setVisible(true);
				QuartdeTourGaucheEES3.setVisible(true);
				PositioninitialeEES3.setVisible(true);

			}
		});

		QuartdeTourDroiteEES3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES3.setVisible(false);
				DemiTourDroiteEES3.setVisible(false);
				QuartdeTourGaucheEES3.setVisible(false);
				PositioninitialeEES3.setVisible(false);

				image1DD.setVisible(false);
				image4.setVisible(false);
				image1.setBounds(375, 425, 200, 200);
				image4QD.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		DemiTourDroiteEES3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES3.setVisible(false);
				DemiTourDroiteEES3.setVisible(false);
				QuartdeTourGaucheEES3.setVisible(false);
				PositioninitialeEES3.setVisible(false);

				image1DD.setVisible(false);
				image4.setVisible(false);
				image1.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEES3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES3.setVisible(false);
				DemiTourDroiteEES3.setVisible(false);
				QuartdeTourGaucheEES3.setVisible(false);
				PositioninitialeEES3.setVisible(false);

				image1DD.setVisible(false);
				image4.setVisible(false);
				image1.setBounds(375, 425, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image4QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});
		PositioninitialeEES3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES3.setVisible(false);
				DemiTourDroiteEES3.setVisible(false);
				QuartdeTourGaucheEES3.setVisible(false);
				PositioninitialeEES3.setVisible(false);

				image1DD.setVisible(false);
				image4.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEL3 = new JButton("1/4 D");
		QuartdeTourDroiteEEL3.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEL3);
		QuartdeTourDroiteEEL3.setVisible(false);

		JButton DemiTourDroiteEEL3 = new JButton("1/2 Tour");
		DemiTourDroiteEEL3.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEL3);
		DemiTourDroiteEEL3.setVisible(false);

		JButton QuartdeTourGaucheEEL3 = new JButton("1/4 G");
		QuartdeTourGaucheEEL3.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEL3);
		QuartdeTourGaucheEEL3.setVisible(false);

		JButton PositioninitialeEEL3 = new JButton("-");
		PositioninitialeEEL3.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEL3);
		PositioninitialeEEL3.setVisible(false);

		LaneEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEL3.setVisible(true);
				DemiTourDroiteEEL3.setVisible(true);
				QuartdeTourGaucheEEL3.setVisible(true);
				PositioninitialeEEL3.setVisible(true);

			}
		});

		QuartdeTourDroiteEEL3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL3.setVisible(false);
				DemiTourDroiteEEL3.setVisible(false);
				QuartdeTourGaucheEEL3.setVisible(false);
				PositioninitialeEEL3.setVisible(false);

				image1DD.setVisible(false);
				image5.setVisible(false);
				image1.setBounds(600, 425, 200, 200);
				image5QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image5DD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);

			}
		});

		DemiTourDroiteEEL3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL3.setVisible(false);
				DemiTourDroiteEEL3.setVisible(false);
				QuartdeTourGaucheEEL3.setVisible(false);
				PositioninitialeEEL3.setVisible(false);

				image1DD.setVisible(false);
				image5.setVisible(false);
				image1.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);
				image1QD.setVisible(false);
				image5DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEL3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL3.setVisible(false);
				DemiTourDroiteEEL3.setVisible(false);
				QuartdeTourGaucheEEL3.setVisible(false);
				PositioninitialeEEL3.setVisible(false);

				image1DD.setVisible(false);
				image5.setVisible(false);
				image1.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image5DD.setVisible(false);

			}
		});
		PositioninitialeEEL3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL3.setVisible(false);
				DemiTourDroiteEEL3.setVisible(false);
				QuartdeTourGaucheEEL3.setVisible(false);
				PositioninitialeEEL3.setVisible(false);

				image1DD.setVisible(false);
				image5.setBounds(375, 200, 200, 200);

				image1.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);
				image1QD.setVisible(false);
				image5DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEM3 = new JButton("1/4 D");
		QuartdeTourDroiteEEM3.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEM3);
		QuartdeTourDroiteEEM3.setVisible(false);

		JButton DemiTourDroiteEEM3 = new JButton("1/2 Tour");
		DemiTourDroiteEEM3.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEM3);
		DemiTourDroiteEEM3.setVisible(false);

		JButton QuartdeTourGaucheEEM3 = new JButton("1/4 G");
		QuartdeTourGaucheEEM3.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEM3);
		QuartdeTourGaucheEEM3.setVisible(false);

		JButton PositioninitialeEEM3 = new JButton("-");
		PositioninitialeEEM3.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEM3);
		PositioninitialeEEM3.setVisible(false);

		MadameEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEM3.setVisible(true);
				DemiTourDroiteEEM3.setVisible(true);
				QuartdeTourGaucheEEM3.setVisible(true);
				PositioninitialeEEM3.setVisible(true);

			}
		});

		QuartdeTourDroiteEEM3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM3.setVisible(false);
				DemiTourDroiteEEM3.setVisible(false);
				QuartdeTourGaucheEEM3.setVisible(false);
				PositioninitialeEEM3.setVisible(false);

				image1DD.setVisible(false);
				image6.setVisible(false);
				image1.setBounds(825, 425, 200, 200);
				image6QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image6DD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);

			}
		});

		DemiTourDroiteEEM3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM3.setVisible(false);
				DemiTourDroiteEEM3.setVisible(false);
				QuartdeTourGaucheEEM3.setVisible(false);
				PositioninitialeEEM3.setVisible(false);

				image1DD.setVisible(false);
				image6.setVisible(false);
				image1.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);
				image1QD.setVisible(false);
				image6DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEM3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM3.setVisible(false);
				DemiTourDroiteEEM3.setVisible(false);
				QuartdeTourGaucheEEM3.setVisible(false);
				PositioninitialeEEM3.setVisible(false);

				image1DD.setVisible(false);
				image6.setVisible(false);
				image1.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image6DD.setVisible(false);

			}
		});
		PositioninitialeEEM3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM3.setVisible(false);
				DemiTourDroiteEEM3.setVisible(false);
				QuartdeTourGaucheEEM3.setVisible(false);
				PositioninitialeEEM3.setVisible(false);

				image1DD.setVisible(false);
				image6.setBounds(375, 200, 200, 200);
				image1.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);
				image1QD.setVisible(false);
				image6DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEMS3 = new JButton("1/4 D");
		QuartdeTourDroiteEEMS3.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEMS3);
		QuartdeTourDroiteEEMS3.setVisible(false);

		JButton DemiTourDroiteEEMS3 = new JButton("1/2 Tour");
		DemiTourDroiteEEMS3.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEMS3);
		DemiTourDroiteEEMS3.setVisible(false);

		JButton QuartdeTourGaucheEEMS3 = new JButton("1/4 G");
		QuartdeTourGaucheEEMS3.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEMS3);
		QuartdeTourGaucheEEMS3.setVisible(false);

		JButton PositioninitialeEEMS3 = new JButton("-");
		PositioninitialeEEMS3.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEMS3);
		PositioninitialeEEMS3.setVisible(false);

		StealthyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEMS3.setVisible(true);
				DemiTourDroiteEEMS3.setVisible(true);
				QuartdeTourGaucheEEMS3.setVisible(true);
				PositioninitialeEEMS3.setVisible(true);

			}
		});

		QuartdeTourDroiteEEMS3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS3.setVisible(false);
				DemiTourDroiteEEMS3.setVisible(false);
				QuartdeTourGaucheEEMS3.setVisible(false);
				PositioninitialeEEMS3.setVisible(false);

				image1DD.setVisible(false);
				image7.setVisible(false);
				image1.setBounds(375, 650, 200, 200);
				image7QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image7QD.setVisible(false);
				image1QG.setVisible(false);
				image7QG.setVisible(false);

			}
		});

		DemiTourDroiteEEMS3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS3.setVisible(false);
				DemiTourDroiteEEMS3.setVisible(false);
				QuartdeTourGaucheEEMS3.setVisible(false);
				PositioninitialeEEMS3.setVisible(false);

				image1DD.setVisible(false);
				image7.setVisible(false);
				image1.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1QD.setVisible(false);
				image7QD.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image7QG.setVisible(false);

			}
		});
		QuartdeTourGaucheEEMS3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS3.setVisible(false);
				DemiTourDroiteEEMS3.setVisible(false);
				QuartdeTourGaucheEEMS3.setVisible(false);
				PositioninitialeEEMS3.setVisible(false);

				image1DD.setVisible(false);
				image7.setVisible(false);
				image1.setBounds(375, 650, 200, 200);
				image7DD.setVisible(false);
				image1QG.setVisible(false);
				image7QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image7DD.setVisible(false);

			}
		});
		PositioninitialeEEMS3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS3.setVisible(false);
				DemiTourDroiteEEMS3.setVisible(false);
				QuartdeTourGaucheEEMS3.setVisible(false);
				PositioninitialeEEMS3.setVisible(false);

				image1DD.setVisible(false);
				image7.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image7QG.setVisible(false);
				image1.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1QD.setVisible(false);
				image7DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEGU3 = new JButton("1/4 D");
		QuartdeTourDroiteEEGU3.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEGU3);
		QuartdeTourDroiteEEGU3.setVisible(false);

		JButton DemiTourDroiteEEGU3 = new JButton("1/2 Tour");
		DemiTourDroiteEEGU3.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEGU3);
		DemiTourDroiteEEGU3.setVisible(false);

		JButton QuartdeTourGaucheEEGU3 = new JButton("1/4 G");
		QuartdeTourGaucheEEGU3.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEGU3);
		QuartdeTourGaucheEEGU3.setVisible(false);

		JButton PositioninitialeEEGU3 = new JButton("-");
		PositioninitialeEEGU3.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEGU3);
		PositioninitialeEEGU3.setVisible(false);

		GullEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEGU3.setVisible(true);
				DemiTourDroiteEEGU3.setVisible(true);
				QuartdeTourGaucheEEGU3.setVisible(true);
				PositioninitialeEEGU3.setVisible(true);

			}
		});

		QuartdeTourDroiteEEGU3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU3.setVisible(false);
				DemiTourDroiteEEGU3.setVisible(false);
				QuartdeTourGaucheEEGU3.setVisible(false);
				PositioninitialeEEGU3.setVisible(false);

				image1DD.setVisible(false);
				image9.setVisible(false);
				image1.setBounds(825, 650, 200, 200);
				image9QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image9DD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);

			}
		});

		DemiTourDroiteEEGU3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU3.setVisible(false);
				DemiTourDroiteEEGU3.setVisible(false);
				QuartdeTourGaucheEEGU3.setVisible(false);
				PositioninitialeEEGU3.setVisible(false);

				image1DD.setVisible(false);
				image9.setVisible(false);
				image1.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);
				image1QD.setVisible(false);
				image9DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEGU3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU3.setVisible(false);
				DemiTourDroiteEEGU3.setVisible(false);
				QuartdeTourGaucheEEGU3.setVisible(false);
				PositioninitialeEEGU3.setVisible(false);

				image1DD.setVisible(false);
				image9.setVisible(false);
				image1.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		PositioninitialeEEGU3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU3.setVisible(false);
				DemiTourDroiteEEGU3.setVisible(false);
				QuartdeTourGaucheEEGU3.setVisible(false);
				PositioninitialeEEGU3.setVisible(false);

				image1DD.setVisible(false);
				image9.setBounds(375, 200, 200, 200);
				image1.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);
				image1QD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEG33 = new JButton("1/4 D");
		QuartdeTourDroiteEEG33.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEG33);
		QuartdeTourDroiteEEG33.setVisible(false);

		JButton DemiTourDroiteEEG3 = new JButton("1/2 Tour");
		DemiTourDroiteEEG3.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEG3);
		DemiTourDroiteEEG3.setVisible(false);

		JButton QuartdeTourGaucheEEG3 = new JButton("1/4 G");
		QuartdeTourGaucheEEG3.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEG3);
		QuartdeTourGaucheEEG3.setVisible(false);

		JButton PositioninitialeEEG3 = new JButton("-");
		PositioninitialeEEG3.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEG3);
		PositioninitialeEEG3.setVisible(false);

		GoodleyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JeremyBertEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEG33.setVisible(true);
				DemiTourDroiteEEG3.setVisible(true);
				QuartdeTourGaucheEEG3.setVisible(true);
				PositioninitialeEEG3.setVisible(true);

			}
		});

		QuartdeTourDroiteEEG33.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG33.setVisible(false);
				DemiTourDroiteEEG3.setVisible(false);
				QuartdeTourGaucheEEG3.setVisible(false);
				PositioninitialeEEG3.setVisible(false);

				image1DD.setVisible(false);
				image8.setVisible(false);
				image1.setBounds(600, 650, 200, 200);
				image8QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image8DD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);

			}
		});

		DemiTourDroiteEEG3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG33.setVisible(false);
				DemiTourDroiteEEG3.setVisible(false);
				QuartdeTourGaucheEEG3.setVisible(false);
				PositioninitialeEEG3.setVisible(false);

				image1DD.setVisible(false);
				image8.setVisible(false);
				image1.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);
				image1QD.setVisible(false);
				image8DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEG3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG33.setVisible(false);
				DemiTourDroiteEEG3.setVisible(false);
				QuartdeTourGaucheEEG3.setVisible(false);
				PositioninitialeEEG3.setVisible(false);

				image1DD.setVisible(false);
				image8.setVisible(false);
				image1.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image8DD.setVisible(false);

			}
		});

		PositioninitialeEEG3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG33.setVisible(false);
				DemiTourDroiteEEG3.setVisible(false);
				QuartdeTourGaucheEEG3.setVisible(false);
				PositioninitialeEEG3.setVisible(false);

				image1DD.setVisible(false);
				image8.setBounds(375, 200, 200, 200);
				image1.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);
				image1QD.setVisible(false);
				image8DD.setVisible(false);

			}
		});
 
		JeremyBertE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeE.setVisible(false);
				JeremyBertE.setVisible(false);
				PizerE.setVisible(false);
				SmithE.setVisible(false);
				LaneE.setVisible(false);
				MadameE.setVisible(false);
				StealthyE.setVisible(false);
				GullE.setVisible(false);
				GoodleyE.setVisible(false);

				QuartdeTourDroiteE.setVisible(true);
				DemiTourDroiteE.setVisible(true);
				QuartdeTourGaucheE.setVisible(true);
				PositioninitialeE.setVisible(true);
				JeremyBertEE.setVisible(false);

				/*
				 * QuartdeTourDroiteE.setVisible(false); DemiTourDroiteE.setVisible(false);
				 * QuartdeTourGaucheE.setVisible(false); PositioninitialeE.setVisible(false);
				 */
			}

		});

		QuartdeTourDroiteE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteE.setVisible(false);
				DemiTourDroiteE.setVisible(false);
				QuartdeTourGaucheE.setVisible(false);
				PositioninitialeE.setVisible(false);

				LestradeEE.setVisible(true);
				PizerEE.setVisible(true);
				SmithEE.setVisible(true);
				LaneEE.setVisible(true);
				MadameEE.setVisible(true);
				StealthyEE.setVisible(true);
				GullEE.setVisible(true);
				GoodleyEE.setVisible(true);

			}

		});

		JButton QuartdeTourDroiteEE11 = new JButton("1/4 D");
		QuartdeTourDroiteEE11.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEE11);
		QuartdeTourDroiteEE11.setVisible(false);

		JButton DemiTourDroiteEE11 = new JButton("1/2 Tour");
		DemiTourDroiteEE11.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEE11);
		DemiTourDroiteEE11.setVisible(false);

		JButton QuartdeTourGaucheEE11 = new JButton("1/4 G");
		QuartdeTourGaucheEE11.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEE11);
		QuartdeTourGaucheEE11.setVisible(false);

		JButton PositioninitialeEE11 = new JButton("-");
		PositioninitialeEE11.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEE11);
		PositioninitialeEE11.setVisible(false);

		LestradeEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEE11.setVisible(true);
				DemiTourDroiteEE11.setVisible(true);
				QuartdeTourGaucheEE11.setVisible(true);
				PositioninitialeEE11.setVisible(true);

				/*
				 * image1.setVisible(false); image2.setVisible(false); image1QD.setBounds(600,
				 * 200, 200,200); image2QD.setBounds(375, 200, 200,200);
				 * image1QG.setVisible(false); image2QG.setVisible(false);
				 */

			}
		});

		QuartdeTourDroiteEE11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE11.setVisible(false);
				DemiTourDroiteEE11.setVisible(false);
				QuartdeTourGaucheEE11.setVisible(false);
				PositioninitialeEE11.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1QD.setBounds(600, 200, 200, 200);
				image2QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image2DD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);

			}
		});

		DemiTourDroiteEE11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE11.setVisible(false);
				DemiTourDroiteEE11.setVisible(false);
				QuartdeTourGaucheEE11.setVisible(false);
				PositioninitialeEE11.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1QD.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);
				image1DD.setVisible(false);
				image2DD.setBounds(375, 200, 200, 200);
			}
		});

		QuartdeTourGaucheEE11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE11.setVisible(false);
				DemiTourDroiteEE11.setVisible(false);
				QuartdeTourGaucheEE11.setVisible(false);
				PositioninitialeEE11.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1QD.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		PositioninitialeEE11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE11.setVisible(false);
				DemiTourDroiteEE11.setVisible(false);
				QuartdeTourGaucheEE11.setVisible(false);
				PositioninitialeEE11.setVisible(false);

				image1.setVisible(false);
				image2.setBounds(375, 200, 200, 200);
				image1QD.setBounds(600, 200, 200, 200);
				image1QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);
				image1DD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEP11 = new JButton("1/4 D");
		QuartdeTourDroiteEEP11.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEP11);
		QuartdeTourDroiteEEP11.setVisible(false);

		JButton DemiTourDroiteEEP11 = new JButton("1/2 Tour");
		DemiTourDroiteEEP11.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEP11);
		DemiTourDroiteEEP11.setVisible(false);

		JButton QuartdeTourGaucheEEP11 = new JButton("1/4 G");
		QuartdeTourGaucheEEP11.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEP11);
		QuartdeTourGaucheEEP11.setVisible(false);

		JButton PositioninitialeEEP11 = new JButton("-");
		PositioninitialeEEP11.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEP11);
		PositioninitialeEEP11.setVisible(false);

		PizerEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEEP11.setVisible(true);
				DemiTourDroiteEEP11.setVisible(true);
				QuartdeTourGaucheEEP11.setVisible(true);
				PositioninitialeEEP11.setVisible(true);

			}
		});

		QuartdeTourDroiteEEP11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP11.setVisible(false);
				DemiTourDroiteEEP11.setVisible(false);
				QuartdeTourGaucheEEP11.setVisible(false);
				PositioninitialeEEP11.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1QD.setBounds(825, 200, 200, 200);
				image3QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image3DD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setVisible(false);

			}
		});

		DemiTourDroiteEEP11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP11.setVisible(false);
				DemiTourDroiteEEP11.setVisible(false);
				QuartdeTourGaucheEEP11.setVisible(false);
				PositioninitialeEEP11.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1QD.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setVisible(false);
				image1DD.setVisible(false);
				image3DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEP11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP11.setVisible(false);
				DemiTourDroiteEEP11.setVisible(false);
				QuartdeTourGaucheEEP11.setVisible(false);
				PositioninitialeEEP11.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1QD.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image3DD.setVisible(false);

			}
		});
		PositioninitialeEEP11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP11.setVisible(false);
				DemiTourDroiteEEP11.setVisible(false);
				QuartdeTourGaucheEEP11.setVisible(false);
				PositioninitialeEEP11.setVisible(false);

				image1.setVisible(false);
				image3.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image3QG.setVisible(false);
				image1QD.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1DD.setVisible(false);
				image3DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEES11 = new JButton("1/4 D");
		QuartdeTourDroiteEES11.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEES11);
		QuartdeTourDroiteEES11.setVisible(false);

		JButton DemiTourDroiteEES11 = new JButton("1/2 Tour");
		DemiTourDroiteEES11.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEES11);
		DemiTourDroiteEES11.setVisible(false);

		JButton QuartdeTourGaucheEES11 = new JButton("1/4 G");
		QuartdeTourGaucheEES11.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEES11);
		QuartdeTourGaucheEES11.setVisible(false);

		JButton PositioninitialeEES11 = new JButton("-");
		PositioninitialeEES11.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEES11);
		PositioninitialeEES11.setVisible(false);

		SmithEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEES11.setVisible(true);
				DemiTourDroiteEES11.setVisible(true);
				QuartdeTourGaucheEES11.setVisible(true);
				PositioninitialeEES11.setVisible(true);

			}
		});

		QuartdeTourDroiteEES11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES11.setVisible(false);
				DemiTourDroiteEES11.setVisible(false);
				QuartdeTourGaucheEES11.setVisible(false);
				PositioninitialeEES11.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1QD.setBounds(375, 425, 200, 200);
				image4QD.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1DD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		DemiTourDroiteEES11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES11.setVisible(false);
				DemiTourDroiteEES11.setVisible(false);
				QuartdeTourGaucheEES11.setVisible(false);
				PositioninitialeEES11.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1QD.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1DD.setVisible(false);
				image4DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEES11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES11.setVisible(false);
				DemiTourDroiteEES11.setVisible(false);
				QuartdeTourGaucheEES11.setVisible(false);
				PositioninitialeEES11.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1QD.setBounds(375, 425, 200, 200);
				image1QD.setVisible(false);
				image1QG.setVisible(false);
				image4QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image4DD.setVisible(false);

			}
		});
		PositioninitialeEES11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES11.setVisible(false);
				DemiTourDroiteEES11.setVisible(false);
				QuartdeTourGaucheEES11.setVisible(false);
				PositioninitialeEES11.setVisible(false);

				image1.setVisible(false);
				image4.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1QD.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1DD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEL11 = new JButton("1/4 D");
		QuartdeTourDroiteEEL11.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEL11);
		QuartdeTourDroiteEEL11.setVisible(false);

		JButton DemiTourDroiteEEL11 = new JButton("1/2 Tour");
		DemiTourDroiteEEL11.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEL11);
		DemiTourDroiteEEL11.setVisible(false);

		JButton QuartdeTourGaucheEEL11 = new JButton("1/4 G");
		QuartdeTourGaucheEEL11.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEL11);
		QuartdeTourGaucheEEL11.setVisible(false);

		JButton PositioninitialeEEL11 = new JButton("-");
		PositioninitialeEEL11.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEL11);
		PositioninitialeEEL11.setVisible(false);

		LaneEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEL11.setVisible(true);
				DemiTourDroiteEEL11.setVisible(true);
				QuartdeTourGaucheEEL11.setVisible(true);
				PositioninitialeEEL11.setVisible(true);

			}
		});

		QuartdeTourDroiteEEL11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL11.setVisible(false);
				DemiTourDroiteEEL11.setVisible(false);
				QuartdeTourGaucheEEL11.setVisible(false);
				PositioninitialeEEL11.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1QD.setBounds(600, 425, 200, 200);
				image5QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image5DD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);

			}
		});

		DemiTourDroiteEEL11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL11.setVisible(false);
				DemiTourDroiteEEL11.setVisible(false);
				QuartdeTourGaucheEEL11.setVisible(false);
				PositioninitialeEEL11.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1QD.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);
				image1DD.setVisible(false);
				image5DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEL11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL11.setVisible(false);
				DemiTourDroiteEEL11.setVisible(false);
				QuartdeTourGaucheEEL11.setVisible(false);
				PositioninitialeEEL11.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1QD.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image5DD.setVisible(false);

			}
		});
		PositioninitialeEEL11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL11.setVisible(false);
				DemiTourDroiteEEL11.setVisible(false);
				QuartdeTourGaucheEEL11.setVisible(false);
				PositioninitialeEEL11.setVisible(false);

				image1.setVisible(false);
				image5.setBounds(375, 200, 200, 200);

				image1QD.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);
				image1DD.setVisible(false);
				image5DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEM11 = new JButton("1/4 D");
		QuartdeTourDroiteEEM11.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEM11);
		QuartdeTourDroiteEEM11.setVisible(false);

		JButton DemiTourDroiteEEM11 = new JButton("1/2 Tour");
		DemiTourDroiteEEM11.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEM11);
		DemiTourDroiteEEM11.setVisible(false);

		JButton QuartdeTourGaucheEEM11 = new JButton("1/4 G");
		QuartdeTourGaucheEEM11.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEM11);
		QuartdeTourGaucheEEM11.setVisible(false);

		JButton PositioninitialeEEM11 = new JButton("-");
		PositioninitialeEEM11.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEM11);
		PositioninitialeEEM11.setVisible(false);

		MadameEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEM11.setVisible(true);
				DemiTourDroiteEEM11.setVisible(true);
				QuartdeTourGaucheEEM11.setVisible(true);
				PositioninitialeEEM11.setVisible(true);

			}
		});

		QuartdeTourDroiteEEM11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM11.setVisible(false);
				DemiTourDroiteEEM11.setVisible(false);
				QuartdeTourGaucheEEM11.setVisible(false);
				PositioninitialeEEM11.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1QD.setBounds(825, 425, 200, 200);
				image6QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image6DD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);

			}
		});

		DemiTourDroiteEEM11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM11.setVisible(false);
				DemiTourDroiteEEM11.setVisible(false);
				QuartdeTourGaucheEEM11.setVisible(false);
				PositioninitialeEEM11.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1QD.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);
				image1DD.setVisible(false);
				image6DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEM11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM11.setVisible(false);
				DemiTourDroiteEEM11.setVisible(false);
				QuartdeTourGaucheEEM11.setVisible(false);
				PositioninitialeEEM11.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1QD.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image6DD.setVisible(false);

			}
		});
		PositioninitialeEEM11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM11.setVisible(false);
				DemiTourDroiteEEM11.setVisible(false);
				QuartdeTourGaucheEEM11.setVisible(false);
				PositioninitialeEEM11.setVisible(false);

				image1.setVisible(false);
				image6.setBounds(375, 200, 200, 200);
				image1QD.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);
				image1DD.setVisible(false);
				image6DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEMS11 = new JButton("1/4 D");
		QuartdeTourDroiteEEMS11.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEMS11);
		QuartdeTourDroiteEEMS11.setVisible(false);

		JButton DemiTourDroiteEEMS11 = new JButton("1/2 Tour");
		DemiTourDroiteEEMS11.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEMS11);
		DemiTourDroiteEEMS11.setVisible(false);

		JButton QuartdeTourGaucheEEMS11 = new JButton("1/4 G");
		QuartdeTourGaucheEEMS11.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEMS11);
		QuartdeTourGaucheEEMS11.setVisible(false);

		JButton PositioninitialeEEMS11 = new JButton("-");
		PositioninitialeEEMS11.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEMS11);
		PositioninitialeEEMS11.setVisible(false);

		StealthyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEMS11.setVisible(true);
				DemiTourDroiteEEMS11.setVisible(true);
				QuartdeTourGaucheEEMS11.setVisible(true);
				PositioninitialeEEMS11.setVisible(true);

			}
		});

		QuartdeTourDroiteEEMS11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS11.setVisible(false);
				DemiTourDroiteEEMS11.setVisible(false);
				QuartdeTourGaucheEEMS11.setVisible(false);
				PositioninitialeEEMS11.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1QD.setBounds(375, 650, 200, 200);
				image7QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image7DD.setVisible(false);
				image1QG.setVisible(false);
				image7QG.setVisible(false);

			}
		});

		DemiTourDroiteEEMS11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS11.setVisible(false);
				DemiTourDroiteEEMS11.setVisible(false);
				QuartdeTourGaucheEEMS11.setVisible(false);
				PositioninitialeEEMS11.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1QD.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1DD.setVisible(false);
				image7DD.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image7QG.setVisible(false);

			}
		});
		QuartdeTourGaucheEEMS11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS11.setVisible(false);
				DemiTourDroiteEEMS11.setVisible(false);
				QuartdeTourGaucheEEMS11.setVisible(false);
				PositioninitialeEEMS11.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1QD.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1QG.setVisible(false);
				image7QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image7DD.setVisible(false);

			}
		});
		PositioninitialeEEMS11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS11.setVisible(false);
				DemiTourDroiteEEMS11.setVisible(false);
				QuartdeTourGaucheEEMS11.setVisible(false);
				PositioninitialeEEMS11.setVisible(false);

				image1.setVisible(false);
				image7.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image7QG.setVisible(false);
				image1QD.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1DD.setVisible(false);
				image7DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEGU11 = new JButton("1/4 D");
		QuartdeTourDroiteEEGU11.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEGU11);
		QuartdeTourDroiteEEGU11.setVisible(false);

		JButton DemiTourDroiteEEGU11 = new JButton("1/2 Tour");
		DemiTourDroiteEEGU11.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEGU11);
		DemiTourDroiteEEGU11.setVisible(false);

		JButton QuartdeTourGaucheEEGU11 = new JButton("1/4 G");
		QuartdeTourGaucheEEGU11.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEGU11);
		QuartdeTourGaucheEEGU11.setVisible(false);

		JButton PositioninitialeEEGU11 = new JButton("-");
		PositioninitialeEEGU11.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEGU11);
		PositioninitialeEEGU11.setVisible(false);

		GullEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEGU11.setVisible(true);
				DemiTourDroiteEEGU11.setVisible(true);
				QuartdeTourGaucheEEGU11.setVisible(true);
				PositioninitialeEEGU11.setVisible(true);

			}
		});

		QuartdeTourDroiteEEGU11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU11.setVisible(false);
				DemiTourDroiteEEGU11.setVisible(false);
				QuartdeTourGaucheEEGU11.setVisible(false);
				PositioninitialeEEGU11.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1QD.setBounds(825, 650, 200, 200);
				image9QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image9DD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);

			}
		});

		DemiTourDroiteEEGU11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU11.setVisible(false);
				DemiTourDroiteEEGU11.setVisible(false);
				QuartdeTourGaucheEEGU11.setVisible(false);
				PositioninitialeEEGU11.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1QD.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);
				image1DD.setVisible(false);
				image9DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEGU11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU11.setVisible(false);
				DemiTourDroiteEEGU11.setVisible(false);
				QuartdeTourGaucheEEGU11.setVisible(false);
				PositioninitialeEEGU11.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1QD.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		PositioninitialeEEGU11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU11.setVisible(false);
				DemiTourDroiteEEGU11.setVisible(false);
				QuartdeTourGaucheEEGU11.setVisible(false);
				PositioninitialeEEGU11.setVisible(false);

				image1.setVisible(false);
				image9.setBounds(375, 200, 200, 200);
				image1QD.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);
				image1DD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEG11 = new JButton("1/4 D");
		QuartdeTourDroiteEEG11.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEG11);
		QuartdeTourDroiteEEG11.setVisible(false);

		JButton DemiTourDroiteEEG11 = new JButton("1/2 Tour");
		DemiTourDroiteEEG11.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEG11);
		DemiTourDroiteEEG11.setVisible(false);

		JButton QuartdeTourGaucheEEG11 = new JButton("1/4 G");
		QuartdeTourGaucheEEG11.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEG11);
		QuartdeTourGaucheEEG11.setVisible(false);

		JButton PositioninitialeEEG11 = new JButton("-");
		PositioninitialeEEG11.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEG11);
		PositioninitialeEEG11.setVisible(false);

		GoodleyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEG11.setVisible(true);
				DemiTourDroiteEEG11.setVisible(true);
				QuartdeTourGaucheEEG11.setVisible(true);
				PositioninitialeEEG11.setVisible(true);

			}
		});

		QuartdeTourDroiteEEG11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG11.setVisible(false);
				DemiTourDroiteEEG11.setVisible(false);
				QuartdeTourGaucheEEG11.setVisible(false);
				PositioninitialeEEG11.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1QD.setBounds(600, 650, 200, 200);
				image8QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image8DD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);

			}
		});

		DemiTourDroiteEEG11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG11.setVisible(false);
				DemiTourDroiteEEG11.setVisible(false);
				QuartdeTourGaucheEEG11.setVisible(false);
				PositioninitialeEEG11.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1QD.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);
				image1DD.setVisible(false);
				image8DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEG11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG11.setVisible(false);
				DemiTourDroiteEEG11.setVisible(false);
				QuartdeTourGaucheEEG11.setVisible(false);
				PositioninitialeEEG11.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1QD.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image8DD.setVisible(false);

			}
		});

		PositioninitialeEEG11.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG11.setVisible(false);
				DemiTourDroiteEEG11.setVisible(false);
				QuartdeTourGaucheEEG11.setVisible(false);
				PositioninitialeEEG11.setVisible(false);

				image1.setVisible(false);
				image8.setBounds(375, 200, 200, 200);
				image1QD.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);
				image1DD.setVisible(false);
				image8DD.setVisible(false);

			}
		});

		DemiTourDroiteE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteE.setVisible(false);
				DemiTourDroiteE.setVisible(false);
				QuartdeTourGaucheE.setVisible(false);
				PositioninitialeE.setVisible(false);

				LestradeEE.setVisible(true);
				PizerEE.setVisible(true);
				SmithEE.setVisible(true);
				LaneEE.setVisible(true);
				MadameEE.setVisible(true);
				StealthyEE.setVisible(true);
				GullEE.setVisible(true);
				GoodleyEE.setVisible(true);

			}

		});

		JButton QuartdeTourDroiteEE111 = new JButton("1/4 D");
		QuartdeTourDroiteEE111.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEE111);
		QuartdeTourDroiteEE111.setVisible(false);

		JButton DemiTourDroiteEE111 = new JButton("1/2 Tour");
		DemiTourDroiteEE111.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEE111);
		DemiTourDroiteEE111.setVisible(false);

		JButton QuartdeTourGaucheEE111 = new JButton("1/4 G");
		QuartdeTourGaucheEE111.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEE111);
		QuartdeTourGaucheEE111.setVisible(false);

		JButton PositioninitialeEE111 = new JButton("-");
		PositioninitialeEE111.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEE111);
		PositioninitialeEE111.setVisible(false);

		LestradeEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEE111.setVisible(true);
				DemiTourDroiteEE111.setVisible(true);
				QuartdeTourGaucheEE111.setVisible(true);
				PositioninitialeEE111.setVisible(true);

				/*
				 * image1.setVisible(false); image2.setVisible(false); image1QD.setBounds(600,
				 * 200, 200,200); image2QD.setBounds(375, 200, 200,200);
				 * image1QG.setVisible(false); image2QG.setVisible(false);
				 */

			}
		});

		QuartdeTourDroiteEE111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE111.setVisible(false);
				DemiTourDroiteEE111.setVisible(false);
				QuartdeTourGaucheEE111.setVisible(false);
				PositioninitialeEE111.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1DD.setBounds(600, 200, 200, 200);
				image2QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image2DD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);

			}
		});

		DemiTourDroiteEE111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE111.setVisible(false);
				DemiTourDroiteEE111.setVisible(false);
				QuartdeTourGaucheEE111.setVisible(false);
				PositioninitialeEE111.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1DD.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);
				image1QD.setVisible(false);
				image2DD.setBounds(375, 200, 200, 200);
			}
		});

		QuartdeTourGaucheEE111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE111.setVisible(false);
				DemiTourDroiteEE111.setVisible(false);
				QuartdeTourGaucheEE111.setVisible(false);
				PositioninitialeEE111.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1DD.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		PositioninitialeEE111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE111.setVisible(false);
				DemiTourDroiteEE111.setVisible(false);
				QuartdeTourGaucheEE111.setVisible(false);
				PositioninitialeEE111.setVisible(false);

				image1.setVisible(false);
				image2.setBounds(375, 200, 200, 200);
				image1DD.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);
				image1QD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEP111 = new JButton("1/4 D");
		QuartdeTourDroiteEEP111.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEP111);
		QuartdeTourDroiteEEP111.setVisible(false);

		JButton DemiTourDroiteEEP111 = new JButton("1/2 Tour");
		DemiTourDroiteEEP111.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEP111);
		DemiTourDroiteEEP111.setVisible(false);

		JButton QuartdeTourGaucheEEP111 = new JButton("1/4 G");
		QuartdeTourGaucheEEP111.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEP111);
		QuartdeTourGaucheEEP111.setVisible(false);

		JButton PositioninitialeEEP111 = new JButton("-");
		PositioninitialeEEP111.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEP111);
		PositioninitialeEEP111.setVisible(false);

		PizerEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEEP111.setVisible(true);
				DemiTourDroiteEEP111.setVisible(true);
				QuartdeTourGaucheEEP111.setVisible(true);
				PositioninitialeEEP111.setVisible(true);

			}
		});

		QuartdeTourDroiteEEP111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP111.setVisible(false);
				DemiTourDroiteEEP111.setVisible(false);
				QuartdeTourGaucheEEP111.setVisible(false);
				PositioninitialeEEP111.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1DD.setBounds(825, 200, 200, 200);
				image3QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image3QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setVisible(false);

			}
		});

		DemiTourDroiteEEP111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP111.setVisible(false);
				DemiTourDroiteEEP111.setVisible(false);
				QuartdeTourGaucheEEP111.setVisible(false);
				PositioninitialeEEP111.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1DD.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setVisible(false);
				image1QD.setVisible(false);
				image3DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEP111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP111.setVisible(false);
				DemiTourDroiteEEP111.setVisible(false);
				QuartdeTourGaucheEEP111.setVisible(false);
				PositioninitialeEEP111.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1DD.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image3DD.setVisible(false);

			}
		});
		PositioninitialeEEP111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP111.setVisible(false);
				DemiTourDroiteEEP111.setVisible(false);
				QuartdeTourGaucheEEP111.setVisible(false);
				PositioninitialeEEP111.setVisible(false);

				image1.setVisible(false);
				image3.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image3QG.setVisible(false);
				image1DD.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QD.setVisible(false);
				image3DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEES111 = new JButton("1/4 D");
		QuartdeTourDroiteEES111.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEES111);
		QuartdeTourDroiteEES111.setVisible(false);

		JButton DemiTourDroiteEES111 = new JButton("1/2 Tour");
		DemiTourDroiteEES111.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEES111);
		DemiTourDroiteEES111.setVisible(false);

		JButton QuartdeTourGaucheEES111 = new JButton("1/4 G");
		QuartdeTourGaucheEES111.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEES111);
		QuartdeTourGaucheEES111.setVisible(false);

		JButton PositioninitialeEES111 = new JButton("-");
		PositioninitialeEES111.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEES111);
		PositioninitialeEES111.setVisible(false);

		SmithEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEES111.setVisible(true);
				DemiTourDroiteEES111.setVisible(true);
				QuartdeTourGaucheEES111.setVisible(true);
				PositioninitialeEES111.setVisible(true);

			}
		});

		QuartdeTourDroiteEES111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES111.setVisible(false);
				DemiTourDroiteEES111.setVisible(false);
				QuartdeTourGaucheEES111.setVisible(false);
				PositioninitialeEES111.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1DD.setBounds(375, 425, 200, 200);
				image4QD.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		DemiTourDroiteEES111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES111.setVisible(false);
				DemiTourDroiteEES111.setVisible(false);
				QuartdeTourGaucheEES111.setVisible(false);
				PositioninitialeEES111.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1DD.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEES111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES111.setVisible(false);
				DemiTourDroiteEES111.setVisible(false);
				QuartdeTourGaucheEES111.setVisible(false);
				PositioninitialeEES111.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1DD.setBounds(375, 425, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image4QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});
		PositioninitialeEES111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES111.setVisible(false);
				DemiTourDroiteEES111.setVisible(false);
				QuartdeTourGaucheEES111.setVisible(false);
				PositioninitialeEES111.setVisible(false);

				image1.setVisible(false);
				image4.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1DD.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEL111 = new JButton("1/4 D");
		QuartdeTourDroiteEEL111.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEL111);
		QuartdeTourDroiteEEL111.setVisible(false);

		JButton DemiTourDroiteEEL111 = new JButton("1/2 Tour");
		DemiTourDroiteEEL111.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEL111);
		DemiTourDroiteEEL111.setVisible(false);

		JButton QuartdeTourGaucheEEL111 = new JButton("1/4 G");
		QuartdeTourGaucheEEL111.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEL111);
		QuartdeTourGaucheEEL111.setVisible(false);

		JButton PositioninitialeEEL111 = new JButton("-");
		PositioninitialeEEL111.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEL111);
		PositioninitialeEEL111.setVisible(false);

		LaneEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEL111.setVisible(true);
				DemiTourDroiteEEL111.setVisible(true);
				QuartdeTourGaucheEEL111.setVisible(true);
				PositioninitialeEEL111.setVisible(true);

			}
		});

		QuartdeTourDroiteEEL111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL111.setVisible(false);
				DemiTourDroiteEEL111.setVisible(false);
				QuartdeTourGaucheEEL111.setVisible(false);
				PositioninitialeEEL111.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1DD.setBounds(600, 425, 200, 200);
				image5QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image5DD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);

			}
		});

		DemiTourDroiteEEL111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL111.setVisible(false);
				DemiTourDroiteEEL111.setVisible(false);
				QuartdeTourGaucheEEL111.setVisible(false);
				PositioninitialeEEL111.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1DD.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);
				image1QD.setVisible(false);
				image5DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEL111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL111.setVisible(false);
				DemiTourDroiteEEL111.setVisible(false);
				QuartdeTourGaucheEEL111.setVisible(false);
				PositioninitialeEEL111.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1DD.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image5DD.setVisible(false);

			}
		});
		PositioninitialeEEL111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL111.setVisible(false);
				DemiTourDroiteEEL111.setVisible(false);
				QuartdeTourGaucheEEL111.setVisible(false);
				PositioninitialeEEL111.setVisible(false);

				image1.setVisible(false);
				image5.setBounds(375, 200, 200, 200);

				image1DD.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);
				image1QD.setVisible(false);
				image5DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEM111 = new JButton("1/4 D");
		QuartdeTourDroiteEEM111.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEM111);
		QuartdeTourDroiteEEM111.setVisible(false);

		JButton DemiTourDroiteEEM111 = new JButton("1/2 Tour");
		DemiTourDroiteEEM111.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEM111);
		DemiTourDroiteEEM111.setVisible(false);

		JButton QuartdeTourGaucheEEM111 = new JButton("1/4 G");
		QuartdeTourGaucheEEM111.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEM111);
		QuartdeTourGaucheEEM111.setVisible(false);

		JButton PositioninitialeEEM111 = new JButton("-");
		PositioninitialeEEM111.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEM111);
		PositioninitialeEEM111.setVisible(false);

		MadameEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEM111.setVisible(true);
				DemiTourDroiteEEM111.setVisible(true);
				QuartdeTourGaucheEEM111.setVisible(true);
				PositioninitialeEEM111.setVisible(true);

			}
		});

		QuartdeTourDroiteEEM111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM111.setVisible(false);
				DemiTourDroiteEEM111.setVisible(false);
				QuartdeTourGaucheEEM111.setVisible(false);
				PositioninitialeEEM111.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1DD.setBounds(825, 425, 200, 200);
				image6QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image6DD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);

			}
		});

		DemiTourDroiteEEM111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM111.setVisible(false);
				DemiTourDroiteEEM111.setVisible(false);
				QuartdeTourGaucheEEM111.setVisible(false);
				PositioninitialeEEM111.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1DD.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);
				image1QD.setVisible(false);
				image6DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEM111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM111.setVisible(false);
				DemiTourDroiteEEM111.setVisible(false);
				QuartdeTourGaucheEEM111.setVisible(false);
				PositioninitialeEEM111.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1DD.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image6DD.setVisible(false);

			}
		});
		PositioninitialeEEM111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM111.setVisible(false);
				DemiTourDroiteEEM111.setVisible(false);
				QuartdeTourGaucheEEM111.setVisible(false);
				PositioninitialeEEM111.setVisible(false);

				image1.setVisible(false);
				image6.setBounds(375, 200, 200, 200);
				image1DD.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);
				image1QD.setVisible(false);
				image6DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEMS111 = new JButton("1/4 D");
		QuartdeTourDroiteEEMS111.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEMS111);
		QuartdeTourDroiteEEMS111.setVisible(false);

		JButton DemiTourDroiteEEMS111 = new JButton("1/2 Tour");
		DemiTourDroiteEEMS111.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEMS111);
		DemiTourDroiteEEMS111.setVisible(false);

		JButton QuartdeTourGaucheEEMS111 = new JButton("1/4 G");
		QuartdeTourGaucheEEMS111.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEMS111);
		QuartdeTourGaucheEEMS111.setVisible(false);

		JButton PositioninitialeEEMS111 = new JButton("-");
		PositioninitialeEEMS111.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEMS111);
		PositioninitialeEEMS111.setVisible(false);

		StealthyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEMS111.setVisible(true);
				DemiTourDroiteEEMS111.setVisible(true);
				QuartdeTourGaucheEEMS111.setVisible(true);
				PositioninitialeEEMS111.setVisible(true);

			}
		});

		QuartdeTourDroiteEEMS111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS111.setVisible(false);
				DemiTourDroiteEEMS111.setVisible(false);
				QuartdeTourGaucheEEMS111.setVisible(false);
				PositioninitialeEEMS111.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1DD.setBounds(375, 650, 200, 200);
				image7QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image7QD.setVisible(false);
				image1QG.setVisible(false);
				image7QG.setVisible(false);

			}
		});

		DemiTourDroiteEEMS111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS111.setVisible(false);
				DemiTourDroiteEEMS111.setVisible(false);
				QuartdeTourGaucheEEMS111.setVisible(false);
				PositioninitialeEEMS111.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1DD.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1QD.setVisible(false);
				image7QD.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image7QG.setVisible(false);

			}
		});
		QuartdeTourGaucheEEMS111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS111.setVisible(false);
				DemiTourDroiteEEMS111.setVisible(false);
				QuartdeTourGaucheEEMS111.setVisible(false);
				PositioninitialeEEMS111.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1DD.setBounds(375, 650, 200, 200);
				image7DD.setVisible(false);
				image1QG.setVisible(false);
				image7QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image7DD.setVisible(false);

			}
		});
		PositioninitialeEEMS111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS111.setVisible(false);
				DemiTourDroiteEEMS111.setVisible(false);
				QuartdeTourGaucheEEMS111.setVisible(false);
				PositioninitialeEEMS111.setVisible(false);

				image1.setVisible(false);
				image7.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image7QG.setVisible(false);
				image1DD.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1QD.setVisible(false);
				image7DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEGU111 = new JButton("1/4 D");
		QuartdeTourDroiteEEGU111.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEGU111);
		QuartdeTourDroiteEEGU111.setVisible(false);

		JButton DemiTourDroiteEEGU111 = new JButton("1/2 Tour");
		DemiTourDroiteEEGU111.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEGU111);
		DemiTourDroiteEEGU111.setVisible(false);

		JButton QuartdeTourGaucheEEGU111 = new JButton("1/4 G");
		QuartdeTourGaucheEEGU111.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEGU111);
		QuartdeTourGaucheEEGU111.setVisible(false);

		JButton PositioninitialeEEGU111 = new JButton("-");
		PositioninitialeEEGU111.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEGU111);
		PositioninitialeEEGU111.setVisible(false);

		GullEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEGU111.setVisible(true);
				DemiTourDroiteEEGU111.setVisible(true);
				QuartdeTourGaucheEEGU111.setVisible(true);
				PositioninitialeEEGU111.setVisible(true);

			}
		});

		QuartdeTourDroiteEEGU111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU111.setVisible(false);
				DemiTourDroiteEEGU111.setVisible(false);
				QuartdeTourGaucheEEGU111.setVisible(false);
				PositioninitialeEEGU111.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1DD.setBounds(825, 650, 200, 200);
				image9QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image9DD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);

			}
		});

		DemiTourDroiteEEGU111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU111.setVisible(false);
				DemiTourDroiteEEGU111.setVisible(false);
				QuartdeTourGaucheEEGU111.setVisible(false);
				PositioninitialeEEGU111.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1DD.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);
				image1QD.setVisible(false);
				image9DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEGU111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU111.setVisible(false);
				DemiTourDroiteEEGU111.setVisible(false);
				QuartdeTourGaucheEEGU111.setVisible(false);
				PositioninitialeEEGU111.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1DD.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		PositioninitialeEEGU111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU111.setVisible(false);
				DemiTourDroiteEEGU111.setVisible(false);
				QuartdeTourGaucheEEGU111.setVisible(false);
				PositioninitialeEEGU111.setVisible(false);

				image1.setVisible(false);
				image9.setBounds(375, 200, 200, 200);
				image1DD.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);
				image1QD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEG111 = new JButton("1/4 D");
		QuartdeTourDroiteEEG111.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEG111);
		QuartdeTourDroiteEEG111.setVisible(false);

		JButton DemiTourDroiteEEG111 = new JButton("1/2 Tour");
		DemiTourDroiteEEG111.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEG111);
		DemiTourDroiteEEG111.setVisible(false);

		JButton QuartdeTourGaucheEEG111 = new JButton("1/4 G");
		QuartdeTourGaucheEEG111.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEG111);
		QuartdeTourGaucheEEG111.setVisible(false);

		JButton PositioninitialeEEG111 = new JButton("-");
		PositioninitialeEEG111.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEG111);
		PositioninitialeEEG111.setVisible(false);

		GoodleyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEG111.setVisible(true);
				DemiTourDroiteEEG111.setVisible(true);
				QuartdeTourGaucheEEG111.setVisible(true);
				PositioninitialeEEG111.setVisible(true);

			}
		});

		QuartdeTourDroiteEEG111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG111.setVisible(false);
				DemiTourDroiteEEG111.setVisible(false);
				QuartdeTourGaucheEEG111.setVisible(false);
				PositioninitialeEEG111.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1DD.setBounds(600, 650, 200, 200);
				image8QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image8DD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);

			}
		});

		DemiTourDroiteEEG111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG111.setVisible(false);
				DemiTourDroiteEEG111.setVisible(false);
				QuartdeTourGaucheEEG111.setVisible(false);
				PositioninitialeEEG111.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1DD.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);
				image1QD.setVisible(false);
				image8DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEG111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG111.setVisible(false);
				DemiTourDroiteEEG111.setVisible(false);
				QuartdeTourGaucheEEG111.setVisible(false);
				PositioninitialeEEG111.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1DD.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image8DD.setVisible(false);

			}
		});

		PositioninitialeEEG111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG111.setVisible(false);
				DemiTourDroiteEEG111.setVisible(false);
				QuartdeTourGaucheEEG111.setVisible(false);
				PositioninitialeEEG111.setVisible(false);

				image1.setVisible(false);
				image8.setBounds(375, 200, 200, 200);
				image1DD.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);
				image1QD.setVisible(false);
				image8DD.setVisible(false);

			}
		});

		QuartdeTourGaucheE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteE.setVisible(false);
				DemiTourDroiteE.setVisible(false);
				QuartdeTourGaucheE.setVisible(false);
				PositioninitialeE.setVisible(false);

				LestradeEE.setVisible(true);
				PizerEE.setVisible(true);
				SmithEE.setVisible(true);
				LaneEE.setVisible(true);
				MadameEE.setVisible(true);
				StealthyEE.setVisible(true);
				GullEE.setVisible(true);
				GoodleyEE.setVisible(true);

			}

		});

		JButton QuartdeTourDroiteEE21 = new JButton("1/4 D");
		QuartdeTourDroiteEE21.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEE21);
		QuartdeTourDroiteEE21.setVisible(false);

		JButton DemiTourDroiteEE21 = new JButton("1/2 Tour");
		DemiTourDroiteEE21.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEE21);
		DemiTourDroiteEE21.setVisible(false);

		JButton QuartdeTourGaucheEE21 = new JButton("1/4 G");
		QuartdeTourGaucheEE21.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEE21);
		QuartdeTourGaucheEE21.setVisible(false);

		JButton PositioninitialeEE21 = new JButton("-");
		PositioninitialeEE21.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEE21);
		PositioninitialeEE21.setVisible(false);

		LestradeEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEE21.setVisible(true);
				DemiTourDroiteEE21.setVisible(true);
				QuartdeTourGaucheEE21.setVisible(true);
				PositioninitialeEE21.setVisible(true);

				/*
				 * image1.setVisible(false); image2.setVisible(false); image1QD.setBounds(600,
				 * 200, 200,200); image2QD.setBounds(375, 200, 200,200);
				 * image1QG.setVisible(false); image2QG.setVisible(false);
				 */

			}
		});

		QuartdeTourDroiteEE21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE21.setVisible(false);
				DemiTourDroiteEE21.setVisible(false);
				QuartdeTourGaucheEE21.setVisible(false);
				PositioninitialeEE21.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1QG.setBounds(600, 200, 200, 200);
				image2QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image2DD.setVisible(false);
				image1DD.setVisible(false);
				image2QG.setVisible(false);

			}
		});

		DemiTourDroiteEE21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE21.setVisible(false);
				DemiTourDroiteEE21.setVisible(false);
				QuartdeTourGaucheEE21.setVisible(false);
				PositioninitialeEE21.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1QG.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1DD.setVisible(false);
				image2QG.setVisible(false);
				image1QD.setVisible(false);
				image2DD.setBounds(375, 200, 200, 200);
			}
		});

		QuartdeTourGaucheEE21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE21.setVisible(false);
				DemiTourDroiteEE21.setVisible(false);
				QuartdeTourGaucheEE21.setVisible(false);
				PositioninitialeEE21.setVisible(false);

				image1.setVisible(false);
				image2.setVisible(false);
				image1QG.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1DD.setVisible(false);
				image2QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		PositioninitialeEE21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE21.setVisible(false);
				DemiTourDroiteEE21.setVisible(false);
				QuartdeTourGaucheEE21.setVisible(false);
				PositioninitialeEE21.setVisible(false);

				image1.setVisible(false);
				image2.setBounds(375, 200, 200, 200);
				image1QG.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1DD.setVisible(false);
				image2QG.setVisible(false);
				image1QD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEP21 = new JButton("1/4 D");
		QuartdeTourDroiteEEP21.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEP21);
		QuartdeTourDroiteEEP21.setVisible(false);

		JButton DemiTourDroiteEEP21 = new JButton("1/2 Tour");
		DemiTourDroiteEEP21.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEP21);
		DemiTourDroiteEEP21.setVisible(false);

		JButton QuartdeTourGaucheEEP21 = new JButton("1/4 G");
		QuartdeTourGaucheEEP21.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEP21);
		QuartdeTourGaucheEEP21.setVisible(false);

		JButton PositioninitialeEEP21 = new JButton("-");
		PositioninitialeEEP21.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEP2);
		PositioninitialeEEP21.setVisible(false);

		PizerEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEEP21.setVisible(true);
				DemiTourDroiteEEP21.setVisible(true);
				QuartdeTourGaucheEEP2.setVisible(true);
				PositioninitialeEEP2.setVisible(true);

			}
		});

		QuartdeTourDroiteEEP21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP21.setVisible(false);
				DemiTourDroiteEEP21.setVisible(false);
				QuartdeTourGaucheEEP2.setVisible(false);
				PositioninitialeEEP2.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1QG.setBounds(825, 200, 200, 200);
				image3QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image3QD.setVisible(false);
				image1DD.setVisible(false);
				image3QG.setVisible(false);

			}
		});

		DemiTourDroiteEEP21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP21.setVisible(false);
				DemiTourDroiteEEP21.setVisible(false);
				QuartdeTourGaucheEEP2.setVisible(false);
				PositioninitialeEEP2.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1QG.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1DD.setVisible(false);
				image3QG.setVisible(false);
				image1QD.setVisible(false);
				image3DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEP2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP21.setVisible(false);
				DemiTourDroiteEEP21.setVisible(false);
				QuartdeTourGaucheEEP2.setVisible(false);
				PositioninitialeEEP2.setVisible(false);

				image1.setVisible(false);
				image3.setVisible(false);
				image1QG.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1DD.setVisible(false);
				image3QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image3DD.setVisible(false);

			}
		});
		PositioninitialeEEP2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP21.setVisible(false);
				DemiTourDroiteEEP21.setVisible(false);
				QuartdeTourGaucheEEP2.setVisible(false);
				PositioninitialeEEP2.setVisible(false);

				image1.setVisible(false);
				image3.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image3QG.setVisible(false);
				image1QG.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QD.setVisible(false);
				image3DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEES21 = new JButton("1/4 D");
		QuartdeTourDroiteEES21.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEES21);
		QuartdeTourDroiteEES21.setVisible(false);

		JButton DemiTourDroiteEES21 = new JButton("1/2 Tour");
		DemiTourDroiteEES21.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEES21);
		DemiTourDroiteEES21.setVisible(false);

		JButton QuartdeTourGaucheEES21 = new JButton("1/4 G");
		QuartdeTourGaucheEES21.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEES21);
		QuartdeTourGaucheEES21.setVisible(false);

		JButton PositioninitialeEES21 = new JButton("-");
		PositioninitialeEES21.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEES21);
		PositioninitialeEES21.setVisible(false);

		SmithEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEES21.setVisible(true);
				DemiTourDroiteEES21.setVisible(true);
				QuartdeTourGaucheEES21.setVisible(true);
				PositioninitialeEES21.setVisible(true);

			}
		});

		QuartdeTourDroiteEES21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES21.setVisible(false);
				DemiTourDroiteEES21.setVisible(false);
				QuartdeTourGaucheEES21.setVisible(false);
				PositioninitialeEES21.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1QG.setBounds(375, 425, 200, 200);
				image4QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image4QG.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		DemiTourDroiteEES21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES21.setVisible(false);
				DemiTourDroiteEES21.setVisible(false);
				QuartdeTourGaucheEES21.setVisible(false);
				PositioninitialeEES21.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1QG.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1DD.setVisible(false);
				image4QG.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEES21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES21.setVisible(false);
				DemiTourDroiteEES21.setVisible(false);
				QuartdeTourGaucheEES21.setVisible(false);
				PositioninitialeEES21.setVisible(false);

				image1.setVisible(false);
				image4.setVisible(false);
				image1QG.setBounds(375, 425, 200, 200);
				image2QD.setVisible(false);
				image1DD.setVisible(false);
				image4QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});
		PositioninitialeEES21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES21.setVisible(false);
				DemiTourDroiteEES21.setVisible(false);
				QuartdeTourGaucheEES21.setVisible(false);
				PositioninitialeEES21.setVisible(false);

				image1.setVisible(false);
				image4.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image4QG.setVisible(false);
				image1QG.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEL21 = new JButton("1/4 D");
		QuartdeTourDroiteEEL21.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEL21);
		QuartdeTourDroiteEEL21.setVisible(false);

		JButton DemiTourDroiteEEL21 = new JButton("1/2 Tour");
		DemiTourDroiteEEL21.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEL21);
		DemiTourDroiteEEL21.setVisible(false);

		JButton QuartdeTourGaucheEEL21 = new JButton("1/4 G");
		QuartdeTourGaucheEEL21.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEL21);
		QuartdeTourGaucheEEL21.setVisible(false);

		JButton PositioninitialeEEL21 = new JButton("-");
		PositioninitialeEEL21.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEL21);
		PositioninitialeEEL21.setVisible(false);

		LaneEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEL21.setVisible(true);
				DemiTourDroiteEEL21.setVisible(true);
				QuartdeTourGaucheEEL21.setVisible(true);
				PositioninitialeEEL21.setVisible(true);

			}
		});

		QuartdeTourDroiteEEL21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL21.setVisible(false);
				DemiTourDroiteEEL21.setVisible(false);
				QuartdeTourGaucheEEL21.setVisible(false);
				PositioninitialeEEL21.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1QG.setBounds(600, 425, 200, 200);
				image5QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image5DD.setVisible(false);
				image1DD.setVisible(false);
				image5QG.setVisible(false);

			}
		});

		DemiTourDroiteEEL21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL21.setVisible(false);
				DemiTourDroiteEEL21.setVisible(false);
				QuartdeTourGaucheEEL21.setVisible(false);
				PositioninitialeEEL21.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1QG.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1DD.setVisible(false);
				image5QG.setVisible(false);
				image1QD.setVisible(false);
				image5DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEL21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL21.setVisible(false);
				DemiTourDroiteEEL21.setVisible(false);
				QuartdeTourGaucheEEL21.setVisible(false);
				PositioninitialeEEL21.setVisible(false);

				image1.setVisible(false);
				image5.setVisible(false);
				image1QG.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1DD.setVisible(false);
				image5QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image5DD.setVisible(false);

			}
		});
		PositioninitialeEEL21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL21.setVisible(false);
				DemiTourDroiteEEL21.setVisible(false);
				QuartdeTourGaucheEEL21.setVisible(false);
				PositioninitialeEEL21.setVisible(false);

				image1.setVisible(false);
				image5.setBounds(375, 200, 200, 200);

				image1QG.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1DD.setVisible(false);
				image5QG.setVisible(false);
				image1QD.setVisible(false);
				image5DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEM21 = new JButton("1/4 D");
		QuartdeTourDroiteEEM21.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEM21);
		QuartdeTourDroiteEEM21.setVisible(false);

		JButton DemiTourDroiteEEM21 = new JButton("1/2 Tour");
		DemiTourDroiteEEM21.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEM21);
		DemiTourDroiteEEM21.setVisible(false);

		JButton QuartdeTourGaucheEEM21 = new JButton("1/4 G");
		QuartdeTourGaucheEEM21.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEM21);
		QuartdeTourGaucheEEM21.setVisible(false);

		JButton PositioninitialeEEM21 = new JButton("-");
		PositioninitialeEEM21.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEM21);
		PositioninitialeEEM21.setVisible(false);

		MadameEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEM21.setVisible(true);
				DemiTourDroiteEEM21.setVisible(true);
				QuartdeTourGaucheEEM21.setVisible(true);
				PositioninitialeEEM21.setVisible(true);

			}
		});

		QuartdeTourDroiteEEM21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM21.setVisible(false);
				DemiTourDroiteEEM21.setVisible(false);
				QuartdeTourGaucheEEM21.setVisible(false);
				PositioninitialeEEM21.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1QG.setBounds(825, 425, 200, 200);
				image6QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image6DD.setVisible(false);
				image1DD.setVisible(false);
				image6QG.setVisible(false);

			}
		});

		DemiTourDroiteEEM21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM21.setVisible(false);
				DemiTourDroiteEEM21.setVisible(false);
				QuartdeTourGaucheEEM21.setVisible(false);
				PositioninitialeEEM21.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1QG.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1DD.setVisible(false);
				image6QG.setVisible(false);
				image1QD.setVisible(false);
				image6DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEM21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM21.setVisible(false);
				DemiTourDroiteEEM21.setVisible(false);
				QuartdeTourGaucheEEM21.setVisible(false);
				PositioninitialeEEM21.setVisible(false);

				image1.setVisible(false);
				image6.setVisible(false);
				image1QG.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1DD.setVisible(false);
				image6QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image6DD.setVisible(false);

			}
		});
		PositioninitialeEEM21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM21.setVisible(false);
				DemiTourDroiteEEM21.setVisible(false);
				QuartdeTourGaucheEEM21.setVisible(false);
				PositioninitialeEEM21.setVisible(false);

				image1.setVisible(false);
				image6.setBounds(375, 200, 200, 200);
				image1QG.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1DD.setVisible(false);
				image6QG.setVisible(false);
				image1QD.setVisible(false);
				image6DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEMS21 = new JButton("1/4 D");
		QuartdeTourDroiteEEMS21.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEMS21);
		QuartdeTourDroiteEEMS21.setVisible(false);

		JButton DemiTourDroiteEEMS21 = new JButton("1/2 Tour");
		DemiTourDroiteEEMS21.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEMS21);
		DemiTourDroiteEEMS21.setVisible(false);

		JButton QuartdeTourGaucheEEMS21 = new JButton("1/4 G");
		QuartdeTourGaucheEEMS21.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEMS21);
		QuartdeTourGaucheEEMS21.setVisible(false);

		JButton PositioninitialeEEMS21 = new JButton("-");
		PositioninitialeEEMS21.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEMS21);
		PositioninitialeEEMS21.setVisible(false);

		StealthyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEMS21.setVisible(true);
				DemiTourDroiteEEMS21.setVisible(true);
				QuartdeTourGaucheEEMS21.setVisible(true);
				PositioninitialeEEMS21.setVisible(true);

			}
		});

		QuartdeTourDroiteEEMS21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS21.setVisible(false);
				DemiTourDroiteEEMS21.setVisible(false);
				QuartdeTourGaucheEEMS21.setVisible(false);
				PositioninitialeEEMS21.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1QG.setBounds(375, 650, 200, 200);
				image7QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image7QD.setVisible(false);
				image1DD.setVisible(false);
				image7QG.setVisible(false);

			}
		});

		DemiTourDroiteEEMS21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS21.setVisible(false);
				DemiTourDroiteEEMS21.setVisible(false);
				QuartdeTourGaucheEEMS21.setVisible(false);
				PositioninitialeEEMS21.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1QG.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1QD.setVisible(false);
				image7QD.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image7QG.setVisible(false);

			}
		});
		QuartdeTourGaucheEEMS21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS21.setVisible(false);
				DemiTourDroiteEEMS21.setVisible(false);
				QuartdeTourGaucheEEMS21.setVisible(false);
				PositioninitialeEEMS21.setVisible(false);

				image1.setVisible(false);
				image7.setVisible(false);
				image1QG.setBounds(375, 650, 200, 200);
				image7DD.setVisible(false);
				image1DD.setVisible(false);
				image7QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image7DD.setVisible(false);

			}
		});
		PositioninitialeEEMS21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS21.setVisible(false);
				DemiTourDroiteEEMS21.setVisible(false);
				QuartdeTourGaucheEEMS21.setVisible(false);
				PositioninitialeEEMS21.setVisible(false);

				image1.setVisible(false);
				image7.setBounds(375, 200, 200, 200);
				image1DD.setVisible(false);
				image7QG.setVisible(false);
				image1QG.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1QD.setVisible(false);
				image7DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEGU21 = new JButton("1/4 D");
		QuartdeTourDroiteEEGU21.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEGU21);
		QuartdeTourDroiteEEGU21.setVisible(false);

		JButton DemiTourDroiteEEGU21 = new JButton("1/2 Tour");
		DemiTourDroiteEEGU21.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEGU21);
		DemiTourDroiteEEGU21.setVisible(false);

		JButton QuartdeTourGaucheEEGU21 = new JButton("1/4 G");
		QuartdeTourGaucheEEGU21.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEGU21);
		QuartdeTourGaucheEEGU21.setVisible(false);

		JButton PositioninitialeEEGU21 = new JButton("-");
		PositioninitialeEEGU21.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEGU21);
		PositioninitialeEEGU21.setVisible(false);

		GullEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEGU21.setVisible(true);
				DemiTourDroiteEEGU21.setVisible(true);
				QuartdeTourGaucheEEGU21.setVisible(true);
				PositioninitialeEEGU21.setVisible(true);

			}
		});

		QuartdeTourDroiteEEGU21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU21.setVisible(false);
				DemiTourDroiteEEGU21.setVisible(false);
				QuartdeTourGaucheEEGU21.setVisible(false);
				PositioninitialeEEGU21.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1QG.setBounds(825, 650, 200, 200);
				image9QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image9DD.setVisible(false);
				image1DD.setVisible(false);
				image9QG.setVisible(false);

			}
		});

		DemiTourDroiteEEGU21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU21.setVisible(false);
				DemiTourDroiteEEGU21.setVisible(false);
				QuartdeTourGaucheEEGU21.setVisible(false);
				PositioninitialeEEGU21.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1QG.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1DD.setVisible(false);
				image9QG.setVisible(false);
				image1QD.setVisible(false);
				image9DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEGU21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU21.setVisible(false);
				DemiTourDroiteEEGU21.setVisible(false);
				QuartdeTourGaucheEEGU21.setVisible(false);
				PositioninitialeEEGU21.setVisible(false);

				image1.setVisible(false);
				image9.setVisible(false);
				image1QG.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1DD.setVisible(false);
				image9QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		PositioninitialeEEGU21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU21.setVisible(false);
				DemiTourDroiteEEGU21.setVisible(false);
				QuartdeTourGaucheEEGU21.setVisible(false);
				PositioninitialeEEGU21.setVisible(false);

				image1.setVisible(false);
				image9.setBounds(375, 200, 200, 200);
				image1QG.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1DD.setVisible(false);
				image9QG.setVisible(false);
				image1QD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEG21 = new JButton("1/4 D");
		QuartdeTourDroiteEEG21.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEG21);
		QuartdeTourDroiteEEG21.setVisible(false);

		JButton DemiTourDroiteEEG21 = new JButton("1/2 Tour");
		DemiTourDroiteEEG21.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEG21);
		DemiTourDroiteEEG21.setVisible(false);

		JButton QuartdeTourGaucheEEG21 = new JButton("1/4 G");
		QuartdeTourGaucheEEG21.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEG21);
		QuartdeTourGaucheEEG21.setVisible(false);

		JButton PositioninitialeEEG21 = new JButton("-");
		PositioninitialeEEG21.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEG21);
		PositioninitialeEEG21.setVisible(false);

		GoodleyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEG21.setVisible(true);
				DemiTourDroiteEEG21.setVisible(true);
				QuartdeTourGaucheEEG21.setVisible(true);
				PositioninitialeEEG21.setVisible(true);

			}
		});

		QuartdeTourDroiteEEG21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG21.setVisible(false);
				DemiTourDroiteEEG21.setVisible(false);
				QuartdeTourGaucheEEG21.setVisible(false);
				PositioninitialeEEG21.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1QG.setBounds(600, 650, 200, 200);
				image8QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image8DD.setVisible(false);
				image1DD.setVisible(false);
				image8QG.setVisible(false);

			}
		});

		DemiTourDroiteEEG21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG21.setVisible(false);
				DemiTourDroiteEEG21.setVisible(false);
				QuartdeTourGaucheEEG21.setVisible(false);
				PositioninitialeEEG21.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1QG.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1DD.setVisible(false);
				image8QG.setVisible(false);
				image1QD.setVisible(false);
				image8DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEG21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG21.setVisible(false);
				DemiTourDroiteEEG21.setVisible(false);
				QuartdeTourGaucheEEG21.setVisible(false);
				PositioninitialeEEG21.setVisible(false);

				image1.setVisible(false);
				image8.setVisible(false);
				image1QG.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1DD.setVisible(false);
				image8QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image8DD.setVisible(false);

			}
		});

		PositioninitialeEEG21.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG21.setVisible(false);
				DemiTourDroiteEEG21.setVisible(false);
				QuartdeTourGaucheEEG21.setVisible(false);
				PositioninitialeEEG21.setVisible(false);

				image1.setVisible(false);
				image8.setBounds(375, 200, 200, 200);
				image1QG.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1DD.setVisible(false);
				image8QG.setVisible(false);
				image1QD.setVisible(false);
				image8DD.setVisible(false);

			}
		});
//////////////////////////// place ////////

		PositioninitialeE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteE.setVisible(false);
				DemiTourDroiteE.setVisible(false);
				QuartdeTourGaucheE.setVisible(false);

				PositioninitialeE.setVisible(false);

				LestradeEE.setVisible(true);
				PizerEE.setVisible(true);
				SmithEE.setVisible(true);
				LaneEE.setVisible(true);
				MadameEE.setVisible(true);
				StealthyEE.setVisible(true);
				GullEE.setVisible(true);
				GoodleyEE.setVisible(true);

			}

		});

		JButton QuartdeTourDroiteEE31 = new JButton("1/4 D");
		QuartdeTourDroiteEE31.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEE31);
		QuartdeTourDroiteEE31.setVisible(false);

		JButton DemiTourDroiteEE31 = new JButton("1/2 Tour");
		DemiTourDroiteEE31.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEE31);
		DemiTourDroiteEE31.setVisible(false);

		JButton QuartdeTourGaucheEE31 = new JButton("1/4 G");
		QuartdeTourGaucheEE31.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEE31);
		QuartdeTourGaucheEE31.setVisible(false);

		JButton PositioninitialeEE31 = new JButton("-");
		PositioninitialeEE31.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEE31);
		PositioninitialeEE31.setVisible(false);

		LestradeEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEE31.setVisible(true);
				DemiTourDroiteEE31.setVisible(true);
				QuartdeTourGaucheEE111.setVisible(true);
				PositioninitialeEE31.setVisible(true);

				/*
				 * image1.setVisible(false); image2.setVisible(false); image1QD.setBounds(600,
				 * 200, 200,200); image2QD.setBounds(375, 200, 200,200);
				 * image1QG.setVisible(false); image2QG.setVisible(false);
				 */

			}
		});

		QuartdeTourDroiteEE31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE31.setVisible(false);
				DemiTourDroiteEE31.setVisible(false);
				QuartdeTourGaucheEE111.setVisible(false);
				PositioninitialeEE31.setVisible(false);

				image1DD.setVisible(false);
				image2.setVisible(false);
				image1.setBounds(600, 200, 200, 200);
				image2QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image2DD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);

			}
		});

		DemiTourDroiteEE31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE31.setVisible(false);
				DemiTourDroiteEE31.setVisible(false);
				QuartdeTourGaucheEE111.setVisible(false);
				PositioninitialeEE31.setVisible(false);

				image1DD.setVisible(false);
				image2.setVisible(false);
				image1.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);
				image1QD.setVisible(false);
				image2DD.setBounds(375, 200, 200, 200);
			}
		});

		QuartdeTourGaucheEE111.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE31.setVisible(false);
				DemiTourDroiteEE31.setVisible(false);
				QuartdeTourGaucheEE111.setVisible(false);
				PositioninitialeEE31.setVisible(false);

				image1DD.setVisible(false);
				image2.setVisible(false);
				image1.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		PositioninitialeEE31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEE31.setVisible(false);
				DemiTourDroiteEE31.setVisible(false);
				QuartdeTourGaucheEE111.setVisible(false);
				PositioninitialeEE31.setVisible(false);

				image1DD.setVisible(false);
				image2.setBounds(375, 200, 200, 200);
				image1.setBounds(600, 200, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image2QG.setVisible(false);
				image1QD.setVisible(false);
				image2DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEP31 = new JButton("1/4 D");
		QuartdeTourDroiteEEP31.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEP31);
		QuartdeTourDroiteEEP31.setVisible(false);

		JButton DemiTourDroiteEEP31 = new JButton("1/2 Tour");
		DemiTourDroiteEEP31.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEP31);
		DemiTourDroiteEEP31.setVisible(false);

		JButton QuartdeTourGaucheEEP31 = new JButton("1/4 G");
		QuartdeTourGaucheEEP31.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEP31);
		QuartdeTourGaucheEEP31.setVisible(false);

		JButton PositioninitialeEEP31 = new JButton("-");
		PositioninitialeEEP31.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEP31);
		PositioninitialeEEP31.setVisible(false);

		PizerEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				/*
				 * QuartdeTourDroiteEE.setVisible(false); DemiTourDroiteEE.setVisible(false);
				 * QuartdeTourGaucheEE.setVisible(false); PositioninitialeEE.setVisible(false);
				 */

				QuartdeTourDroiteEEP31.setVisible(true);
				DemiTourDroiteEEP31.setVisible(true);
				QuartdeTourGaucheEEP31.setVisible(true);
				PositioninitialeEEP31.setVisible(true);

			}
		});

		QuartdeTourDroiteEEP31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP31.setVisible(false);
				DemiTourDroiteEEP31.setVisible(false);
				QuartdeTourGaucheEEP31.setVisible(false);
				PositioninitialeEEP31.setVisible(false);

				image1DD.setVisible(false);
				image3.setVisible(false);
				image1.setBounds(825, 200, 200, 200);
				image3QD.setBounds(375, 200, 200, 200);
				image3DD.setVisible(false);
				image1QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setVisible(false);

			}
		});

		DemiTourDroiteEEP31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP31.setVisible(false);
				DemiTourDroiteEEP31.setVisible(false);
				QuartdeTourGaucheEEP31.setVisible(false);
				PositioninitialeEEP31.setVisible(false);

				image1DD.setVisible(false);
				image3.setVisible(false);
				image1.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setVisible(false);
				image1QD.setVisible(false);
				image3DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEP31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP31.setVisible(false);
				DemiTourDroiteEEP31.setVisible(false);
				QuartdeTourGaucheEEP31.setVisible(false);
				PositioninitialeEEP31.setVisible(false);

				image1DD.setVisible(false);
				image3.setVisible(false);
				image1.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QG.setVisible(false);
				image3QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image3DD.setVisible(false);

			}
		});
		PositioninitialeEEP31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEP31.setVisible(false);
				DemiTourDroiteEEP31.setVisible(false);
				QuartdeTourGaucheEEP31.setVisible(false);
				PositioninitialeEEP31.setVisible(false);

				image1DD.setVisible(false);
				image3.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image3QG.setVisible(false);
				image1.setBounds(825, 200, 200, 200);
				image3QD.setVisible(false);
				image1QD.setVisible(false);
				image3DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEES31 = new JButton("1/4 D");
		QuartdeTourDroiteEES31.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEES31);
		QuartdeTourDroiteEES31.setVisible(false);

		JButton DemiTourDroiteEES31 = new JButton("1/2 Tour");
		DemiTourDroiteEES31.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEES31);
		DemiTourDroiteEES31.setVisible(false);

		JButton QuartdeTourGaucheEES31 = new JButton("1/4 G");
		QuartdeTourGaucheEES31.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEES31);
		QuartdeTourGaucheEES31.setVisible(false);

		JButton PositioninitialeEES31 = new JButton("-");
		PositioninitialeEES31.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEES31);
		PositioninitialeEES31.setVisible(false);

		SmithEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEES31.setVisible(true);
				DemiTourDroiteEES31.setVisible(true);
				QuartdeTourGaucheEES31.setVisible(true);
				PositioninitialeEES31.setVisible(true);

			}
		});

		QuartdeTourDroiteEES31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES31.setVisible(false);
				DemiTourDroiteEES31.setVisible(false);
				QuartdeTourGaucheEES31.setVisible(false);
				PositioninitialeEES31.setVisible(false);

				image1DD.setVisible(false);
				image4.setVisible(false);
				image1.setBounds(375, 425, 200, 200);
				image4QD.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		DemiTourDroiteEES31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEES31.setVisible(false);
				DemiTourDroiteEES31.setVisible(false);
				QuartdeTourGaucheEES31.setVisible(false);
				PositioninitialeEES31.setVisible(false);

				image1DD.setVisible(false);
				image4.setVisible(false);
				image1.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEES31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES31.setVisible(false);
				DemiTourDroiteEES31.setVisible(false);
				QuartdeTourGaucheEES31.setVisible(false);
				PositioninitialeEES31.setVisible(false);

				image1DD.setVisible(false);
				image4.setVisible(false);
				image1.setBounds(375, 425, 200, 200);
				image2QD.setVisible(false);
				image1QG.setVisible(false);
				image4QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});
		PositioninitialeEES31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEES31.setVisible(false);
				DemiTourDroiteEES31.setVisible(false);
				QuartdeTourGaucheEES31.setVisible(false);
				PositioninitialeEES31.setVisible(false);

				image1DD.setVisible(false);
				image4.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image4QG.setVisible(false);
				image1.setBounds(375, 425, 200, 200);
				image4QD.setVisible(false);
				image1QD.setVisible(false);
				image4DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEL31 = new JButton("1/4 D");
		QuartdeTourDroiteEEL31.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEL31);
		QuartdeTourDroiteEEL31.setVisible(false);

		JButton DemiTourDroiteEEL31 = new JButton("1/2 Tour");
		DemiTourDroiteEEL31.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEL31);
		DemiTourDroiteEEL31.setVisible(false);

		JButton QuartdeTourGaucheEEL31 = new JButton("1/4 G");
		QuartdeTourGaucheEEL31.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEL31);
		QuartdeTourGaucheEEL31.setVisible(false);

		JButton PositioninitialeEEL31 = new JButton("-");
		PositioninitialeEEL31.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEL31);
		PositioninitialeEEL31.setVisible(false);

		LaneEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEL31.setVisible(true);
				DemiTourDroiteEEL31.setVisible(true);
				QuartdeTourGaucheEEL31.setVisible(true);
				PositioninitialeEEL31.setVisible(true);

			}
		});

		QuartdeTourDroiteEEL31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL31.setVisible(false);
				DemiTourDroiteEEL31.setVisible(false);
				QuartdeTourGaucheEEL31.setVisible(false);
				PositioninitialeEEL31.setVisible(false);

				image1DD.setVisible(false);
				image5.setVisible(false);
				image1.setBounds(600, 425, 200, 200);
				image5QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image5DD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);

			}
		});

		DemiTourDroiteEEL31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEL31.setVisible(false);
				DemiTourDroiteEEL31.setVisible(false);
				QuartdeTourGaucheEEL31.setVisible(false);
				PositioninitialeEEL31.setVisible(false);

				image1DD.setVisible(false);
				image5.setVisible(false);
				image1.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);
				image1QD.setVisible(false);
				image5DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEL31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL31.setVisible(false);
				DemiTourDroiteEEL31.setVisible(false);
				QuartdeTourGaucheEEL31.setVisible(false);
				PositioninitialeEEL31.setVisible(false);

				image1DD.setVisible(false);
				image5.setVisible(false);
				image1.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image5DD.setVisible(false);

			}
		});
		PositioninitialeEEL31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEL31.setVisible(false);
				DemiTourDroiteEEL31.setVisible(false);
				QuartdeTourGaucheEEL31.setVisible(false);
				PositioninitialeEEL31.setVisible(false);

				image1DD.setVisible(false);
				image5.setBounds(375, 200, 200, 200);

				image1.setBounds(600, 425, 200, 200);
				image5QD.setVisible(false);
				image1QG.setVisible(false);
				image5QG.setVisible(false);
				image1QD.setVisible(false);
				image5DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEM31 = new JButton("1/4 D");
		QuartdeTourDroiteEEM31.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEM31);
		QuartdeTourDroiteEEM31.setVisible(false);

		JButton DemiTourDroiteEEM31 = new JButton("1/2 Tour");
		DemiTourDroiteEEM31.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEM31);
		DemiTourDroiteEEM31.setVisible(false);

		JButton QuartdeTourGaucheEEM31 = new JButton("1/4 G");
		QuartdeTourGaucheEEM31.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEM31);
		QuartdeTourGaucheEEM31.setVisible(false);

		JButton PositioninitialeEEM31 = new JButton("-");
		PositioninitialeEEM31.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEM31);
		PositioninitialeEEM31.setVisible(false);

		MadameEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEM31.setVisible(true);
				DemiTourDroiteEEM31.setVisible(true);
				QuartdeTourGaucheEEM31.setVisible(true);
				PositioninitialeEEM31.setVisible(true);

			}
		});

		QuartdeTourDroiteEEM31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM31.setVisible(false);
				DemiTourDroiteEEM31.setVisible(false);
				QuartdeTourGaucheEEM31.setVisible(false);
				PositioninitialeEEM31.setVisible(false);

				image1DD.setVisible(false);
				image6.setVisible(false);
				image1.setBounds(825, 425, 200, 200);
				image6QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image6DD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);

			}
		});

		DemiTourDroiteEEM31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEM31.setVisible(false);
				DemiTourDroiteEEM31.setVisible(false);
				QuartdeTourGaucheEEM31.setVisible(false);
				PositioninitialeEEM31.setVisible(false);

				image1DD.setVisible(false);
				image6.setVisible(false);
				image1.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);
				image1QD.setVisible(false);
				image6DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEM31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM31.setVisible(false);
				DemiTourDroiteEEM31.setVisible(false);
				QuartdeTourGaucheEEM31.setVisible(false);
				PositioninitialeEEM31.setVisible(false);

				image1DD.setVisible(false);
				image6.setVisible(false);
				image1.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image6DD.setVisible(false);

			}
		});
		PositioninitialeEEM31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEM31.setVisible(false);
				DemiTourDroiteEEM31.setVisible(false);
				QuartdeTourGaucheEEM31.setVisible(false);
				PositioninitialeEEM31.setVisible(false);

				image1DD.setVisible(false);
				image6.setBounds(375, 200, 200, 200);
				image1.setBounds(825, 425, 200, 200);
				image6QD.setVisible(false);
				image1QG.setVisible(false);
				image6QG.setVisible(false);
				image1QD.setVisible(false);
				image6DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEMS31 = new JButton("1/4 D");
		QuartdeTourDroiteEEMS31.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEMS31);
		QuartdeTourDroiteEEMS31.setVisible(false);

		JButton DemiTourDroiteEEMS31 = new JButton("1/2 Tour");
		DemiTourDroiteEEMS31.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEMS31);
		DemiTourDroiteEEMS31.setVisible(false);

		JButton QuartdeTourGaucheEEMS31 = new JButton("1/4 G");
		QuartdeTourGaucheEEMS31.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEMS31);
		QuartdeTourGaucheEEMS31.setVisible(false);

		JButton PositioninitialeEEMS31 = new JButton("-");
		PositioninitialeEEMS31.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEMS31);
		PositioninitialeEEMS31.setVisible(false);

		StealthyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEMS31.setVisible(true);
				DemiTourDroiteEEMS31.setVisible(true);
				QuartdeTourGaucheEEMS31.setVisible(true);
				PositioninitialeEEMS31.setVisible(true);

			}
		});

		QuartdeTourDroiteEEMS31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS31.setVisible(false);
				DemiTourDroiteEEMS31.setVisible(false);
				QuartdeTourGaucheEEMS31.setVisible(false);
				PositioninitialeEEMS31.setVisible(false);

				image1DD.setVisible(false);
				image7.setVisible(false);
				image1.setBounds(375, 650, 200, 200);
				image7QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image7QD.setVisible(false);
				image1QG.setVisible(false);
				image7QG.setVisible(false);

			}
		});

		DemiTourDroiteEEMS31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEMS31.setVisible(false);
				DemiTourDroiteEEMS31.setVisible(false);
				QuartdeTourGaucheEEMS31.setVisible(false);
				PositioninitialeEEMS31.setVisible(false);

				image1DD.setVisible(false);
				image7.setVisible(false);
				image1.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1QD.setVisible(false);
				image7QD.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image7QG.setVisible(false);

			}
		});
		QuartdeTourGaucheEEMS31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS31.setVisible(false);
				DemiTourDroiteEEMS31.setVisible(false);
				QuartdeTourGaucheEEMS31.setVisible(false);
				PositioninitialeEEMS31.setVisible(false);

				image1DD.setVisible(false);
				image7.setVisible(false);
				image1.setBounds(375, 650, 200, 200);
				image7DD.setVisible(false);
				image1QG.setVisible(false);
				image7QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image7DD.setVisible(false);

			}
		});
		PositioninitialeEEMS31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEMS31.setVisible(false);
				DemiTourDroiteEEMS31.setVisible(false);
				QuartdeTourGaucheEEMS31.setVisible(false);
				PositioninitialeEEMS31.setVisible(false);

				image1DD.setVisible(false);
				image7.setBounds(375, 200, 200, 200);
				image1QG.setVisible(false);
				image7QG.setVisible(false);
				image1.setBounds(375, 650, 200, 200);
				image7QD.setVisible(false);
				image1QD.setVisible(false);
				image7DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEGU31 = new JButton("1/4 D");
		QuartdeTourDroiteEEGU31.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEGU31);
		QuartdeTourDroiteEEGU31.setVisible(false);

		JButton DemiTourDroiteEEGU31 = new JButton("1/2 Tour");
		DemiTourDroiteEEGU31.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEGU31);
		DemiTourDroiteEEGU31.setVisible(false);

		JButton QuartdeTourGaucheEEGU31 = new JButton("1/4 G");
		QuartdeTourGaucheEEGU31.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEGU31);
		QuartdeTourGaucheEEGU31.setVisible(false);

		JButton PositioninitialeEEGU31 = new JButton("-");
		PositioninitialeEEGU31.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEGU31);
		PositioninitialeEEGU31.setVisible(false);

		GullEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEGU31.setVisible(true);
				DemiTourDroiteEEGU31.setVisible(true);
				QuartdeTourGaucheEEGU31.setVisible(true);
				PositioninitialeEEGU31.setVisible(true);

			}
		});

		QuartdeTourDroiteEEGU31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU31.setVisible(false);
				DemiTourDroiteEEGU31.setVisible(false);
				QuartdeTourGaucheEEGU31.setVisible(false);
				PositioninitialeEEGU31.setVisible(false);

				image1DD.setVisible(false);
				image9.setVisible(false);
				image1.setBounds(825, 650, 200, 200);
				image9QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image9DD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);

			}
		});

		DemiTourDroiteEEGU31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEGU31.setVisible(false);
				DemiTourDroiteEEGU31.setVisible(false);
				QuartdeTourGaucheEEGU31.setVisible(false);
				PositioninitialeEEGU31.setVisible(false);

				image1DD.setVisible(false);
				image9.setVisible(false);
				image1.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);
				image1QD.setVisible(false);
				image9DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEGU31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU31.setVisible(false);
				DemiTourDroiteEEGU31.setVisible(false);
				QuartdeTourGaucheEEGU31.setVisible(false);
				PositioninitialeEEGU31.setVisible(false);

				image1DD.setVisible(false);
				image9.setVisible(false);
				image1.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		PositioninitialeEEGU31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEGU31.setVisible(false);
				DemiTourDroiteEEGU31.setVisible(false);
				QuartdeTourGaucheEEGU31.setVisible(false);
				PositioninitialeEEGU31.setVisible(false);

				image1DD.setVisible(false);
				image9.setBounds(375, 200, 200, 200);
				image1.setBounds(825, 650, 200, 200);
				image9QD.setVisible(false);
				image1QG.setVisible(false);
				image9QG.setVisible(false);
				image1QD.setVisible(false);
				image9DD.setVisible(false);

			}
		});

		JButton QuartdeTourDroiteEEG331 = new JButton("1/4 D");
		QuartdeTourDroiteEEG331.setBounds(1550, 580, 85, 15);
		label.add(QuartdeTourDroiteEEG331);
		QuartdeTourDroiteEEG331.setVisible(false);

		JButton DemiTourDroiteEEG31 = new JButton("1/2 Tour");
		DemiTourDroiteEEG31.setBounds(1550, 595, 85, 15);
		label.add(DemiTourDroiteEEG31);
		DemiTourDroiteEEG31.setVisible(false);

		JButton QuartdeTourGaucheEEG31 = new JButton("1/4 G");
		QuartdeTourGaucheEEG31.setBounds(1550, 610, 85, 15);
		label.add(QuartdeTourGaucheEEG31);
		QuartdeTourGaucheEEG31.setVisible(false);

		JButton PositioninitialeEEG31 = new JButton("-");
		PositioninitialeEEG31.setBounds(1550, 625, 85, 15);
		label.add(PositioninitialeEEG31);
		PositioninitialeEEG31.setVisible(false);

		GoodleyEE.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LestradeEE.setVisible(false);
				PizerEE.setVisible(false);
				SmithEE.setVisible(false);
				LaneEE.setVisible(false);
				MadameEE.setVisible(false);
				StealthyEE.setVisible(false);
				GullEE.setVisible(false);
				GoodleyEE.setVisible(false);

				QuartdeTourDroiteEEG331.setVisible(true);
				DemiTourDroiteEEG31.setVisible(true);
				QuartdeTourGaucheEEG31.setVisible(true);
				PositioninitialeEEG31.setVisible(true);

			}
		});

		QuartdeTourDroiteEEG331.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG331.setVisible(false);
				DemiTourDroiteEEG31.setVisible(false);
				QuartdeTourGaucheEEG31.setVisible(false);
				PositioninitialeEEG31.setVisible(false);

				image1DD.setVisible(false);
				image8.setVisible(false);
				image1.setBounds(600, 650, 200, 200);
				image8QD.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image8DD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);

			}
		});

		DemiTourDroiteEEG31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				QuartdeTourDroiteEEG331.setVisible(false);
				DemiTourDroiteEEG31.setVisible(false);
				QuartdeTourGaucheEEG31.setVisible(false);
				PositioninitialeEEG31.setVisible(false);

				image1DD.setVisible(false);
				image8.setVisible(false);
				image1.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);
				image1QD.setVisible(false);
				image8DD.setBounds(375, 200, 200, 200);

			}
		});
		QuartdeTourGaucheEEG31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG331.setVisible(false);
				DemiTourDroiteEEG31.setVisible(false);
				QuartdeTourGaucheEEG31.setVisible(false);
				PositioninitialeEEG31.setVisible(false);

				image1DD.setVisible(false);
				image8.setVisible(false);
				image1.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setBounds(375, 200, 200, 200);
				image1QD.setVisible(false);
				image8DD.setVisible(false);

			} 
		});

		PositioninitialeEEG31.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				QuartdeTourDroiteEEG331.setVisible(false);
				DemiTourDroiteEEG31.setVisible(false);
				QuartdeTourGaucheEEG31.setVisible(false);
				PositioninitialeEEG31.setVisible(false);

				image1DD.setVisible(false);
				image8.setBounds(375, 200, 200, 200);
				image1.setBounds(600, 650, 200, 200);
				image8QD.setVisible(false);
				image1QG.setVisible(false);
				image8QG.setVisible(false);
				image1QD.setVisible(false);
				image8DD.setVisible(false);

			}
		});

	}
}