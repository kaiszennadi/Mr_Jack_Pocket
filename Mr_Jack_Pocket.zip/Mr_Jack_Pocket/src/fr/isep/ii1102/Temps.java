package fr.isep.ii1102;

public class Temps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int numero;

	}

}
