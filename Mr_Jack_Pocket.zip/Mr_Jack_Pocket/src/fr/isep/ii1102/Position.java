package fr.isep.ii1102;

public class Position {
	private String column;
	private int row;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
