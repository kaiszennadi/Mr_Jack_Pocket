package fr.isep.ii1102;

import java.awt.FlowLayout;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Main {

	public static void main(String[] args) {
		Jframe j1=new Jframe();                          // Permet de cr�er une instance de la classe Jframe.
		j1.Main();                                       // Permet d'appeler la m�thode Main afin d'afficher la fen�tre principale de jeu.
	
		
	
		District d1 = new District(5, 5);                // Permet de cr�er une instance de la classe District.
	
		d1.DebutdeJeu();                                 // Nouvelle partie, plateau vide
		
		d1.Miseenplaceduplateau();                       // Placement des tuiles, affichage de la liste des personnages et du plateau
		
		d1.ChoixduPersonnage();                          // Choix du personnages
		                                                 // Permet � Mr Jack de piocher une carte au hasard qui sera l'identit� sous
				                                         // laquelle il se dissimule
		
	 
		



		
		

		// Test tour n�x
		System.out.println("Le tour n�1 peut maintenant commencer");

		// Permet d'afficher la fin de la partie
		Tours t1 = new Tours();                          // Permet de cr�er une instance de la classe Tours.
		
		t1.Deroulementdujeu();                           // Appelle la m�thode permettant d'afficher le d�roulement du jeu (traques, appels � t�moins...).
		t1.FindePartie(8);                               // Permet d'afficher la fin de la partie.
		
	}
}
