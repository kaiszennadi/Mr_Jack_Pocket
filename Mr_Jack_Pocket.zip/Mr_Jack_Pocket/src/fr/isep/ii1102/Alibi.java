package fr.isep.ii1102;

public class Alibi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
