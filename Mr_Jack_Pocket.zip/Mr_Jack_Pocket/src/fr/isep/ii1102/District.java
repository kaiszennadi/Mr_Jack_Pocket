package fr.isep.ii1102;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class District {

	
	
	
	
	private static final String[][] District = null;         // Permet de cr�er un tableau repr�sentant le plateau de jeu.
// Attributs d�finissants e plateau de jeu
	private int nbLignes;                                    // Nombre de lignes du tableau.
	private int nbColonnes;                                  // Nombre de colonnes du tableau.
	private char[][] grille;

// Constructeur
	public District(int n, int p) {                          // Permet de cr�er un tableau de la taille que l'on veut .
		nbLignes = n;
		nbColonnes = p;
		grille = new char[nbLignes][nbColonnes];

		for (int i = 0; i < nbLignes; i++) {                 // Permet de placer un '.' dans toutes les cellules du tableau.
			for (int j = 0; j < nbColonnes; j++) {
				grille[i][j] = '.';

			}
		}
	}
	// Accesseurs

	 // Fonction permettant d'afficher le plateau de jeu d�finit auparavant.
	
	public void afficher() {                       
		System.out.println();                       
		for (int i = 0; i < nbLignes; i++) {          
			for (int j = 0; j < nbColonnes; j++) {

				System.out.print(" | " + grille[i][j]);         // Permet de placer un '|' autour de toutes la cellules du tableau.

			}
			System.out.println(" | ");
		}
		System.out.println();
	}

// Fonction permettant de placer les diff�rents suspects al�atoirement sur le plateau de jeu.

	public void placer(int c, int d, char t) {
		if (c < 0 || d < 0 || c > nbLignes || d > nbColonnes) {
			System.out.println(" Erreur de placements ");
			return;
		}
		if (grille[c][d] == '.') {
			grille[c][d] = t;
		} 

	}
///////////////////////////////////////////////////////////////////////////////// Fonction permettant de placer les autres personnages 

	// Fonction permettant aux joueurs de placer les tuiles de rues al�atoirement sur le plateau en saisissant la lettre 'm'.
	
	public void placerM() {

		System.out.println("Veuillez placer les cartes al�atoirement sur le plateau de jeu :");
		System.out.println("Taper m pour cela");
		Scanner Carte = new Scanner(System.in);
		String c = Carte.nextLine();
		if (c.equals("m")) {
			MelangeretPlacer();

		}
		

	}

	// Fonction permettant de renvoyer un nombre entier al�atoire entre deux bornes.
	
	public int al(int n, int p) {
		Random r = new Random();
		int valeur = n + r.nextInt(p - n);

		return valeur;

	}

	// Fonction permettant aux joueurs de placer les tuiles de rues al�atoirement
	// sur le plateau

	public void MelangeretPlacer() {
		List<String> liste = new ArrayList<String>(); // Permet de cr�er une liste vide.
    // Permet d'ajouter les lettres repr�sentants les diff�rentes tuiles de rues
		liste.add("M");
		liste.add("G");
		liste.add("B");
		liste.add("W");
		liste.add("S");
		liste.add("J");
		liste.add("I");
		liste.add("P");
		liste.add("L");

		int indiceAuHasard1 = (int) (Math.random() * (liste.size() - 1)); // Permet de s�lectionner un indice au hard de la liste 'liste'.
		String m = liste.get(indiceAuHasard1);                            // Permet de s�lectionner l'�l�ment d'indice 'indiceAuHasard1'.
		char M = m.charAt(0);                    // Permet de convertir cette chaine de caract�re en 'char' et d'en afficher la premi�re lettre.
		placer(1, 1, M);                                                  // Permet de placer la lettre.
		liste.remove(indiceAuHasard1);                                    // Permet de supprier cet �l�ment e la liste.

		
		int indiceAuHasard2 = (int) (Math.random() * (liste.size() - 1)); // Permet de s�lectionner un indice au hard de la liste 'liste'.
		String g = liste.get(indiceAuHasard2);                            // Permet de s�lectionner l'�l�ment d'indice 'indiceAuHasard2'.
		char G = g.charAt(0);                    // Permet de convertir cette chaine de caract�re en 'char' et d'en afficher la premi�re lettre.
		placer(1, 2, G);                                                  // Permet de placer la lettre.
		liste.remove(indiceAuHasard2);                                    // Permet de supprier cet �l�ment e la liste.

		
		int indiceAuHasard3 = (int) (Math.random() * (liste.size() - 1)); // Permet de s�lectionner un indice au hard de la liste 'liste'.
		String b = liste.get(indiceAuHasard3);                            // Permet de s�lectionner l'�l�ment d'indice 'indiceAuHasard3'.
		char B = b.charAt(0);                    // Permet de convertir cette chaine de caract�re en 'char' et d'en afficher la premi�re lettre.
		placer(1, 3, B);                                                  // Permet de placer la lettre.
		liste.remove(indiceAuHasard3);                                    // Permet de supprier cet �l�ment e la liste.

		
		int indiceAuHasard4 = (int) (Math.random() * (liste.size() - 1)); // Permet de s�lectionner un indice au hard de la liste 'liste'.
		String w = liste.get(indiceAuHasard4);                            // Permet de s�lectionner l'�l�ment d'indice 'indiceAuHasard4'.
		char W = w.charAt(0);                    // Permet de convertir cette chaine de caract�re en 'char' et d'en afficher la premi�re lettre.
		placer(2, 1, W);                                                  // Permet de placer la lettre.
		liste.remove(indiceAuHasard4);                                    // Permet de supprier cet �l�ment e la liste.

		
		int indiceAuHasard5 = (int) (Math.random() * (liste.size() - 1)); // Permet de s�lectionner un indice au hard de la liste 'liste'.
		String s = liste.get(indiceAuHasard5);                            // Permet de s�lectionner l'�l�ment d'indice 'indiceAuHasard5'.
		char S = s.charAt(0);                    // Permet de convertir cette chaine de caract�re en 'char' et d'en afficher la premi�re lettre.
		placer(2, 2, S);                                                  // Permet de placer la lettre.
		liste.remove(indiceAuHasard5);                                    // Permet de supprier cet �l�ment e la liste.

		
		int indiceAuHasard6 = (int) (Math.random() * (liste.size() - 1)); // Permet de s�lectionner un indice au hard de la liste 'liste'.
		String j = liste.get(indiceAuHasard6);                            // Permet de s�lectionner l'�l�ment d'indice 'indiceAuHasard6'.
		char J = j.charAt(0);                    // Permet de convertir cette chaine de caract�re en 'char' et d'en afficher la premi�re lettre.
		placer(2, 3, J);                                                  // Permet de placer la lettre.
		liste.remove(indiceAuHasard6);                                    // Permet de supprier cet �l�ment e la liste.

		
		int indiceAuHasard7 = (int) (Math.random() * (liste.size() - 1)); // Permet de s�lectionner un indice au hard de la liste 'liste'.
		String i = liste.get(indiceAuHasard7);                            // Permet de s�lectionner l'�l�ment d'indice 'indiceAuHasard7'.
		char I = i.charAt(0);                    // Permet de convertir cette chaine de caract�re en 'char' et d'en afficher la premi�re lettre.
		placer(3, 1, I);                                                  // Permet de placer la lettre.
		liste.remove(indiceAuHasard7);                                    // Permet de supprier cet �l�ment e la liste.

		
		int indiceAuHasard8 = (int) (Math.random() * (liste.size() - 1)); // Permet de s�lectionner un indice au hard de la liste 'liste'.
		String p = liste.get(indiceAuHasard8);                            // Permet de s�lectionner l'�l�ment d'indice 'indiceAuHasard8'.
		char P = p.charAt(0);                    // Permet de convertir cette chaine de caract�re en 'char' et d'en afficher la premi�re lettre.
		placer(3, 2, P);                                                  // Permet de placer la lettre.
		liste.remove(indiceAuHasard8);                                    // Permet de supprier cet �l�ment e la liste.

		
		int indiceAuHasard9 = (int) (Math.random() * (liste.size() - 1)); // Permet de s�lectionner un indice au hard de la liste 'liste'.
		String l = liste.get(indiceAuHasard9);                            // Permet de s�lectionner l'�l�ment d'indice 'indiceAuHasard9'.
		char L = l.charAt(0);                    // Permet de convertir cette chaine de caract�re en 'char' et d'en afficher la premi�re lettre.
		placer(3, 3, L);                                                  // Permet de placer la lettre.
		liste.remove(indiceAuHasard9);                                    // Permet de supprier cet �l�ment e la liste.

		// Placement initial des d�tectives

		placer(0, 1, 's'); // Permet de placer la lettre repr�sentant Holmes en position (0,1) sur le plateau de jeu de taille 5x5.
		placer(1, 4, 'w'); // Permet de placer la lettre repr�sentant Watson en position (1,4) sur le plateau de jeu de taille 5x5.
		placer(4, 2, 't'); // Permet de placer la lettre repr�sentant Tobi en position (4,2) sur le plateau de jeu de taille 5x5.

		afficher();
	}
	public void DebutdeJeu(){
		System.out.println("Nouvelle partie");
		System.out.println("Voici le plateau de jeu : Le District de Whitechapel");
		
		
	}
	public void Miseenplaceduplateau(){
		afficher();
		Personnage p1 = new Personnage();
		p1.listedesPersonnages();
		
		System.out.println("Veuiller m�langer les neuf tuiles de rues et les placer sur le plateau de jeu");
		placerM();
		MelangeretPlacer();
		
		
	}
	
	// Fonction appelant la m�thode 'qui()' afin de permettre aux deux joueurs de choisir leur personnage.
	
	public void ChoixduPersonnage(){                
		Personnage p1 = new Personnage();
		p1.qui(null);
		
	}
	
	
	public void imim() {
		String JeremyBertrQD = "JeremyBertQD-recto.png";
		ImageIcon iconeJeremyBertrQD = new ImageIcon(JeremyBertrQD);
		JLabel image2QD = new JLabel(iconeJeremyBertrQD);
		image2QD.setBounds(600, 200, 200, 200);
	}
}
